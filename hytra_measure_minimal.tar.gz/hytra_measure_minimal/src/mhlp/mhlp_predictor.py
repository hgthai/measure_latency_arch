"""
MHLPPredictor: Multihardware Adaptive Latency Prediction Model
===============================================================

Nhiệm vụ 3: Xây dựng kiến trúc MHLP bằng PyTorch.

Mô hình MHLP dự đoán latency (ms) của một kiến trúc mạng nơ-ron trên
một thiết bị phần cứng cụ thể. Bao gồm 4 thành phần chính:

  ┌───────────────────────┐       ┌──────────────────────┐
  │  Network Architecture │       │  Hardware Features   │
    │  X: (B, 19, 14)      │       │  hw: (B, 5)          │
  │  A: (B, 19, 19)      │       │                      │
  └──────────┬────────────┘       └──────────┬───────────┘
             │                               │
             ▼                               ▼
  ┌──────────────────────┐       ┌──────────────────────┐
  │ 1. GCN Encoder       │       │ 2. Hardware MLP      │
  │    (3-layer GCN)     │       │    (3-layer MLP)     │
  │    Custom, no torch_ │       │    One-hot → embed   │
  │    geometric needed  │       │                      │
  └──────────┬───────────┘       └──────────┬───────────┘
             │ node_embs (B,19,D)           │ hw_emb (B,D)
             │                               │
             ▼                               ▼
  ┌──────────────────────────────────────────────────────┐
  │ 3. Multihead Attention Fusion (nn.MultiheadAttention)│
  │                                                      │
  │    Q (Queries) ← GCN node embeddings                │
  │    K (Keys)    ← [GCN nodes; HW token]              │
  │    V (Values)  ← [GCN nodes; HW token]              │
  │                                                      │
  │    → Residual + LayerNorm + FFN                      │
  │    → Global Mean Pooling → fused (B, D)              │
  └──────────────────────┬───────────────────────────────┘
                         │
                         ▼
  ┌──────────────────────────────────────────────────────┐
  │ 4. Latency Regressor                                 │
  │    Linear(D, D) → ReLU → Dropout                     │
  │    Linear(D, D//2) → ReLU → Dropout                 │
  │    Linear(D//2, 1)                                   │
  └──────────────────────┬───────────────────────────────┘
                         │
                         ▼
                  predicted_latency (B, 1)

Usage:
    from mhlp_predictor import MHLPPredictor
    from hytra_encoding import encode_hytra_dag, encode_hardware

    model = MHLPPredictor()
    X, A = encode_hytra_dag(arch_tuples)
    hw = encode_hardware("RTX4080")
    pred = model(X_batch, A_batch, hw_batch)

Author: MHLP Team — Khóa luận tốt nghiệp
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, Optional, Tuple


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  1. GRAPH CONVOLUTIONAL LAYER (GCN Layer — Custom Implementation)      ║
# ║                                                                        ║
# ║  Công thức: H' = σ( D̃^{-1/2} Ã D̃^{-1/2} H W + b )                  ║
# ║  Trong đó: Ã = A (đã có self-loops), D̃ = degree matrix của Ã         ║
# ║                                                                        ║
# ║  KHÔNG yêu cầu torch_geometric. Dùng phép nhân ma trận PyTorch.       ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class GCNLayer(nn.Module):
    """
    Một lớp Graph Convolutional Network (GCN) — Kipf & Welling, 2017.

    Thực hiện message passing trên đồ thị:
      Bước 1: Chuẩn hóa ma trận kề:  Â = D̃⁻¹/² Ã D̃⁻¹/²
      Bước 2: Biến đổi tuyến tính:   S = H·W
      Bước 3: Propagation qua đồ thị: H' = Â · S + b
      Bước 4: Activation function:    H' = σ(H')

    Args:
        in_features:  Chiều feature đầu vào mỗi node
        out_features: Chiều feature đầu ra mỗi node
        bias:         Có sử dụng bias không
    """

    def __init__(
        self,
        in_features: int,
        out_features: int,
        bias: bool = True,
    ):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        # Trọng số W ∈ ℝ^{in_features × out_features}
        self.weight = nn.Parameter(torch.empty(in_features, out_features))

        if bias:
            self.bias = nn.Parameter(torch.empty(out_features))
        else:
            self.register_parameter("bias", None)

        self._reset_parameters()

    def _reset_parameters(self) -> None:
        """Khởi tạo trọng số: Glorot/Xavier uniform."""
        nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, X: torch.Tensor, A: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.

        Args:
            X: Node feature matrix, shape (batch, num_nodes, in_features)
            A: Adjacency matrix (đã có self-loops),
               shape (batch, num_nodes, num_nodes)

        Returns:
            H': Transformed features, shape (batch, num_nodes, out_features)
        """
        # Bước 1: Chuẩn hóa ma trận kề → D̃⁻¹/² Ã D̃⁻¹/²
        A_norm = self._normalize_adjacency(A)

        # Bước 2: Biến đổi tuyến tính H·W → (B, N, out_features)
        support = torch.matmul(X, self.weight)

        # Bước 3: Message passing qua đồ thị → Â · (H·W)
        output = torch.bmm(A_norm, support)  # (B, N, out_features)

        # Bước 4: Bias
        if self.bias is not None:
            output = output + self.bias

        return output

    @staticmethod
    def _normalize_adjacency(A: torch.Tensor) -> torch.Tensor:
        """
        Chuẩn hóa symmetric: D̃⁻¹/² Ã D̃⁻¹/²

        Args:
            A: Adjacency matrix (B, N, N) — assumed to include self-loops
        Returns:
            Normalized adjacency (B, N, N)
        """
        # Degree: D̃_ii = Σ_j Ã_ij
        degree = A.sum(dim=-1)  # (B, N)

        # D̃⁻¹/², tránh division by zero
        d_inv_sqrt = torch.pow(degree.clamp(min=1e-12), -0.5)  # (B, N)

        # Broadcast: D⁻¹/² A D⁻¹/² = diag(d)⁻¹/² @ A @ diag(d)⁻¹/²
        d_left = d_inv_sqrt.unsqueeze(-1)    # (B, N, 1)
        d_right = d_inv_sqrt.unsqueeze(-2)   # (B, 1, N)

        return d_left * A * d_right  # element-wise broadcast

    def __repr__(self) -> str:
        return (f"GCNLayer({self.in_features} → {self.out_features})")


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  2. NETWORK ARCHITECTURE ENCODER (Nhánh GCN)                          ║
# ║                                                                        ║
# ║  Xử lý đồ thị DAG (X, A) của kiến trúc HyTra.                       ║
# ║  Output: Per-node embeddings (KHÔNG pooling — pooling sau attention).  ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class GCNEncoder(nn.Module):
    """
    Nhánh GCN: Mã hóa đồ thị DAG kiến trúc HyTra thành per-node embeddings.

    Kiến trúc:
      GCNLayer(node_feat_dim, hidden_dim) → BN → ReLU → Dropout
      GCNLayer(hidden_dim, hidden_dim)    → BN → ReLU → Residual → Dropout
      GCNLayer(hidden_dim, embed_dim)     → BN → ReLU → Residual
      → LayerNorm

    Đặc điểm quan trọng:
      - Output là per-node embeddings (B, N, D), KHÔNG pooling
      - Pooling sẽ được thực hiện SAU bước Multihead Attention
      - Điều này cho phép attention layer "nhìn thấy" từng node riêng lẻ,
        nắm bắt mối quan hệ node-hardware chi tiết hơn

    Args:
        node_feat_dim: Chiều feature mỗi node (default: 14 cho HyTra)
        hidden_dim:    Chiều ẩn GCN (default: 128)
        embed_dim:     Chiều embedding đầu ra (default: 128)
        num_layers:    Số lớp GCN (default: 3)
        dropout:       Tỷ lệ dropout (default: 0.1)
    """

    def __init__(
        self,
        node_feat_dim: int = 14,
        hidden_dim: int = 128,
        embed_dim: int = 128,
        num_layers: int = 3,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.num_layers = num_layers
        self.dropout_rate = dropout

        # Stack GCN layers
        self.gcn_layers = nn.ModuleList()
        self.batch_norms = nn.ModuleList()

        # Layer đầu: node_feat_dim → hidden_dim
        self.gcn_layers.append(GCNLayer(node_feat_dim, hidden_dim))
        self.batch_norms.append(nn.BatchNorm1d(hidden_dim))

        # Hidden layers: hidden_dim → hidden_dim
        for _ in range(num_layers - 2):
            self.gcn_layers.append(GCNLayer(hidden_dim, hidden_dim))
            self.batch_norms.append(nn.BatchNorm1d(hidden_dim))

        # Layer cuối: hidden_dim → embed_dim
        self.gcn_layers.append(GCNLayer(hidden_dim, embed_dim))
        self.batch_norms.append(nn.BatchNorm1d(embed_dim))

        # Output normalization
        self.output_norm = nn.LayerNorm(embed_dim)

    def forward(self, X: torch.Tensor, A: torch.Tensor) -> torch.Tensor:
        """
        Forward pass — trả về per-node embeddings.

        Args:
            X: Node features, shape (B, N, node_feat_dim)
            A: Adjacency matrix, shape (B, N, N)

        Returns:
            node_embeddings: shape (B, N, embed_dim) — per-node, chưa pooling
        """
        H = X  # (B, N, F_in)

        for i, (gcn, bn) in enumerate(zip(self.gcn_layers, self.batch_norms)):
            # GCN message passing
            H_new = gcn(H, A)  # (B, N, F_out)

            # BatchNorm: reshape (B, N, C) → (B*N, C) → normalize → reshape back
            B, N, C = H_new.shape
            H_new = bn(H_new.reshape(B * N, C)).reshape(B, N, C)

            # Activation
            H_new = F.relu(H_new)

            # Residual connection (khi kích thước khớp)
            if H.shape[-1] == H_new.shape[-1]:
                H_new = H_new + H

            # Dropout (trừ layer cuối)
            if i < self.num_layers - 1:
                H_new = F.dropout(H_new, p=self.dropout_rate, training=self.training)

            H = H_new

        # LayerNorm đầu ra
        return self.output_norm(H)  # (B, N, embed_dim)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  3. HARDWARE ENCODER (Nhánh MLP)                                      ║
# ║                                                                        ║
# ║  Xử lý vector phần cứng MHLP 5D → hardware embedding (Dd).            ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class HardwareMLP(nn.Module):
    """
    Nhánh MLP: Mã hóa vector one-hot phần cứng thành embedding.

    Kiến trúc:
      Linear(hw_dim, hidden) → LayerNorm → ReLU → Dropout
      Linear(hidden, hidden)  → LayerNorm → ReLU → Dropout
      Linear(hidden, embed_dim) → LayerNorm

    Mặc dù input chỉ là one-hot (thưa), MLP project nó vào không gian
    embedding liên tục, cho phép mô hình học mối quan hệ ngữ nghĩa
    giữa các nền tảng phần cứng (e.g., GPU vs ARM SoC).

    Args:
        hw_input_dim: Chiều input phần cứng (default: 5, MHLP paper 5D encoding)
        hidden_dim:   Chiều ẩn (default: 64)
        embed_dim:    Chiều embedding output (default: 128)
        dropout:      Tỷ lệ dropout (default: 0.1)
    """

    def __init__(
        self,
        hw_input_dim: int = 5,
        hidden_dim: int = 64,
        embed_dim: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()

        self.mlp = nn.Sequential(
            # Layer 1: Input projection (5 → 64)
            nn.Linear(hw_input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),

            # Layer 2: Hidden (64 → 64)
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),

            # Layer 3: Output projection (64 → 128)
            nn.Linear(hidden_dim, embed_dim),
            nn.LayerNorm(embed_dim),
        )

    def forward(self, hw_features: torch.Tensor) -> torch.Tensor:
        """
        Args:
            hw_features: shape (B, hw_input_dim)
        Returns:
            hw_embedding: shape (B, embed_dim)
        """
        return self.mlp(hw_features)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  4. MULTIHEAD ATTENTION FUSION                                         ║
# ║     (nn.MultiheadAttention — Dung hợp đặc trưng GCN + MLP)           ║
# ║                                                                        ║
# ║  GIẢI THÍCH CÁCH ÁNH XẠ Q, K, V:                                     ║
# ║  ─────────────────────────────────                                     ║
# ║  Q (Queries) ← Nhánh GCN (kiến trúc mạng)                            ║
# ║  K (Keys)    ← Nhánh GCN + Nhánh MLP (kiến trúc + phần cứng)        ║
# ║  V (Values)  ← Nhánh GCN + Nhánh MLP (kiến trúc + phần cứng)        ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class MultiheadAttentionFusion(nn.Module):
    """
    Module dung hợp đặc trưng bằng nn.MultiheadAttention.

    ═══════════════════════════════════════════════════════════════════════
    THIẾT KẾ Q, K, V — Chi tiết:
    ═══════════════════════════════════════════════════════════════════════

    Q (Queries) ← NHÁNH GCN (Network Architecture Encoder):
      ┌────────────────────────────────────────────────────────────────┐
      │ Input:   Per-node embeddings từ GCN, shape (B, N, D)          │
      │ Ý nghĩa: Mỗi node kiến trúc mạng "đặt câu hỏi":             │
      │          "Tôi (node này) cần thông tin gì từ các node khác    │
      │           VÀ từ phần cứng để dự đoán latency?"                │
      │ Bên trong nn.MHA: Q_proj = W_Q @ node_embeddings              │
      └────────────────────────────────────────────────────────────────┘

    K (Keys) ← NHÁNH GCN + NHÁNH MLP (kết hợp cả hai):
      ┌────────────────────────────────────────────────────────────────┐
      │ Input:   [node_embeddings; hw_token], shape (B, N+1, D)       │
      │ Ý nghĩa: Cả kiến trúc lẫn phần cứng cung cấp "chìa khóa"   │
      │          để hệ thống attention tìm kiếm thông tin phù hợp.    │
      │          hw_token ở vị trí cuối chuỗi → attention tự học       │
      │          mức độ quan trọng của phần cứng đối với mỗi node.    │
      │ Bên trong nn.MHA: K_proj = W_K @ [nodes; hw_token]            │
      └────────────────────────────────────────────────────────────────┘

    V (Values) ← NHÁNH GCN + NHÁNH MLP (kết hợp cả hai):
      ┌────────────────────────────────────────────────────────────────┐
      │ Input:   [node_embeddings; hw_token], shape (B, N+1, D)       │
      │ Ý nghĩa: "Giá trị" thực sự mà attention truy xuất.           │
      │          Bao gồm thông tin kiến trúc (từ GCN) VÀ phần cứng   │
      │          (từ MLP), cho phép mỗi node nhận thức phần cứng.    │
      │ Bên trong nn.MHA: V_proj = W_V @ [nodes; hw_token]            │
      └────────────────────────────────────────────────────────────────┘

    Kết quả:
      attn_output shape (B, N, D) — mỗi node đã "biết" về:
        (a) Các node kiến trúc khác (spatial dependencies qua GCN)
        (b) Đặc trưng phần cứng (cross-modal fusion qua hw_token)
      → Global Mean Pooling → fused_features (B, D)
    ═══════════════════════════════════════════════════════════════════════

    Args:
        embed_dim:  Chiều embedding (phải bằng output_dim cả 2 encoder)
        num_heads:  Số attention heads (default: 4)
        dropout:    Dropout trong attention (default: 0.1)
        ffn_dim:    Chiều ẩn Feed-Forward Network (default: 512)
    """

    def __init__(
        self,
        embed_dim: int = 128,
        num_heads: int = 4,
        dropout: float = 0.1,
        ffn_dim: int = 512,
    ):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads

        # ── nn.MultiheadAttention ──
        # batch_first=True → input/output format: (batch, seq_len, embed_dim)
        # Bên trong module tự tạo W_Q, W_K, W_V projections
        self.multihead_attn = nn.MultiheadAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            dropout=dropout,
            batch_first=True,  # (B, L, D) format
        )

        # ── Post-attention LayerNorm (Pre-norm style) ──
        self.norm1 = nn.LayerNorm(embed_dim)

        # ── Feed-Forward Network (FFN) ──
        # Transformer-style: Linear → GELU → Dropout → Linear → Dropout
        self.ffn = nn.Sequential(
            nn.Linear(embed_dim, ffn_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(ffn_dim, embed_dim),
            nn.Dropout(dropout),
        )
        self.norm2 = nn.LayerNorm(embed_dim)

    def forward(
        self,
        node_embeddings: torch.Tensor,
        hw_embedding: torch.Tensor,
    ) -> torch.Tensor:
        """
        Forward pass: Dung hợp đặc trưng GCN (per-node) + MLP (hardware).

        Args:
            node_embeddings: Từ GCN Encoder, shape (B, N, embed_dim)
                             N = 19 nodes cho đồ thị HyTra
            hw_embedding:    Từ Hardware MLP, shape (B, embed_dim)

        Returns:
            fused_features: shape (B, embed_dim) — đặc trưng sau fusion
        """
        B, N, D = node_embeddings.shape

        # ═══════════════════════════════════════════════════════════════
        # BƯỚC 1: Chuẩn bị Q, K, V cho nn.MultiheadAttention
        # ═══════════════════════════════════════════════════════════════

        # Q (Queries) ← Nhánh GCN: per-node embeddings từ kiến trúc mạng
        #   Mỗi node "đặt câu hỏi" về mối quan hệ với các node khác
        #   và với phần cứng → shape (B, N, D)
        Q = node_embeddings            # (B, 19, 128)

        # Tạo hardware token: expand hw_embedding thành 1 token
        #   hw_embedding (B, D) → hw_token (B, 1, D)
        hw_token = hw_embedding.unsqueeze(1)  # (B, 1, D)

        # K (Keys) ← Nối [GCN nodes; HW token]:
        #   - Nodes 0..N-1: thông tin kiến trúc (từ GCN)
        #   - Node N: thông tin phần cứng (từ MLP)
        #   → Attention có thể match mỗi query node với tất cả nodes
        #     VÀ với phần cứng → shape (B, N+1, D)
        K = torch.cat([node_embeddings, hw_token], dim=1)  # (B, 20, 128)

        # V (Values) ← Nối [GCN nodes; HW token]:
        #   - Giá trị mà attention truy xuất → bao gồm cả thông tin
        #     kiến trúc và phần cứng → shape (B, N+1, D)
        V = torch.cat([node_embeddings, hw_token], dim=1)  # (B, 20, 128)

        # ═══════════════════════════════════════════════════════════════
        # BƯỚC 2: Áp dụng Multihead Attention
        # ═══════════════════════════════════════════════════════════════
        # nn.MultiheadAttention tự thực hiện bên trong:
        #   Q_proj = W_Q @ Q      (B, N, D)
        #   K_proj = W_K @ K      (B, N+1, D)
        #   V_proj = W_V @ V      (B, N+1, D)
        #   Attention = softmax(Q_proj @ K_proj^T / √d_k) @ V_proj
        #
        # Kết quả: mỗi node đã tổng hợp thông tin từ:
        #   (a) Tất cả nodes kiến trúc khác (self-attention)
        #   (b) Hardware token (cross-modal attention)

        attn_output, attn_weights = self.multihead_attn(
            query=Q,    # (B, N, D) — architecture nodes query
            key=K,      # (B, N+1, D) — arch + hw provide keys
            value=V,    # (B, N+1, D) — arch + hw provide values
        )
        # attn_output: (B, N, D) — attended per-node features
        # attn_weights: (B, N, N+1) — attention weights (optional debug)

        # ═══════════════════════════════════════════════════════════════
        # BƯỚC 3: Residual Connection + LayerNorm
        # ═══════════════════════════════════════════════════════════════
        # Post-norm: norm(x + sublayer(x))
        attn_output = self.norm1(node_embeddings + attn_output)  # (B, N, D)

        # ═══════════════════════════════════════════════════════════════
        # BƯỚC 4: Feed-Forward Network + Residual
        # ═══════════════════════════════════════════════════════════════
        ffn_output = self.ffn(attn_output)
        attn_output = self.norm2(attn_output + ffn_output)  # (B, N, D)

        # ═══════════════════════════════════════════════════════════════
        # BƯỚC 5: Global Mean Pooling → graph-level representation
        # ═══════════════════════════════════════════════════════════════
        # Trung bình tất cả node embeddings → single vector
        fused_features = attn_output.mean(dim=1)  # (B, D)

        return fused_features


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  5. LATENCY REGRESSOR (Bộ hồi quy dự đoán latency)                   ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class LatencyRegressor(nn.Module):
    """
    Linear regressor: fused features → scalar latency prediction.

    Kiến trúc:
      Linear(embed_dim, hidden) → ReLU → Dropout
      Linear(hidden, hidden//2) → ReLU → Dropout
      Linear(hidden//2, 1)

    Args:
        embed_dim:  Chiều input từ fusion module (default: 128)
        hidden_dim: Chiều ẩn (default: 128)
        dropout:    Tỷ lệ dropout (default: 0.1)
    """

    def __init__(
        self,
        embed_dim: int = 128,
        hidden_dim: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()

        self.regressor = nn.Sequential(
            nn.Linear(embed_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),

            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),

            # Output: 1 giá trị scalar (predicted latency)
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, fused: torch.Tensor) -> torch.Tensor:
        """
        Args:
            fused: shape (B, embed_dim)
        Returns:
            predicted_latency: shape (B, 1)
        """
        return self.regressor(fused)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  6. MHLPPredictor — MÔ HÌNH TỔNG HỢP                                 ║
# ║                                                                        ║
# ║  Kết hợp 4 thành phần: GCN + MLP + MultiheadAttention + Regressor     ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class MHLPPredictor(nn.Module):
    """
    MHLP Predictor: Multihardware Adaptive Latency Prediction.

    Mô hình dự đoán inference latency (ms) của một kiến trúc mạng nơ-ron
    trên một thiết bị phần cứng cụ thể, sử dụng 4 thành phần:

    ┌───────────────────────────────────────────────────────────────────┐
    │                                                                   │
    │  1. GCN Encoder:  (X, A) → per-node embeddings (B, N, D)        │
    │     - Graph Convolutional Network xử lý đồ thị DAG              │
    │     - 3 GCN layers + BatchNorm + Residual + LayerNorm            │
    │                                                                   │
    │  2. Hardware MLP: hw_onehot → hw_embedding (B, D)                │
    │     - Multi-Layer Perceptron xử lý vector one-hot phần cứng     │
    │     - 3 Linear layers + LayerNorm + Dropout                      │
    │                                                                   │
    │  3. Multihead Attention Fusion:                                   │
    │     - Q ← GCN node embeddings (kiến trúc)                       │
    │     - K, V ← [GCN nodes; HW token] (kiến trúc + phần cứng)     │
    │     - nn.MultiheadAttention + Residual + FFN + LayerNorm         │
    │     - Global Mean Pooling → fused (B, D)                         │
    │                                                                   │
    │  4. Latency Regressor: fused → predicted_latency (B, 1)          │
    │     - 3 Linear layers + ReLU + Dropout                           │
    │                                                                   │
    └───────────────────────────────────────────────────────────────────┘

    Args:
        node_feat_dim:    Chiều feature mỗi node (default: 14 cho HyTra)
        hw_input_dim:     Chiều input phần cứng (default: 5, MHLP paper 5D)
        gcn_hidden_dim:   Chiều ẩn GCN (default: 128)
        mlp_hidden_dim:   Chiều ẩn Hardware MLP (default: 64)
        embed_dim:        Chiều embedding chung (default: 128)
        num_gcn_layers:   Số lớp GCN (default: 3)
        num_attn_heads:   Số attention heads (default: 4)
        ffn_dim:          Chiều ẩn FFN trong fusion (default: 512)
        predictor_hidden: Chiều ẩn regressor (default: 128)
        dropout:          Tỷ lệ dropout (default: 0.1)
    """

    def __init__(
        self,
        node_feat_dim: int = 14,
        hw_input_dim: int = 5,
        gcn_hidden_dim: int = 128,
        mlp_hidden_dim: int = 64,
        embed_dim: int = 128,
        num_gcn_layers: int = 3,
        num_attn_heads: int = 4,
        ffn_dim: int = 512,
        predictor_hidden: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()

        # ── Nhánh 1: GCN Encoder (Network Architecture) ──
        # Xử lý đồ thị DAG với 19 nodes (16 blocks + Input + Output + Global)
        # Output: per-node embeddings (B, 19, embed_dim)
        self.gcn_encoder = GCNEncoder(
            node_feat_dim=node_feat_dim,
            hidden_dim=gcn_hidden_dim,
            embed_dim=embed_dim,
            num_layers=num_gcn_layers,
            dropout=dropout,
        )

        # ── Nhánh 2: Hardware MLP ──
        # Xử lý vector phần cứng MHLP 5D → hw embedding (128d)
        self.hw_encoder = HardwareMLP(
            hw_input_dim=hw_input_dim,
            hidden_dim=mlp_hidden_dim,
            embed_dim=embed_dim,
            dropout=dropout,
        )

        # ── Module 3: Multihead Attention Fusion ──
        # Dung hợp GCN per-node embeddings + hardware embedding
        # Q ← GCN, K/V ← [GCN; HW]
        self.fusion = MultiheadAttentionFusion(
            embed_dim=embed_dim,
            num_heads=num_attn_heads,
            dropout=dropout,
            ffn_dim=ffn_dim,
        )

        # ── Module 4: Latency Regressor ──
        # Dự đoán giá trị latency (scalar dương)
        self.predictor = LatencyRegressor(
            embed_dim=embed_dim,
            hidden_dim=predictor_hidden,
            dropout=dropout,
        )

        # Khởi tạo trọng số
        self._init_weights()

    def _init_weights(self) -> None:
        """Khởi tạo Kaiming Normal cho Linear layers (trừ GCN)."""
        for module in [self.hw_encoder, self.predictor]:
            for m in module.modules():
                if isinstance(m, nn.Linear):
                    nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

    def forward(self, *inputs) -> torch.Tensor:
        """
        Forward pass hoàn chỉnh.

        Hỗ trợ 2 kiểu gọi:
          1) model((X, A), hardware_features)
          2) model(X, A, hardware_features)   # backward-compatibility

        Luồng xử lý:
          1. GCN Encoder:  (X, A)  → node_embeddings (B, N, D)
          2. Hardware MLP:  hw     → hw_embedding (B, D)
          3. Attention:     fusion(node_embs, hw_emb) → fused (B, D)
          4. Regressor:     fused  → predicted_latency (B, 1)

                Args:
                        inputs:
                            - ((X, A), hardware_features)
                            - (X, A, hardware_features)

        Returns:
            predicted_latency: shape (B, 1)
        """
        if len(inputs) == 2:
            network_features, hardware_features = inputs
            if not isinstance(network_features, (tuple, list)) or len(network_features) != 2:
                raise ValueError(
                    "When passing 2 arguments, expected network_features=(X, A)."
                )
            X, A = network_features
        elif len(inputs) == 3:
            X, A, hardware_features = inputs
        else:
            raise ValueError(
                "Expected forward inputs as ((X, A), hardware_features) "
                "or (X, A, hardware_features)."
            )

        # ── Bước 1: Encode kiến trúc mạng (GCN) ──
        # GCN xử lý đồ thị DAG, trả về per-node embeddings (CHƯA pooling)
        node_embeddings = self.gcn_encoder(X, A)        # (B, N, embed_dim)

        # ── Bước 2: Encode phần cứng (MLP) ──
        # MLP project one-hot → không gian embedding liên tục
        hw_embedding = self.hw_encoder(hardware_features)  # (B, embed_dim)

        # ── Bước 3: Fusion bằng Multihead Attention ──
        # Q ← node_embeddings (GCN)
        # K, V ← [node_embeddings; hw_token] (GCN + MLP)
        # → Mỗi node attend đến tất cả nodes khác VÀ hardware token
        # → Global pooling → fused representation
        fused = self.fusion(node_embeddings, hw_embedding)  # (B, embed_dim)

        # ── Bước 4: Dự đoán latency ──
        predicted_latency = self.predictor(fused)            # (B, 1)

        return predicted_latency

    def count_parameters(self) -> int:
        """Đếm tham số trainable."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def get_component_params(self) -> Dict[str, int]:
        """Trả về số tham số từng thành phần."""
        return {
            "GCN Encoder": sum(
                p.numel() for p in self.gcn_encoder.parameters() if p.requires_grad
            ),
            "Hardware MLP": sum(
                p.numel() for p in self.hw_encoder.parameters() if p.requires_grad
            ),
            "Attention Fusion": sum(
                p.numel() for p in self.fusion.parameters() if p.requires_grad
            ),
            "Latency Regressor": sum(
                p.numel() for p in self.predictor.parameters() if p.requires_grad
            ),
        }


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  7. TRAINING UTILITIES                                                 ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def train_one_epoch(
    model: MHLPPredictor,
    train_loader,
    optimizer: torch.optim.Optimizer,
    criterion: nn.Module,
    device: torch.device,
    epoch: int,
) -> float:
    """Train 1 epoch. Returns: average loss."""
    model.train()
    total_loss = 0.0
    num_batches = 0

    for X, A, hw, latency in train_loader:
        X, A, hw, latency = (
            X.to(device), A.to(device), hw.to(device), latency.to(device)
        )

        pred = model(X, A, hw)
        loss = criterion(pred, latency)

        optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        optimizer.step()

        total_loss += loss.item()
        num_batches += 1

    return total_loss / max(num_batches, 1)


@torch.no_grad()
def evaluate(
    model: MHLPPredictor,
    data_loader,
    criterion: nn.Module,
    device: torch.device,
) -> Tuple[float, float, float]:
    """Evaluate. Returns: (avg_loss, mae, rmse)."""
    model.eval()
    total_loss = 0.0
    all_preds, all_targets = [], []

    for X, A, hw, latency in data_loader:
        X, A, hw, latency = (
            X.to(device), A.to(device), hw.to(device), latency.to(device)
        )
        pred = model(X, A, hw)
        total_loss += criterion(pred, latency).item()
        all_preds.append(pred.cpu())
        all_targets.append(latency.cpu())

    preds = torch.cat(all_preds)
    targets = torch.cat(all_targets)

    avg_loss = total_loss / max(len(data_loader), 1)
    mae = (preds - targets).abs().mean().item()
    rmse = ((preds - targets) ** 2).mean().sqrt().item()

    return avg_loss, mae, rmse


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  8. MAIN: TEST FORWARD PASS với DỮ LIỆU GIẢ LẬP                      ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def main():
    """
    Test forward pass hoàn chỉnh với dummy data và real encoding.
    """
    import sys
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

    print("=" * 72)
    print("  MHLPPredictor — Forward Pass Test")
    print("  Multihardware Adaptive Latency Prediction for HyTra")
    print("=" * 72)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nDevice: {device}")

    # ── Import encoding module ──
    from hytra_encoding import (
        encode_hytra_dag, encode_hardware, bossnas_to_tuples,
        validate_hytra_architecture, pretty_print_architecture,
        print_graph_summary, get_all_hardware_encodings,
        NUM_GRAPH_NODES, NODE_FEATURE_DIM, HW_ENCODING_DIM,
    )

    # ══════════════════════════════════════════════════════════════════════
    # TEST 1: Khởi tạo model + Forward pass với dummy data
    # ══════════════════════════════════════════════════════════════════════
    print(f"\n{'─' * 72}")
    print("▶ TEST 1: Dummy Data Forward Pass")
    print(f"{'─' * 72}")

    model = MHLPPredictor(
        node_feat_dim=NODE_FEATURE_DIM,  # 14
        hw_input_dim=HW_ENCODING_DIM,    # 5
        gcn_hidden_dim=128,
        mlp_hidden_dim=64,
        embed_dim=128,
        num_gcn_layers=3,
        num_attn_heads=4,
        ffn_dim=512,
        predictor_hidden=128,
        dropout=0.1,
    ).to(device)

    # Model summary
    total_params = model.count_parameters()
    print(f"\n  Total trainable parameters: {total_params:,}")
    print(f"\n  Parameters by component:")
    for name, count in model.get_component_params().items():
        pct = 100.0 * count / total_params
        print(f"    {name:22s}: {count:>8,}  ({pct:5.1f}%)")

    # Dummy forward pass
    BATCH = 4
    X_dummy = torch.randn(BATCH, NUM_GRAPH_NODES, NODE_FEATURE_DIM).to(device)
    A_dummy = torch.eye(NUM_GRAPH_NODES).unsqueeze(0).expand(BATCH, -1, -1).clone().to(device)
    for i in range(NUM_GRAPH_NODES - 1):
        A_dummy[:, i, i + 1] = 1.0
    hw_dummy = torch.zeros(BATCH, HW_ENCODING_DIM).to(device)
    hw_dummy[:, 0] = 1.0  # Desktop
    hw_dummy[:, 3] = 1.0  # GPU

    with torch.no_grad():
        pred_dummy = model(X_dummy, A_dummy, hw_dummy)

    print(f"\n  Input shapes:")
    print(f"    X:  {X_dummy.shape}  (batch, nodes, features)")
    print(f"    A:  {A_dummy.shape}  (batch, nodes, nodes)")
    print(f"    hw: {hw_dummy.shape}  (batch, hw_dim)")
    print(f"  Output shape: {pred_dummy.shape}")
    print(f"  Predictions:  {pred_dummy.squeeze().tolist()}")
    print(f"  ✓ Dummy forward pass PASSED")

    # ══════════════════════════════════════════════════════════════════════
    # TEST 2: Forward pass với HyTra architecture encoding thực
    # ══════════════════════════════════════════════════════════════════════
    print(f"\n{'─' * 72}")
    print("▶ TEST 2: Real HyTra Architecture Encoding")
    print(f"{'─' * 72}")

    # Kiến trúc HyTra mẫu: mix CNN + Transformer, giảm dần scale
    sample_arch: list = [
        # Stage 0: bắt đầu scale trung bình, chuyển sang nhỏ hơn
        ("ResConv", 1/8),   ("ResAtt",  1/16),  ("ResAtt",  1/16),  ("ResConv", 1/16),
        # Stage 1: chủ yếu CNN ở scale trung bình
        ("ResConv", 1/8),   ("ResConv", 1/8),   ("ResAtt",  1/16),  ("ResConv", 1/16),
        # Stage 2: scale nhỏ
        ("ResAtt",  1/16),  ("ResConv", 1/16),  ("ResConv", 1/16),  ("ResConv", 1/32),
        # Stage 3: scale nhỏ nhất, heavy Transformer
        ("ResConv", 1/16),  ("ResConv", 1/16),  ("ResAtt",  1/32),  ("ResAtt",  1/32),
    ]

    print(pretty_print_architecture(sample_arch))

    # Validate
    is_valid, errors = validate_hytra_architecture(sample_arch)
    print(f"\n  Validation: {'✓ PASS' if is_valid else '✗ FAIL'}")

    # Encode
    X_enc, A_enc = encode_hytra_dag(sample_arch)
    print(f"\n  Encoded graph:")
    print_graph_summary(X_enc, A_enc)

    # Forward pass cho 3 thiết bị
    print(f"\n  Prediction per hardware:")
    for hw_name in ["RTX4080", "ip15", "Macbook_M1"]:
        hw_vec = encode_hardware(hw_name)
        X_t = torch.tensor(X_enc, dtype=torch.float32).unsqueeze(0).to(device)
        A_t = torch.tensor(A_enc, dtype=torch.float32).unsqueeze(0).to(device)
        hw_t = torch.as_tensor(hw_vec, dtype=torch.float32).unsqueeze(0).to(device)

        with torch.no_grad():
            pred = model(X_t, A_t, hw_t)
        print(f"    {hw_name:12s}: {pred.item():+.6f} (raw, pre-training)")

    print(f"  ✓ Real architecture forward pass PASSED")

    # ══════════════════════════════════════════════════════════════════════
    # TEST 3: BossNAS format conversion + forward pass
    # ══════════════════════════════════════════════════════════════════════
    print(f"\n{'─' * 72}")
    print("▶ TEST 3: BossNAS Format → Tuple → DAG → Forward")
    print(f"{'─' * 72}")

    bossnas_archs = [
        [[4, 2, 2, 3], [4, 4, 2, 3], [2, 3, 3, 1], [3, 3, 0, 0]],
        [[5, 5, 4, 4], [3, 2, 2, 1], [0, 0, 1, 1], [2, 3, 0, 0]],
        [[1, 1, 0, 0], [1, 0, 0, 1], [2, 3, 2, 3], [3, 3, 3, 3]],
    ]

    for idx, bossnas_arch in enumerate(bossnas_archs):
        tuples = bossnas_to_tuples(bossnas_arch)
        X_b, A_b = encode_hytra_dag(tuples)
        hw_b = encode_hardware("RTX4080")

        X_bt = torch.tensor(X_b).unsqueeze(0).to(device)
        A_bt = torch.tensor(A_b).unsqueeze(0).to(device)
        hw_bt = torch.tensor(hw_b).unsqueeze(0).to(device)

        with torch.no_grad():
            pred_b = model(X_bt, A_bt, hw_bt)

        resatt_count = sum(1 for bt, _ in tuples if bt == "ResAtt")
        print(f"  Arch {idx}: BossNAS={bossnas_arch}")
        print(f"           ResAtt={resatt_count}/16, pred={pred_b.item():+.6f}")

    print(f"  ✓ BossNAS format conversion PASSED")

    # ══════════════════════════════════════════════════════════════════════
    # TEST 4: Batch forward pass (simulating training)
    # ══════════════════════════════════════════════════════════════════════
    print(f"\n{'─' * 72}")
    print("▶ TEST 4: Batch Forward + Backward Pass")
    print(f"{'─' * 72}")

    # Tạo mini-batch từ nhiều kiến trúc
    batch_X, batch_A, batch_hw, batch_lat = [], [], [], []

    for bossnas_arch in bossnas_archs:
        for hw_name in ["RTX4080", "ip15", "Macbook_M1"]:
            tuples = bossnas_to_tuples(bossnas_arch)
            X_s, A_s = encode_hytra_dag(tuples)
            hw_s = encode_hardware(hw_name)

            batch_X.append(torch.tensor(X_s))
            batch_A.append(torch.tensor(A_s))
            batch_hw.append(torch.tensor(hw_s))
            batch_lat.append(torch.tensor([10.0]))  # dummy latency

    X_batch = torch.stack(batch_X).to(device)
    A_batch = torch.stack(batch_A).to(device)
    hw_batch = torch.stack(batch_hw).to(device)
    lat_batch = torch.stack(batch_lat).to(device)

    print(f"  Batch size: {X_batch.shape[0]}")
    print(f"    X:  {X_batch.shape}")
    print(f"    A:  {A_batch.shape}")
    print(f"    hw: {hw_batch.shape}")

    # Forward pass
    model.train()
    pred_batch = model(X_batch, A_batch, hw_batch)
    print(f"  Output: {pred_batch.shape}")

    # Backward pass
    criterion = nn.MSELoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)

    loss = criterion(pred_batch, lat_batch)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

    print(f"  Loss: {loss.item():.6f}")
    print(f"  ✓ Batch forward + backward PASSED")

    # ══════════════════════════════════════════════════════════════════════
    # TEST 5: Mini training loop (3 epochs) nếu có data thực
    # ══════════════════════════════════════════════════════════════════════
    print(f"\n{'─' * 72}")
    print("▶ TEST 5: Mini Training Loop (3 epochs)")
    print(f"{'─' * 72}")

    base_dir = os.path.dirname(os.path.abspath(__file__))
    lat_file = os.path.join(base_dir, "latency_500.json")

    if os.path.exists(lat_file):
        from hytra_encoding import HyTraMHLPDataset, create_dataloaders

        dataset = HyTraMHLPDataset(
            json_files=[lat_file],
            hardware_names=["RTX4080"],
            normalize_latency=True,
        )
        train_loader, val_loader, test_loader = create_dataloaders(
            dataset, batch_size=32
        )

        # Fresh model
        model_train = MHLPPredictor(
            node_feat_dim=NODE_FEATURE_DIM,
            hw_input_dim=HW_ENCODING_DIM,
        ).to(device)

        optimizer = torch.optim.AdamW(
            model_train.parameters(), lr=1e-3, weight_decay=1e-4
        )
        criterion = nn.MSELoss()

        print(f"\n  Training on {len(dataset)} samples...")
        for epoch in range(3):
            train_loss = train_one_epoch(
                model_train, train_loader, optimizer, criterion, device, epoch
            )
            val_loss, val_mae, val_rmse = evaluate(
                model_train, val_loader, criterion, device
            )
            print(
                f"    Epoch {epoch + 1}: "
                f"train_loss={train_loss:.4f}, "
                f"val_loss={val_loss:.4f}, "
                f"val_mae={val_mae:.4f}, "
                f"val_rmse={val_rmse:.4f}"
            )

        print(f"  ✓ Training loop PASSED")
    else:
        print(f"  (Skipping — latency_500.json not found)")
        print(f"  ✓ Skipped (no data file)")

    # ══════════════════════════════════════════════════════════════════════
    # SUMMARY
    # ══════════════════════════════════════════════════════════════════════
    print(f"\n{'═' * 72}")
    print("  ✅ ALL TESTS PASSED")
    print(f"{'═' * 72}")
    print(f"  Model: MHLPPredictor")
    print(f"  Total params: {total_params:,}")
    print(f"  Input:  X({NUM_GRAPH_NODES},{NODE_FEATURE_DIM}) + "
          f"A({NUM_GRAPH_NODES},{NUM_GRAPH_NODES}) + hw({HW_ENCODING_DIM})")
    print(f"  Output: predicted_latency (1)")
    print(f"  Components: GCN Encoder → Hardware MLP → "
          f"MultiheadAttention Fusion → Latency Regressor")
    print(f"{'═' * 72}")


if __name__ == "__main__":
    import os
    main()
