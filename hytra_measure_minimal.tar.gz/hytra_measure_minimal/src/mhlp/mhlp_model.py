"""
MHLP Model: Multihardware Adaptive Latency Prediction
=====================================================

Nhiệm vụ 2: Xây dựng cấu trúc mô hình MHLP bằng PyTorch.

Kiến trúc MHLP bao gồm 4 thành phần chính:

  1. Network Architecture Encoder (GCN Branch)
     - Graph Convolutional Network xử lý đồ thị DAG của kiến trúc mạng
     - Input: Node feature matrix X, Adjacency matrix A
     - Output: Graph-level embedding vector

  2. Hardware Encoder (MLP Branch)
     - Multi-Layer Perceptron xử lý vector phần cứng one-hot
     - Input: Hardware one-hot vector
     - Output: Hardware embedding vector

  3. Feature Fusion (Multihead Attention)
     - Cơ chế Multihead Attention (Transformer-style)
     - Dung hợp đặc trưng kiến trúc mạng và đặc trưng phần cứng
     - Q, K, V được tạo từ sự kết hợp của cả hai nhánh

  4. Latency Predictor (Regression Head)
     - Linear layers dự đoán giá trị latency liên tục
     - Input: Fused feature vector
     - Output: Scalar latency prediction

Usage:
    from mhlp_model import MHLPModel
    model = MHLPModel()
    predicted_latency = model(X, A, hw_features)

Author: MHLP Team
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


# ============================================================================
# 1. Graph Convolutional Network (GCN) - Custom Implementation
# ============================================================================
# Không yêu cầu torch_geometric. Sử dụng phép nhân ma trận PyTorch tiêu chuẩn.
# Công thức GCN:  H' = σ( D̃^{-1/2} Ã D̃^{-1/2} H W )
# Trong đó: Ã = A + I (adjacency + self-loops), D̃ = degree matrix của Ã
# ============================================================================

class GCNLayer(nn.Module):
    """
    Một lớp Graph Convolutional Network (GCN).

    Thực hiện phép biến đổi:
        H' = σ( D̃^{-1/2} Ã D̃^{-1/2} H W + b )

    Ã (A_tilde) là ma trận kề đã có self-loops (A + I).
    Nếu A chưa có self-loops, module sẽ tự thêm.

    Args:
        in_features:  Số chiều input feature (mỗi node)
        out_features: Số chiều output feature (mỗi node)
        bias:         Có sử dụng bias hay không
    """

    def __init__(self, in_features: int, out_features: int, bias: bool = True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

        # Trọng số W ∈ R^{in × out} cho phép biến đổi tuyến tính
        self.weight = nn.Parameter(torch.empty(in_features, out_features))

        if bias:
            self.bias = nn.Parameter(torch.empty(out_features))
        else:
            self.register_parameter('bias', None)

        self._reset_parameters()

    def _reset_parameters(self):
        """Khởi tạo trọng số với Glorot/Xavier uniform."""
        nn.init.xavier_uniform_(self.weight)
        if self.bias is not None:
            nn.init.zeros_(self.bias)

    def forward(self, X: torch.Tensor, A: torch.Tensor) -> torch.Tensor:
        """
        Forward pass cho GCN Layer.

        Args:
            X: Node feature matrix, shape (batch, num_nodes, in_features)
            A: Adjacency matrix (đã có self-loops),
               shape (batch, num_nodes, num_nodes)

        Returns:
            H': Transformed node features, shape (batch, num_nodes, out_features)
        """
        # Bước 1: Tính normalized adjacency: D̃^{-1/2} Ã D̃^{-1/2}
        A_hat = self._normalize_adjacency(A)

        # Bước 2: Phép biến đổi tuyến tính H * W
        # X: (B, N, F_in), weight: (F_in, F_out)
        support = torch.matmul(X, self.weight)  # (B, N, F_out)

        # Bước 3: Propagation qua đồ thị: A_hat * (H * W)
        output = torch.bmm(A_hat, support)  # (B, N, F_out)

        # Bước 4: Thêm bias
        if self.bias is not None:
            output = output + self.bias

        return output

    @staticmethod
    def _normalize_adjacency(A: torch.Tensor) -> torch.Tensor:
        """
        Chuẩn hóa ma trận kề: D̃^{-1/2} Ã D̃^{-1/2}

        Args:
            A: Adjacency matrix (batch, N, N) - đã bao gồm self-loops

        Returns:
            Normalized adjacency matrix (batch, N, N)
        """
        # Tính degree vector: D̃_ii = sum_j Ã_ij
        degree = A.sum(dim=-1)  # (B, N)

        # D̃^{-1/2}, tránh chia cho 0
        d_inv_sqrt = torch.pow(degree.clamp(min=1e-12), -0.5)  # (B, N)

        # Tạo ma trận đường chéo D̃^{-1/2}
        # d_inv_sqrt: (B, N) -> (B, N, 1) * A * (B, 1, N) = D^{-1/2} A D^{-1/2}
        d_left = d_inv_sqrt.unsqueeze(-1)   # (B, N, 1)
        d_right = d_inv_sqrt.unsqueeze(-2)  # (B, 1, N)

        A_normalized = d_left * A * d_right  # (B, N, N) element-wise broadcast

        return A_normalized

    def __repr__(self):
        return (f"GCNLayer(in_features={self.in_features}, "
                f"out_features={self.out_features})")


# ============================================================================
# 2. Network Architecture Encoder (Nhánh GCN)
# ============================================================================

class NetworkArchitectureEncoder(nn.Module):
    """
    Nhánh GCN: Mã hóa kiến trúc mạng nơ-ron từ biểu diễn đồ thị DAG.

    Kiến trúc:
        GCNLayer(node_feat_dim, hidden_dim) → ReLU → Dropout
        → GCNLayer(hidden_dim, hidden_dim) → ReLU → Dropout
        → GCNLayer(hidden_dim, hidden_dim) → ReLU
        → Global Pooling (mean + max concatenation)
        → Linear projection → LayerNorm

    Mục đích:
        Nắm bắt mối quan hệ không gian và phụ thuộc giữa các operation
        trong cấu trúc mạng nơ-ron. GCN cho phép mỗi node tổng hợp thông tin
        từ các node lân cận (neighbor aggregation), phù hợp cho cấu trúc DAG.

    Args:
        node_feat_dim: Số chiều feature của mỗi node (default: 9)
        hidden_dim:    Số chiều ẩn của GCN layers (default: 128)
        output_dim:    Số chiều embedding đầu ra (default: 128)
        num_layers:    Số lớp GCN (default: 3)
        dropout:       Tỷ lệ dropout (default: 0.1)
    """

    def __init__(
        self,
        node_feat_dim: int = 9,
        hidden_dim: int = 128,
        output_dim: int = 128,
        num_layers: int = 3,
        dropout: float = 0.1
    ):
        super().__init__()

        self.num_layers = num_layers
        self.dropout = dropout

        # Xây dựng stack GCN layers
        self.gcn_layers = nn.ModuleList()

        # Layer đầu tiên: node_feat_dim -> hidden_dim
        self.gcn_layers.append(GCNLayer(node_feat_dim, hidden_dim))

        # Các layer ẩn: hidden_dim -> hidden_dim
        for _ in range(num_layers - 1):
            self.gcn_layers.append(GCNLayer(hidden_dim, hidden_dim))

        # Batch normalization sau mỗi GCN layer
        self.batch_norms = nn.ModuleList([
            nn.BatchNorm1d(hidden_dim) for _ in range(num_layers)
        ])

        # Global pooling: mean + max => 2 * hidden_dim
        # Sau đó project xuống output_dim
        self.projection = nn.Sequential(
            nn.Linear(hidden_dim * 2, output_dim),
            nn.LayerNorm(output_dim),
        )

    def forward(self, X: torch.Tensor, A: torch.Tensor) -> torch.Tensor:
        """
        Forward pass cho Network Architecture Encoder.

        Args:
            X: Node feature matrix, shape (batch, num_nodes, node_feat_dim)
            A: Adjacency matrix, shape (batch, num_nodes, num_nodes)

        Returns:
            arch_embedding: Graph-level embedding, shape (batch, output_dim)
        """
        H = X  # (B, N, F)

        for i, (gcn, bn) in enumerate(zip(self.gcn_layers, self.batch_norms)):
            # GCN aggregation
            H_new = gcn(H, A)  # (B, N, hidden_dim)

            # Batch normalization: cần reshape (B, N, C) -> (B*N, C) -> (B, N, C)
            B, N, C = H_new.shape
            H_new = bn(H_new.reshape(B * N, C)).reshape(B, N, C)

            # Activation
            H_new = F.relu(H_new)

            # Residual connection (nếu kích thước khớp)
            if H.shape == H_new.shape:
                H_new = H_new + H  # Skip connection

            # Dropout (trừ layer cuối)
            if i < self.num_layers - 1:
                H_new = F.dropout(H_new, p=self.dropout, training=self.training)

            H = H_new

        # ---- Global Graph Pooling ----
        # Mean pooling: trung bình tất cả node features
        h_mean = H.mean(dim=1)  # (B, hidden_dim)

        # Max pooling: lấy max trên tất cả nodes
        h_max = H.max(dim=1).values  # (B, hidden_dim)

        # Nối mean + max
        h_graph = torch.cat([h_mean, h_max], dim=-1)  # (B, 2 * hidden_dim)

        # Projection xuống output_dim
        arch_embedding = self.projection(h_graph)  # (B, output_dim)

        return arch_embedding


# ============================================================================
# 3. Hardware Encoder (Nhánh MLP)
# ============================================================================

class HardwareEncoder(nn.Module):
    """
    Nhánh MLP: Mã hóa vector đặc trưng phần cứng khi đã one-hot encoding.

    Kiến trúc:
        Linear(hw_input_dim, hidden_dim) → LayerNorm → ReLU → Dropout
        → Linear(hidden_dim, hidden_dim) → LayerNorm → ReLU → Dropout
        → Linear(hidden_dim, output_dim) → LayerNorm

    Mục đích:
        Học biểu diễn embedding phong phú cho đặc trưng phần cứng.
        Mặc dù input chỉ là one-hot vector (thưa), MLP sẽ project nó
        vào không gian embedding liên tục, nắm bắt được mối quan hệ
        ngữ nghĩa giữa các nền tảng phần cứng khác nhau.

    Args:
        hw_input_dim: Số chiều input (MHLP 5D encoding), default=5
        hidden_dim:   Số chiều ẩn, default=64
        output_dim:   Số chiều embedding đầu ra, default=128
        dropout:      Tỷ lệ dropout, default=0.1
    """

    def __init__(
        self,
        hw_input_dim: int = 5,
        hidden_dim: int = 64,
        output_dim: int = 128,
        dropout: float = 0.1
    ):
        super().__init__()

        self.mlp = nn.Sequential(
            # Layer 1: Input projection
            nn.Linear(hw_input_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),

            # Layer 2: Hidden
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),

            # Layer 3: Output projection
            nn.Linear(hidden_dim, output_dim),
            nn.LayerNorm(output_dim),
        )

    def forward(self, hw_features: torch.Tensor) -> torch.Tensor:
        """
        Forward pass cho Hardware Encoder.

        Args:
            hw_features: Hardware one-hot vector, shape (batch, hw_input_dim)

        Returns:
            hw_embedding: Hardware embedding, shape (batch, output_dim)
        """
        hw_embedding = self.mlp(hw_features)  # (B, output_dim)
        return hw_embedding


# ============================================================================
# 4. Feature Fusion Module (Multihead Attention)
# ============================================================================

class FeatureFusionModule(nn.Module):
    """
    Module dung hợp đặc trưng bằng Multihead Attention (Transformer-style).

    Cơ chế hoạt động:
        - Tạo chuỗi token từ arch_embedding và hw_embedding
        - Sử dụng nn.MultiheadAttention để thực hiện self-attention
        - Q, K, V đều được tạo từ sự kết hợp đặc trưng kiến trúc + phần cứng
        - Attention cho phép mô hình học sự tương tác phức tạp giữa
          đặc trưng phần cứng và kiến trúc mạng

    Token sequence construction:
        Token 0: [CLS] token (learnable) - dùng để aggregate thông tin
        Token 1: Architecture embedding
        Token 2: Hardware embedding
        => Sequence length = 3

    Self-attention cho phép mỗi token attend đến tất cả tokens khác,
    nhờ đó nắm bắt cross-modal interactions.

    Args:
        embed_dim:  Số chiều embedding (phải bằng output_dim của cả 2 encoder)
        num_heads:  Số attention heads (default: 4)
        dropout:    Tỷ lệ dropout trong attention (default: 0.1)
        num_fusion_layers: Số Transformer layers để fusion (default: 2)
    """

    def __init__(
        self,
        embed_dim: int = 128,
        num_heads: int = 4,
        dropout: float = 0.1,
        num_fusion_layers: int = 2
    ):
        super().__init__()

        self.embed_dim = embed_dim
        self.num_heads = num_heads

        # Learnable [CLS] token - token đặc biệt để aggregate thông tin
        self.cls_token = nn.Parameter(torch.randn(1, 1, embed_dim) * 0.02)

        # Positional encoding cho 3 tokens: [CLS], arch, hw
        self.pos_encoding = nn.Parameter(torch.randn(1, 3, embed_dim) * 0.02)

        # Stack of Transformer Encoder Layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=embed_dim,
            nhead=num_heads,
            dim_feedforward=embed_dim * 4,  # FFN hidden dim = 4x embed_dim
            dropout=dropout,
            activation='gelu',
            batch_first=True,  # Input format: (batch, seq_len, embed_dim)
            norm_first=True,   # Pre-norm architecture (more stable training)
        )
        self.transformer_encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=num_fusion_layers,
        )

        # Layer norm cuối
        self.output_norm = nn.LayerNorm(embed_dim)

    def forward(
        self,
        arch_embedding: torch.Tensor,
        hw_embedding: torch.Tensor
    ) -> torch.Tensor:
        """
        Forward pass cho Feature Fusion Module.

        Quy trình:
            1. Tạo token sequence: [CLS, arch, hw]
            2. Thêm positional encoding
            3. Chạy qua Transformer Encoder (self-attention)
            4. Lấy output của [CLS] token làm fused representation

        Args:
            arch_embedding: Từ GCN branch, shape (batch, embed_dim)
            hw_embedding:   Từ MLP branch, shape (batch, embed_dim)

        Returns:
            fused_features: shape (batch, embed_dim)
        """
        B = arch_embedding.size(0)

        # Tạo token sequence: [CLS, arch_emb, hw_emb]
        cls_tokens = self.cls_token.expand(B, -1, -1)          # (B, 1, D)
        arch_tokens = arch_embedding.unsqueeze(1)               # (B, 1, D)
        hw_tokens = hw_embedding.unsqueeze(1)                   # (B, 1, D)

        # Nối thành chuỗi: (B, 3, D)
        token_sequence = torch.cat([cls_tokens, arch_tokens, hw_tokens], dim=1)

        # Thêm positional encoding
        token_sequence = token_sequence + self.pos_encoding

        # Chạy qua Transformer Encoder (self-attention giữa các tokens)
        # Attention mechanism:
        #   Q, K, V đều được tạo từ token_sequence
        #   Mỗi token attend đến tất cả tokens khác
        #   => CLS token sẽ tổng hợp thông tin từ cả arch và hw
        transformer_output = self.transformer_encoder(token_sequence)  # (B, 3, D)

        # Lấy output từ [CLS] token (vị trí 0) làm fused representation
        cls_output = transformer_output[:, 0, :]  # (B, D)

        # Layer norm cuối
        fused_features = self.output_norm(cls_output)  # (B, D)

        return fused_features


# ============================================================================
# 5. Latency Predictor (Bộ hồi quy cuối cùng)
# ============================================================================

class LatencyPredictor(nn.Module):
    """
    Bộ hồi quy dự đoán giá trị latency liên tục.

    Kiến trúc:
        Linear(embed_dim, hidden_dim) → ReLU → Dropout
        → Linear(hidden_dim, hidden_dim // 2) → ReLU → Dropout
        → Linear(hidden_dim // 2, 1)

    Mục đích:
        Nhận fused feature vector từ module Multihead Attention
        và dự đoán giá trị latency (scalar dương).

    Args:
        embed_dim:  Số chiều input feature (từ fusion module)
        hidden_dim: Số chiều ẩn (default: 128)
        dropout:    Tỷ lệ dropout (default: 0.1)
    """

    def __init__(
        self,
        embed_dim: int = 128,
        hidden_dim: int = 128,
        dropout: float = 0.1
    ):
        super().__init__()

        self.regressor = nn.Sequential(
            nn.Linear(embed_dim, hidden_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),

            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(inplace=True),
            nn.Dropout(p=dropout),

            # Layer cuối: output 1 giá trị (latency prediction)
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, fused_features: torch.Tensor) -> torch.Tensor:
        """
        Forward pass cho latency prediction.

        Args:
            fused_features: shape (batch, embed_dim)

        Returns:
            predicted_latency: shape (batch, 1)
        """
        return self.regressor(fused_features)


# ============================================================================
# 6. MHLP Model (Mô hình tổng hợp)
# ============================================================================

class MHLPModel(nn.Module):
    """
    MHLP: Multihardware Adaptive Latency Prediction Model
    =====================================================

    Kiến trúc tổng thể:

        ┌─────────────────────┐    ┌──────────────────────┐
        │  Network Arch Input │    │  Hardware Input       │
        │  (X: node features  │    │  (one-hot vector)     │
        │   A: adjacency)     │    │                       │
        └────────┬────────────┘    └──────────┬───────────┘
                 │                             │
                 ▼                             ▼
        ┌─────────────────────┐    ┌──────────────────────┐
        │  GCN Encoder        │    │  MLP Encoder          │
        │  (3-layer GCN +     │    │  (3-layer MLP +       │
        │   global pooling)   │    │   LayerNorm)          │
        └────────┬────────────┘    └──────────┬───────────┘
                 │ arch_emb (128)              │ hw_emb (128)
                 │                             │
                 └──────────┬──────────────────┘
                            │
                            ▼
                 ┌──────────────────────┐
                 │  Multihead Attention  │
                 │  Feature Fusion       │
                 │  (Transformer-style,  │
                 │   [CLS] + arch + hw)  │
                 └──────────┬───────────┘
                            │ fused (128)
                            ▼
                 ┌──────────────────────┐
                 │  Latency Predictor   │
                 │  (MLP Regressor)     │
                 └──────────┬───────────┘
                            │
                            ▼
                    predicted_latency (1)

    Args:
        node_feat_dim:    Số chiều feature mỗi node (default: 9)
        hw_input_dim:     Số chiều input phần cứng (default: 5, MHLP 5D)
        gcn_hidden_dim:   Số chiều ẩn cho GCN (default: 128)
        mlp_hidden_dim:   Số chiều ẩn cho Hardware MLP (default: 64)
        embed_dim:        Số chiều embedding chung (default: 128)
        num_gcn_layers:   Số lớp GCN (default: 3)
        num_attn_heads:   Số attention heads (default: 4)
        num_fusion_layers: Số Transformer layers cho fusion (default: 2)
        predictor_hidden: Số chiều ẩn cho predictor (default: 128)
        dropout:          Tỷ lệ dropout chung (default: 0.1)
    """

    def __init__(
        self,
        node_feat_dim: int = 9,
        hw_input_dim: int = 5,
        gcn_hidden_dim: int = 128,
        mlp_hidden_dim: int = 64,
        embed_dim: int = 128,
        num_gcn_layers: int = 3,
        num_attn_heads: int = 4,
        num_fusion_layers: int = 2,
        predictor_hidden: int = 128,
        dropout: float = 0.1,
    ):
        super().__init__()

        # ---- Nhánh 1: Network Architecture Encoder (GCN) ----
        # Xử lý đồ thị DAG (X, A) để tạo graph-level embedding
        self.arch_encoder = NetworkArchitectureEncoder(
            node_feat_dim=node_feat_dim,
            hidden_dim=gcn_hidden_dim,
            output_dim=embed_dim,
            num_layers=num_gcn_layers,
            dropout=dropout,
        )

        # ---- Nhánh 2: Hardware Encoder (MLP) ----
        # Xử lý vector one-hot phần cứng để tạo hardware embedding
        self.hw_encoder = HardwareEncoder(
            hw_input_dim=hw_input_dim,
            hidden_dim=mlp_hidden_dim,
            output_dim=embed_dim,
            dropout=dropout,
        )

        # ---- Module 3: Feature Fusion (Multihead Attention) ----
        # Dung hợp đặc trưng arch + hw bằng Transformer self-attention
        self.fusion = FeatureFusionModule(
            embed_dim=embed_dim,
            num_heads=num_attn_heads,
            dropout=dropout,
            num_fusion_layers=num_fusion_layers,
        )

        # ---- Module 4: Latency Predictor (Regression Head) ----
        # Dự đoán giá trị latency liên tục
        self.predictor = LatencyPredictor(
            embed_dim=embed_dim,
            hidden_dim=predictor_hidden,
            dropout=dropout,
        )

        # Khởi tạo trọng số
        self._init_weights()

    def _init_weights(self):
        """Khởi tạo trọng số cho các Linear layers (trừ GCN đã có riêng)."""
        for module in [self.hw_encoder, self.predictor]:
            for m in module.modules():
                if isinstance(m, nn.Linear):
                    nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
                    if m.bias is not None:
                        nn.init.zeros_(m.bias)

    def forward(self, *inputs) -> torch.Tensor:
        """
        Forward pass hoàn chỉnh của mô hình MHLP.

        Luồng xử lý:
            1. GCN Encoder:  (X, A) → arch_embedding
            2. MLP Encoder:  hardware_features → hw_embedding
            3. Fusion:       (arch_embedding, hw_embedding) → fused
            4. Predictor:    fused → predicted_latency

                Args:
                        inputs:
                            - ((X, A), hardware_features)
                            - (X, A, hardware_features)

        Returns:
            predicted_latency: Dự đoán latency
                               shape (batch, 1)
        """
        if len(inputs) == 2:
            network_features, hardware_features = inputs
            if not isinstance(network_features, (tuple, list)) or len(network_features) != 2:
                raise ValueError(
                    "When passing 2 arguments, expected network_features=(X, A)."
                )
            X, A = network_features
        elif len(inputs) == 3:
            X, A, hardware_features = inputs
        else:
            raise ValueError(
                "Expected forward inputs as ((X, A), hardware_features) "
                "or (X, A, hardware_features)."
            )

        # ---- Bước 1: Encode kiến trúc mạng ----
        # GCN xử lý đồ thị DAG, output là graph-level embedding
        arch_embedding = self.arch_encoder(X, A)        # (B, embed_dim)

        # ---- Bước 2: Encode đặc trưng phần cứng ----
        # MLP project one-hot vector vào không gian embedding
        hw_embedding = self.hw_encoder(hardware_features)  # (B, embed_dim)

        # ---- Bước 3: Dung hợp đặc trưng ----
        # Multihead Attention kết hợp cả 2 nhánh
        # Q, K, V được tạo từ chuỗi [CLS, arch, hw]
        fused = self.fusion(arch_embedding, hw_embedding)  # (B, embed_dim)

        # ---- Bước 4: Dự đoán latency ----
        # Linear regressor output scalar
        predicted_latency = self.predictor(fused)          # (B, 1)

        return predicted_latency

    def count_parameters(self) -> int:
        """Đếm tổng số tham số có thể train."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def get_component_params(self) -> dict:
        """Trả về số tham số của từng thành phần."""
        return {
            "arch_encoder (GCN)": sum(
                p.numel() for p in self.arch_encoder.parameters() if p.requires_grad
            ),
            "hw_encoder (MLP)": sum(
                p.numel() for p in self.hw_encoder.parameters() if p.requires_grad
            ),
            "fusion (MultiheadAttention)": sum(
                p.numel() for p in self.fusion.parameters() if p.requires_grad
            ),
            "predictor (Regressor)": sum(
                p.numel() for p in self.predictor.parameters() if p.requires_grad
            ),
        }


# ============================================================================
# 7. Training Utilities
# ============================================================================

def train_one_epoch(
    model: MHLPModel,
    train_loader,
    optimizer: torch.optim.Optimizer,
    criterion: nn.Module,
    device: torch.device,
    epoch: int,
) -> float:
    """
    Train mô hình MHLP trong 1 epoch.

    Args:
        model: MHLPModel instance
        train_loader: DataLoader cho tập train
        optimizer: Optimizer (e.g., AdamW)
        criterion: Loss function (e.g., MSELoss)
        device: thiết bị train (cuda/cpu)
        epoch: epoch index

    Returns:
        Trung bình loss cho epoch
    """
    model.train()
    total_loss = 0.0
    num_batches = 0

    for batch_idx, (X, A, hw, latency) in enumerate(train_loader):
        X = X.to(device)
        A = A.to(device)
        hw = hw.to(device)
        latency = latency.to(device)

        # Forward
        pred = model(X, A, hw)

        # Compute loss
        loss = criterion(pred, latency)

        # Backward
        optimizer.zero_grad()
        loss.backward()

        # Gradient clipping để ổn định training
        nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

        optimizer.step()

        total_loss += loss.item()
        num_batches += 1

    avg_loss = total_loss / max(num_batches, 1)
    return avg_loss


@torch.no_grad()
def evaluate(
    model: MHLPModel,
    data_loader,
    criterion: nn.Module,
    device: torch.device,
) -> Tuple[float, float, float]:
    """
    Đánh giá mô hình trên tập validation/test.

    Returns:
        (avg_loss, mae, rmse) - mean loss, mean absolute error, root mean sq error
    """
    model.eval()
    total_loss = 0.0
    all_preds = []
    all_targets = []

    for X, A, hw, latency in data_loader:
        X = X.to(device)
        A = A.to(device)
        hw = hw.to(device)
        latency = latency.to(device)

        pred = model(X, A, hw)
        loss = criterion(pred, latency)

        total_loss += loss.item()
        all_preds.append(pred.cpu())
        all_targets.append(latency.cpu())

    all_preds = torch.cat(all_preds)
    all_targets = torch.cat(all_targets)

    avg_loss = total_loss / max(len(data_loader), 1)
    mae = (all_preds - all_targets).abs().mean().item()
    rmse = ((all_preds - all_targets) ** 2).mean().sqrt().item()

    return avg_loss, mae, rmse


# ============================================================================
# 8. Main: Demo forward pass & Summary
# ============================================================================

def main():
    """Demo: Khởi tạo model, forward pass với dữ liệu ngẫu nhiên."""
    import sys
    sys.path.insert(0, '.')

    print("=" * 70)
    print("  MHLP Model - Multihardware Adaptive Latency Prediction")
    print("=" * 70)

    # ---- Cấu hình ----
    BATCH_SIZE = 4
    NUM_NODES = 16        # 4 stages × 4 ops
    NODE_FEAT_DIM = 9     # 6 (op one-hot) + 3 (positional)
    HW_DIM = 5            # MHLP 5D: [is_desktop_cloud, is_mobile, has_cpu, has_gpu, has_asic_npu]

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nDevice: {device}")

    # ---- Khởi tạo model ----
    model = MHLPModel(
        node_feat_dim=NODE_FEAT_DIM,
        hw_input_dim=HW_DIM,
        gcn_hidden_dim=128,
        mlp_hidden_dim=64,
        embed_dim=128,
        num_gcn_layers=3,
        num_attn_heads=4,
        num_fusion_layers=2,
        predictor_hidden=128,
        dropout=0.1,
    ).to(device)

    # ---- Model Summary ----
    print(f"\nTotal trainable parameters: {model.count_parameters():,}")
    print("\nParameters by component:")
    for name, count in model.get_component_params().items():
        print(f"  {name}: {count:,}")

    # ---- Demo forward pass ----
    print(f"\n{'─' * 70}")
    print("Demo Forward Pass:")
    print(f"{'─' * 70}")

    # Tạo input giả
    X = torch.randn(BATCH_SIZE, NUM_NODES, NODE_FEAT_DIM).to(device)
    A = torch.eye(NUM_NODES).unsqueeze(0).expand(BATCH_SIZE, -1, -1).to(device)
    # Thêm kết nối tuần tự
    for i in range(NUM_NODES - 1):
        A[:, i, i + 1] = 1.0
    hw = torch.zeros(BATCH_SIZE, HW_DIM).to(device)
    hw[:, 0] = 1.0  # Desktop
    hw[:, 3] = 1.0  # GPU

    # Forward
    with torch.no_grad():
        pred = model(X, A, hw)

    print(f"  Input X shape:          {X.shape}")
    print(f"  Input A shape:          {A.shape}")
    print(f"  Input hw shape:         {hw.shape}")
    print(f"  Output pred shape:      {pred.shape}")
    print(f"  Predicted latencies:    {pred.squeeze().tolist()}")

    # ---- Test với dữ liệu từ preprocessing (nếu có) ----
    print(f"\n{'─' * 70}")
    print("Integration Test with Preprocessing:")
    print(f"{'─' * 70}")

    try:
        from mhlp_data_preprocessing import (
            encode_network, encode_hardware, MHLPDataset, create_dataloaders
        )
        import os

        # Test encode_network
        sample_arch = [[4, 2, 2, 3], [4, 4, 2, 3], [2, 3, 3, 1], [3, 3, 0, 0]]
        X_test, A_test = encode_network(sample_arch)
        print(f"  encode_network output: X={X_test.shape}, A={A_test.shape}")

        # Test encode_hardware
        for hw_name in ["RTX4080", "ip15", "Macbook_M1"]:
            vec = encode_hardware(hw_name)
            print(f"  encode_hardware('{hw_name}'): {vec.tolist()}")

        # Test forward với encoded data
        X_t = torch.tensor(X_test, dtype=torch.float32).unsqueeze(0).to(device)
        A_t = torch.tensor(A_test, dtype=torch.float32).unsqueeze(0).to(device)
        hw_t = torch.as_tensor(encode_hardware("RTX4080"), dtype=torch.float32).unsqueeze(0).to(device)

        with torch.no_grad():
            pred_t = model(X_t, A_t, hw_t)
        print(f"\n  Single arch prediction: {pred_t.item():.4f}")

        # Test DataLoader nếu dữ liệu tồn tại
        base_dir = os.path.dirname(os.path.abspath(__file__))
        lat_file = os.path.join(base_dir, "latency_500.json")

        if os.path.exists(lat_file):
            print(f"\n  Loading dataset from latency_500.json...")
            dataset = MHLPDataset(
                data_files=[lat_file],
                hardware_names=["RTX4080"],
                normalize_latency=True
            )
            train_loader, val_loader, test_loader = create_dataloaders(
                dataset, batch_size=16
            )

            # Test train loop
            optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
            criterion = nn.MSELoss()

            print(f"\n  Running 3 training epochs...")
            for epoch in range(3):
                train_loss = train_one_epoch(
                    model, train_loader, optimizer, criterion, device, epoch
                )
                val_loss, val_mae, val_rmse = evaluate(
                    model, val_loader, criterion, device
                )
                print(f"    Epoch {epoch + 1}: "
                      f"train_loss={train_loss:.4f}, "
                      f"val_loss={val_loss:.4f}, "
                      f"val_mae={val_mae:.4f}, "
                      f"val_rmse={val_rmse:.4f}")
        else:
            print(f"  (Skipping DataLoader test - {lat_file} not found)")

    except ImportError as e:
        print(f"  (Skipping integration test: {e})")

    print(f"\n{'=' * 70}")
    print("  MHLP Model ready for training!")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    main()
