"""HyTra-CIFAR search-space paths.

This module mirrors the role of ``hytra_paths.py`` for the smaller CIFAR
variant.  Architectures are represented as 8 tuples:

    (block_type, scale_ratio)

where ``scale_ratio`` is relative to a 32x32 input image.
"""

from __future__ import annotations

import random
from typing import Any, Dict, List, Optional, Tuple


STAGE_DEPTHS_CIFAR: List[int] = [3, 3, 2]
WIDTH_MULTS_CIFAR: List[float] = [0.75, 1.0, 1.25]
DEFAULT_WIDTH_MULT_CIFAR: float = 1.0

OP_INDEX_TO_TUPLE_CIFAR: Dict[int, Tuple[str, float]] = {
    0: ("ResConv", 1.0),    # 32x32
    1: ("ResConv", 1 / 2),  # 16x16
    2: ("ResConv", 1 / 4),  # 8x8
    3: ("ResAtt",  1 / 4),  # 8x8
    4: ("ResConv", 1 / 8),  # 4x4
    5: ("ResAtt",  1 / 8),  # 4x4
}

TUPLE_TO_OP_INDEX_CIFAR: Dict[Tuple[str, float], int] = {
    value: key for key, value in OP_INDEX_TO_TUPLE_CIFAR.items()
}

S_RANK_CIFAR: Dict[int, List[int]] = {
    0: [0],
    1: [1],
    2: [2, 3],
    3: [4, 5],
}

RESATT_ALLOWED_SCALES_CIFAR = {1 / 4, 1 / 8}
VALID_BLOCK_SCALES_CIFAR: List[float] = [1.0, 1 / 2, 1 / 4, 1 / 8]


def round_channels_cifar(channels: int, width_mult: float) -> int:
    """Scale channels and round to a hardware-friendly multiple of 8."""
    return max(8, int(round(channels * width_mult / 8.0) * 8))


def normalize_hytra_cifar_arch(
    arch: Any,
    width_mult: Optional[float] = None,
) -> Tuple[List[Tuple[str, float]], float]:
    """Return ``(blocks, width_mult)`` from old or width-aware CIFAR formats."""
    if isinstance(arch, str):
        parsed = parse_hytra_cifar_arch_string(arch)
        blocks = parsed["blocks"]
        wm = parsed["width_mult"] if width_mult is None else width_mult
    elif isinstance(arch, dict):
        blocks = arch.get("blocks") or arch.get("arch") or arch.get("arch_tuples")
        wm = arch.get("width_mult", width_mult)
    else:
        blocks = arch
        wm = width_mult
    if blocks is None:
        raise ValueError("HyTra-CIFAR architecture is missing block tuples")
    wm = DEFAULT_WIDTH_MULT_CIFAR if wm is None else float(wm)
    if wm not in WIDTH_MULTS_CIFAR:
        raise ValueError(f"Unsupported HyTra-CIFAR width_mult={wm}; expected one of {WIDTH_MULTS_CIFAR}")
    return [(bt, float(scale)) for bt, scale in blocks], wm


def make_hytra_cifar_arch(
    blocks: List[Tuple[str, float]],
    width_mult: float = DEFAULT_WIDTH_MULT_CIFAR,
) -> Dict[str, Any]:
    blocks, width_mult = normalize_hytra_cifar_arch(blocks, width_mult)
    return {
        "blocks": blocks,
        "downsample_pattern": downsample_pattern_cifar(blocks),
        "width_mult": width_mult,
    }


def downsample_pattern_cifar(arch: Any) -> List[int]:
    blocks, _width_mult = normalize_hytra_cifar_arch(arch)
    pattern: List[int] = []
    cursor = 0
    for stage_depth in STAGE_DEPTHS_CIFAR:
        stage_scales = [scale for _bt, scale in blocks[cursor:cursor + stage_depth]]
        pattern.append(1 if min(stage_scales) < stage_scales[0] else 0)
        cursor += stage_depth
    return pattern


def hytra_cifar_arch_to_string(
    arch: Any,
    width_mult: Optional[float] = None,
) -> str:
    blocks, wm = normalize_hytra_cifar_arch(arch, width_mult)
    wm_str = f"{wm:.2f}".rstrip("0")
    if wm_str.endswith("."):
        wm_str += "0"
    parts = [f"wm={wm_str}"]
    parts.extend(f"{bt}@{scale:g}" for bt, scale in blocks)
    return "|".join(parts)


def parse_hytra_cifar_arch_string(arch_string: str) -> Dict[str, Any]:
    parts = arch_string.split("|")
    width_mult = DEFAULT_WIDTH_MULT_CIFAR
    if parts and parts[0].startswith("wm="):
        width_mult = float(parts[0].split("=", 1)[1])
        parts = parts[1:]
    blocks: List[Tuple[str, float]] = []
    for part in parts:
        block_type, scale = part.split("@")
        blocks.append((block_type, float(scale)))
    return make_hytra_cifar_arch(blocks, width_mult)


def _expand_depth_patterns(
    depth_patterns: List[List[int]],
) -> List[List[int]]:
    paths: List[List[int]] = []
    for depths in depth_patterns:
        stage_paths: List[List[int]] = [[]]
        for depth in depths:
            next_paths: List[List[int]] = []
            for prefix in stage_paths:
                for op in S_RANK_CIFAR[depth]:
                    next_paths.append(prefix + [op])
            stage_paths = next_paths
        paths.extend(stage_paths)
    return paths


# Each stage can keep its input resolution or take one stride-2 transition.
# The depth patterns are monotone non-decreasing because larger depth index
# means smaller spatial scale.
RESTRICTED_PATHS_CIFAR: Dict[int, List[List[int]]] = {
    0: _expand_depth_patterns([
        [0, 0, 0],
        [0, 0, 1],
        [0, 1, 1],
        [1, 1, 1],
    ]),
    1: _expand_depth_patterns([
        [1, 1, 1],
        [1, 1, 2],
        [1, 2, 2],
        [2, 2, 2],
    ]),
    2: _expand_depth_patterns([
        [2, 2],
        [2, 3],
        [3, 3],
    ]),
}


def op_indices_to_tuples_cifar(op_indices: List[List[int]]) -> List[Tuple[str, float]]:
    arch: List[Tuple[str, float]] = []
    for stage in op_indices:
        for op in stage:
            arch.append(OP_INDEX_TO_TUPLE_CIFAR[op])
    return arch


def tuples_to_op_indices_cifar(arch: Any) -> List[List[int]]:
    arch, _width_mult = normalize_hytra_cifar_arch(arch)
    if len(arch) != sum(STAGE_DEPTHS_CIFAR):
        raise ValueError(f"HyTra-CIFAR architecture must have 8 blocks, got {len(arch)}")
    out: List[List[int]] = []
    cursor = 0
    for depth in STAGE_DEPTHS_CIFAR:
        stage_ops = []
        for item in arch[cursor:cursor + depth]:
            stage_ops.append(TUPLE_TO_OP_INDEX_CIFAR[item])
        out.append(stage_ops)
        cursor += depth
    return out


def generate_random_hytra_cifar(seed: Optional[int] = None) -> Dict[str, Any]:
    """Generate one valid HyTra-CIFAR architecture."""
    rng = random.Random(seed) if seed is not None else random
    op_indices: List[List[int]] = []
    for stage_idx in range(len(STAGE_DEPTHS_CIFAR)):
        op_indices.append(list(rng.choice(RESTRICTED_PATHS_CIFAR[stage_idx])))
    return make_hytra_cifar_arch(
        op_indices_to_tuples_cifar(op_indices),
        width_mult=rng.choice(WIDTH_MULTS_CIFAR),
    )


def count_resatt_cifar(arch: Any) -> int:
    arch, _width_mult = normalize_hytra_cifar_arch(arch)
    return sum(1 for block_type, _scale in arch if block_type == "ResAtt")


def _verify() -> None:
    arch = generate_random_hytra_cifar(seed=7)
    blocks, width_mult = normalize_hytra_cifar_arch(arch)
    arch_string = hytra_cifar_arch_to_string(arch)
    parsed = parse_hytra_cifar_arch_string(arch_string)
    assert len(blocks) == 8
    assert width_mult in WIDTH_MULTS_CIFAR
    assert hytra_cifar_arch_to_string(parsed) == arch_string
    assert all(bt in {"ResConv", "ResAtt"} for bt, _ in blocks)
    assert all(scale in VALID_BLOCK_SCALES_CIFAR for _, scale in blocks)
    assert all(scale in RESATT_ALLOWED_SCALES_CIFAR for bt, scale in blocks if bt == "ResAtt")
    assert sum(len(paths) for paths in RESTRICTED_PATHS_CIFAR.values()) > 0
    print("HyTra-CIFAR paths OK:", arch_string, "ResAtt blocks:", count_resatt_cifar(arch))


if __name__ == "__main__":
    _verify()
