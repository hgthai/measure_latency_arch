#!/usr/bin/env python3
"""
Few-shot evaluation script cho MHLP trên unseen devices.

Usage:
    python eval_fewshot.py \
        --checkpoint results/meta_learning/mhlp_v3_metatrain.pth \
        --test_csv hytra_latency_metatest.csv \
        --shots 5 10 20 50 \
        --fine_tune_steps 100 \
        --out_dir results/eval
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import random
from typing import Dict, List, Tuple

import numpy as np
import torch
import torch.nn as nn
from scipy.stats import kendalltau
from torch.utils.data import DataLoader, TensorDataset

import sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from hytra_encoding import encode_hytra_dag, encode_hardware, HW_ENCODING_DIM
from mhlp_predictor import MHLPPredictor


# ── Helpers ──────────────────────────────────────────────────────────────────

def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def parse_arch_tuples(arch_string: str) -> List[Tuple[str, float]]:
    pairs = []
    for token in arch_string.split("|"):
        op, scale_s = token.split("@")
        pairs.append((op, float(scale_s)))
    return pairs


def load_test_csv(csv_path: str) -> Dict[str, List[dict]]:
    """Load CSV và group theo hardware_type."""
    groups: Dict[str, List[dict]] = {}
    with open(csv_path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            hw = row["hardware_type"]
            if hw not in groups:
                groups[hw] = []
            groups[hw].append({
                "arch_string": row["architecture_string"],
                "latency_ms": float(row["latency_ms"]),
            })
    for hw, rows in groups.items():
        print(f"  {hw}: {len(rows)} samples")
    return groups


def build_tensors(
    rows: List[dict],
    hw_vec: torch.Tensor,
    lat_mean: float,
    lat_std: float,
) -> TensorDataset:
    """Convert list of dicts → TensorDataset."""
    X_list, A_list, H_list, Y_list = [], [], [], []
    for row in rows:
        arch_tuples = parse_arch_tuples(row["arch_string"])
        X_np, A_np = encode_hytra_dag(arch_tuples)
        y_norm = (row["latency_ms"] - lat_mean) / max(lat_std, 1e-8)
        X_list.append(torch.tensor(X_np, dtype=torch.float32))
        A_list.append(torch.tensor(A_np, dtype=torch.float32))
        H_list.append(hw_vec)
        Y_list.append(torch.tensor([y_norm], dtype=torch.float32))

    return TensorDataset(
        torch.stack(X_list),
        torch.stack(A_list),
        torch.stack(H_list),
        torch.stack(Y_list),
    )


def load_model(checkpoint_path: str, config_path: str, device: torch.device) -> MHLPPredictor:
    """Load model từ checkpoint."""
    with open(config_path) as f:
        cfg = json.load(f)

    model = MHLPPredictor(
        node_feat_dim=14,
        hw_input_dim=HW_ENCODING_DIM,
        gcn_hidden_dim=cfg.get("gcn_hidden", 128),
        mlp_hidden_dim=cfg.get("mlp_hidden", 64),
        embed_dim=cfg.get("embed_dim", 128),
        num_gcn_layers=cfg.get("num_gcn_layers", 3),
        num_attn_heads=cfg.get("num_attn_heads", 4),
        ffn_dim=cfg.get("ffn_dim", 512),
        predictor_hidden=cfg.get("predictor_hidden", 128),
        dropout=cfg.get("dropout", 0.1),
    ).to(device)

    ckpt = torch.load(checkpoint_path, map_location=device)
    model.load_state_dict(ckpt["model_state_dict"])
    print(f"  Loaded checkpoint: {checkpoint_path}")
    return model


def few_shot_adapt(
    meta_model: MHLPPredictor,
    support_rows: List[dict],
    hw_vec: torch.Tensor,
    lat_mean: float,
    lat_std: float,
    fine_tune_steps: int,
    inner_lr: float,
    device: torch.device,
) -> MHLPPredictor:
    """Fine-tune model trên support set (few shots)."""
    import copy
    adapted = copy.deepcopy(meta_model)
    adapted.train()

    support_ds = build_tensors(support_rows, hw_vec, lat_mean, lat_std)
    support_loader = DataLoader(
        support_ds,
        batch_size=min(len(support_rows), 16),
        shuffle=True,
    )

    optimizer = torch.optim.Adam(adapted.parameters(), lr=inner_lr)
    criterion = nn.MSELoss()

    step = 0
    while step < fine_tune_steps:
        for X, A, hw, y in support_loader:
            if step >= fine_tune_steps:
                break
            X, A, hw, y = X.to(device), A.to(device), hw.to(device), y.to(device)
            optimizer.zero_grad()
            pred = adapted(X, A, hw)
            loss = criterion(pred, y)
            loss.backward()
            optimizer.step()
            step += 1

    return adapted


def evaluate(
    model: MHLPPredictor,
    query_rows: List[dict],
    hw_vec: torch.Tensor,
    lat_mean: float,
    lat_std: float,
    device: torch.device,
) -> Dict[str, float]:
    """Đánh giá model trên query set, trả về metrics."""
    model.eval()
    query_ds = build_tensors(query_rows, hw_vec, lat_mean, lat_std)
    query_loader = DataLoader(query_ds, batch_size=64, shuffle=False)

    preds_norm, gts_norm = [], []
    with torch.no_grad():
        for X, A, hw, y in query_loader:
            X, A, hw = X.to(device), A.to(device), hw.to(device)
            pred = model(X, A, hw)
            preds_norm.extend(pred.squeeze(-1).cpu().tolist())
            gts_norm.extend(y.squeeze(-1).tolist())

    preds_norm = np.array(preds_norm)
    gts_norm = np.array(gts_norm)

    # Denormalize → ms
    preds_ms = preds_norm * lat_std + lat_mean
    gts_ms = gts_norm * lat_std + lat_mean

    # Metrics
    tau, _ = kendalltau(preds_ms, gts_ms)
    mape = float(100.0 * np.mean(np.abs((preds_ms - gts_ms) / np.maximum(np.abs(gts_ms), 1e-8))))
    acc10 = float(np.mean(np.abs(preds_ms - gts_ms) / np.maximum(np.abs(gts_ms), 1e-8) < 0.10) * 100)
    acc5  = float(np.mean(np.abs(preds_ms - gts_ms) / np.maximum(np.abs(gts_ms), 1e-8) < 0.05) * 100)
    rmse  = float(np.sqrt(np.mean((preds_ms - gts_ms) ** 2)))

    return {
        "kendall_tau": float(tau),
        "mape": mape,
        "acc@5%": acc5,
        "acc@10%": acc10,
        "rmse": rmse,
        "n_query": len(query_rows),
    }


# ── Main ─────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    p.add_argument("--checkpoint", required=True, help="Path to .pth checkpoint")
    p.add_argument("--config",     default=None,  help="Path to config JSON (auto-detect nếu None)")
    p.add_argument("--test_csv",   required=True, help="Path to meta-test CSV")
    p.add_argument("--train_csv",  required=True, help="Path to meta-train CSV (để tính lat_mean/std)")
    p.add_argument("--shots",      nargs="+", type=int, default=[5, 10, 20, 50])
    p.add_argument("--fine_tune_steps", type=int, default=100)
    p.add_argument("--inner_lr",   type=float, default=0.01)
    p.add_argument("--seed",       type=int,   default=42)
    p.add_argument("--out_dir",    type=str,   default="results/eval")
    return p.parse_args()


def main():
    args = parse_args()
    set_seed(args.seed)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    # Auto-detect config path
    if args.config is None:
        config_path = args.checkpoint.replace(".pth", "_config.json")
    else:
        config_path = args.config

    # Load normalization stats từ train CSV
    train_lats = []
    with open(args.train_csv, newline="") as f:
        for row in csv.DictReader(f):
            train_lats.append(float(row["latency_ms"]))
    lat_mean = float(np.mean(train_lats))
    lat_std  = float(np.std(train_lats))
    print(f"Normalization: mean={lat_mean:.4f}, std={lat_std:.4f}")

    # Load test data
    print("\nLoading test data...")
    test_groups = load_test_csv(args.test_csv)

    # Load meta model
    print("\nLoading model...")
    meta_model = load_model(args.checkpoint, config_path, device)

    os.makedirs(args.out_dir, exist_ok=True)
    all_results = {}

    # Eval từng device
    for hw_name, rows in test_groups.items():
        print(f"\n{'='*60}")
        print(f"  Evaluating: {hw_name} ({len(rows)} samples)")
        print(f"{'='*60}")

        hw_vec = encode_hardware(hw_name).to(device)
        results_per_shots = {}

        for n_shots in args.shots:
            if n_shots >= len(rows):
                print(f"  [SKIP] n_shots={n_shots} >= total samples")
                continue

            # PDWRS-style: chọn support set đều theo latency distribution
            sorted_rows = sorted(rows, key=lambda r: r["latency_ms"])
            step = len(sorted_rows) // n_shots
            support_rows = [sorted_rows[i * step] for i in range(n_shots)]
            support_set = set(r["arch_string"] for r in support_rows)
            query_rows = [r for r in rows if r["arch_string"] not in support_set]

            # Adapt
            adapted = few_shot_adapt(
                meta_model=meta_model,
                support_rows=support_rows,
                hw_vec=hw_vec,
                lat_mean=lat_mean,
                lat_std=lat_std,
                fine_tune_steps=args.fine_tune_steps,
                inner_lr=args.inner_lr,
                device=device,
            )

            # Evaluate
            metrics = evaluate(adapted, query_rows, hw_vec, lat_mean, lat_std, device)
            results_per_shots[n_shots] = metrics

            print(f"  shots={n_shots:3d} | "
                  f"KTau={metrics['kendall_tau']:.4f} | "
                  f"MAPE={metrics['mape']:.2f}% | "
                  f"Acc@10%={metrics['acc@10%']:.1f}% | "
                  f"Acc@5%={metrics['acc@5%']:.1f}%")

        all_results[hw_name] = results_per_shots

    # Save results
    out_path = os.path.join(args.out_dir, "fewshot_eval.json")
    with open(out_path, "w") as f:
        json.dump(all_results, f, indent=2)

    # Print summary table
    print(f"\n{'='*60}")
    print("  SUMMARY")
    print(f"{'='*60}")
    print(f"{'Device':<20} {'Shots':<8} {'KTau':<10} {'MAPE':<10} {'Acc@10%'}")
    print("-" * 60)
    for hw_name, shots_dict in all_results.items():
        for n_shots, m in shots_dict.items():
            print(f"{hw_name:<20} {n_shots:<8} "
                  f"{m['kendall_tau']:<10.4f} "
                  f"{m['mape']:<10.2f} "
                  f"{m['acc@10%']:.1f}%")

    print(f"\nResults saved: {out_path}")


if __name__ == "__main__":
    main()