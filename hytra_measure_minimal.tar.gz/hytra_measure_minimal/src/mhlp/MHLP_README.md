# MHLP — Multihardware Adaptive Latency Prediction

<p align="center">
  <b>Khóa luận tốt nghiệp Đại học — Ngành Trí tuệ Nhân tạo / Khoa học Máy tính</b>
</p>

> **Đề tài:** Ứng dụng mô hình MHLP (Multihardware Adaptive Latency Prediction) trong Hardware‑aware Neural Architecture Search (NAS)

---

## 1. Giới thiệu

Trong lĩnh vực Neural Architecture Search (NAS), việc đánh giá hiệu năng thực tế (inference latency) trên các nền tảng phần cứng khác nhau là cực kỳ tốn kém về thời gian. Mỗi kiến trúc ứng viên cần được biên dịch, triển khai và đo đạc trực tiếp trên từng thiết bị — quy trình này không thể mở rộng khi không gian tìm kiếm chứa hàng triệu kiến trúc.

**MHLP (Multihardware Adaptive Latency Prediction)** giải quyết vấn đề này bằng cách xây dựng một mô hình dự đoán độ trễ (latency predictor) có khả năng:
- Nhận đầu vào là **cấu trúc kiến trúc mạng** (dưới dạng đồ thị DAG) và **đặc trưng phần cứng** (one-hot encoding)
- Dự đoán **inference latency** mà không cần đo đạc thực tế
- **Tổng quát hóa** sang các thiết bị phần cứng mới thông qua few-shot adaptation

### Nền tảng đo đạc thực nghiệm

| Thiết bị | Loại nền tảng | Kiến trúc chip | Vai trò |
|---|---|---|---|
| NVIDIA RTX 4080 | Desktop | GPU (CUDA) | Baseline — meta-training device |
| iPhone 15 | Mobile | NPU / GPU (Apple Neural Engine) | Unseen device — few-shot target |
| MacBook Pro M1 | Laptop | ARM SoC (Unified Memory) | Unseen device — few-shot target |

---

## 2. Kiến trúc hệ thống MHLP

```
┌─────────────────────────────────────────────────────────────────────┐
│                         MHLP PIPELINE                               │
│                                                                     │
│  ┌───────────────────┐        ┌──────────────────────┐             │
│  │  Dữ liệu đầu vào │        │  Dữ liệu đầu vào    │             │
│  │  KIẾN TRÚC MẠNG   │        │  PHẦN CỨNG           │             │
│  │  (4 stages × 4 ops│        │  (one-hot vector)    │             │
│  │   → DAG: X, A)    │        │                      │             │
│  └────────┬──────────┘        └──────────┬───────────┘             │
│           │                              │                          │
│           ▼                              ▼                          │
│  ┌─────────────────────┐    ┌──────────────────────┐               │
│  │  GCN Encoder         │    │  MLP Encoder          │              │
│  │  (3-layer GCN        │    │  (3-layer MLP         │              │
│  │   + BatchNorm        │    │   + LayerNorm)        │              │
│  │   + Residual         │    │                       │              │
│  │   + Global Pooling)  │    │  Input:  6 dims       │              │
│  │                      │    │  Output: 128 dims     │              │
│  │  Input:  (16, 9)     │    │                       │              │
│  │  Output: 128 dims    │    └──────────┬───────────┘              │
│  └────────┬─────────────┘               │                          │
│           │ arch_embedding               │ hw_embedding             │
│           │                              │                          │
│           └──────────┬───────────────────┘                          │
│                      │                                              │
│                      ▼                                              │
│           ┌──────────────────────────┐                              │
│           │  Feature Fusion Module    │                              │
│           │  (Multihead Attention)    │                              │
│           │                           │                              │
│           │  Tokens: [CLS, arch, hw]  │                              │
│           │  2-layer Transformer      │                              │
│           │  Encoder (4 heads, GELU)  │                              │
│           │                           │                              │
│           │  Output: CLS token → 128  │                              │
│           └──────────┬───────────────┘                              │
│                      │ fused_features                                │
│                      ▼                                              │
│           ┌──────────────────────────┐                              │
│           │  Latency Predictor       │                              │
│           │  (MLP Regressor)         │                              │
│           │  128 → 128 → 64 → 1     │                              │
│           └──────────┬───────────────┘                              │
│                      │                                              │
│                      ▼                                              │
│              predicted_latency (ms)                                  │
│                                                                     │
└─────────────────────────────────────────────────────────────────────┘
```

### Chi tiết các thành phần

| Thành phần | Module | Tham số | Mô tả |
|---|---|---|---|
| GCN Encoder | `NetworkArchitectureEncoder` | ~68K | 3-layer GCN với BatchNorm, residual connections, global mean+max pooling |
| MLP Encoder | `HardwareEncoder` | ~13K | 3-layer MLP với LayerNorm, mã hóa one-hot phần cứng |
| Feature Fusion | `FeatureFusionModule` | ~397K | 2-layer Transformer Encoder, [CLS] token, 4 attention heads |
| Predictor | `LatencyPredictor` | ~25K | MLP regressor, output scalar latency |
| **Tổng** | `MHLPModel` | **~504K** | End-to-end differentiable |

---

## 3. Cấu trúc thư mục dự án

```
MHLP-Thesis/
│
├── README.md                          ← Tài liệu chính (file này)
├── requirements.txt                   ← Danh sách thư viện Python
├── setup.py                           ← (Optional) Package setup
├── .gitignore                         ← Git ignore rules
├── LICENSE                            ← Giấy phép mã nguồn
│
├── data/                              ← THƯ MỤC DỮ LIỆU
│   ├── raw/                           ← Dữ liệu đo đạc thô (không chỉnh sửa)
│   │   ├── latency_rtx4080.json       ← Kết quả đo trên RTX 4080
│   │   ├── latency_ip15.json          ← Kết quả đo trên iPhone 15
│   │   ├── latency_macbook_m1.json    ← Kết quả đo trên MacBook M1
│   │   └── sampled_architectures.json ← Kiến trúc đã sample (PDWRS)
│   │
│   ├── processed/                     ← Dữ liệu đã tiền xử lý
│   │   ├── processed_mhlp_data.pt     ← Tensors (X, A, hw, latency)
│   │   └── train_val_test_split.json  ← Thông tin chia tập dữ liệu
│   │
│   └── simulated/                     ← Dữ liệu giả lập (nếu cần)
│       └── simulated_multi_device.json
│
├── src/                               ← MÃ NGUỒN CHÍNH
│   ├── __init__.py
│   │
│   ├── models/                        ← Định nghĩa mô hình
│   │   ├── __init__.py
│   │   ├── mhlp_model.py             ← MHLPModel (GCN + MLP + Attention)
│   │   ├── gcn_layers.py             ← Custom GCN Layer implementation
│   │   └── components.py             ← HardwareEncoder, FusionModule, Predictor
│   │
│   ├── data/                          ← Xử lý dữ liệu
│   │   ├── __init__.py
│   │   ├── preprocessing.py           ← encode_network(), encode_hardware()
│   │   ├── dataset.py                 ← MHLPDataset, create_dataloaders()
│   │   └── hardware_catalog.py        ← HARDWARE_CATALOG, encoding configs
│   │
│   └── utils/                         ← Tiện ích
│       ├── __init__.py
│       ├── metrics.py                 ← MAE, RMSE, MAPE, Spearman rank
│       ├── visualization.py           ← Plot functions
│       └── config.py                  ← Hyperparameter configurations
│
├── scripts/                           ← SCRIPTS THỰC THI
│   ├── 01_sample_architectures.py     ← Bước 1: Lấy mẫu kiến trúc (PDWRS)
│   ├── 02_measure_latency.py          ← Bước 2: Đo latency trên thiết bị
│   ├── 03_preprocess_data.py          ← Bước 3: Tiền xử lý & format dữ liệu
│   ├── 04_train.py                    ← Bước 4: Huấn luyện mô hình MHLP
│   ├── 05_evaluate.py                 ← Bước 5: Đánh giá trên tập test
│   ├── 06_predict.py                  ← Bước 6: Dự đoán latency cho kiến trúc mới
│   └── 07_few_shot_adapt.py           ← Bước 7: Few-shot trên unseen device
│
├── notebooks/                         ← JUPYTER NOTEBOOKS
│   ├── 01_EDA_latency_data.ipynb      ← Khám phá & phân tích dữ liệu
│   ├── 02_model_architecture.ipynb    ← Trực quan hóa kiến trúc MHLP
│   ├── 03_training_analysis.ipynb     ← Phân tích quá trình training
│   ├── 04_evaluation_results.ipynb    ← Biểu đồ kết quả đánh giá
│   └── 05_thesis_feasibility.ipynb    ← Phân tích tính khả thi KLTN
│
├── configs/                           ← CẤU HÌNH THÍ NGHIỆM
│   ├── default.yaml                   ← Cấu hình mặc định
│   ├── rtx4080.yaml                   ← Cấu hình cho RTX 4080
│   └── few_shot.yaml                  ← Cấu hình few-shot adaptation
│
├── checkpoints/                       ← MÔ HÌNH ĐÃ TRAIN
│   ├── mhlp_best.pt                   ← Checkpoint tốt nhất
│   └── mhlp_final.pt                  ← Checkpoint cuối cùng
│
├── results/                           ← KẾT QUẢ THÍ NGHIỆM
│   ├── figures/                       ← Hình ảnh cho báo cáo
│   │   ├── training_curve.png
│   │   ├── prediction_scatter.png
│   │   └── attention_heatmap.png
│   └── tables/                        ← Bảng kết quả
│       └── comparison_table.csv
│
├── docs/                              ← TÀI LIỆU BÁO CÁO
│   ├── thesis/                        ← Bản báo cáo KLTN
│   │   ├── main.tex                   ← File LaTeX chính
│   │   ├── chapters/                  ← Các chương
│   │   ├── figures/                   ← Hình ảnh trong báo cáo
│   │   └── references.bib            ← Tài liệu tham khảo
│   ├── slides/                        ← Slide bảo vệ
│   │   └── defense_slides.pptx
│   └── proposal/                      ← Đề cương KLTN
│       └── proposal.pdf
│
└── tests/                             ← KIỂM THỬ ĐƠN VỊ
    ├── test_preprocessing.py
    ├── test_model.py
    └── test_dataset.py
```

---

## 4. Yêu cầu môi trường

### 4.1 Phiên bản Python

```
Python >= 3.10 (khuyến nghị 3.12)
```

### 4.2 Thư viện chính

```txt
# Core
torch>=2.0.0
torchvision>=0.15.0
numpy>=1.24.0
pandas>=2.0.0

# Visualization & Analysis
matplotlib>=3.7.0
seaborn>=0.12.0
jupyter>=1.0.0

# Utilities
tqdm>=4.65.0
pyyaml>=6.0
scikit-learn>=1.3.0

# (Optional) Graph Neural Network
# torch-geometric>=2.4.0    # Nếu muốn dùng PyG thay cho custom GCN

# (Optional) Experiment tracking
# wandb>=0.15.0
# tensorboard>=2.14.0
```

### 4.3 Cài đặt

```bash
# 1. Clone repository
git clone https://github.com/<username>/MHLP-Thesis.git
cd MHLP-Thesis

# 2. Tạo virtual environment
python -m venv venv
source venv/bin/activate  # Linux/Mac
# hoặc: venv\Scripts\activate  # Windows

# 3. Cài đặt dependencies
pip install -r requirements.txt

# 4. Kiểm tra PyTorch + CUDA
python -c "import torch; print(f'PyTorch {torch.__version__}, CUDA: {torch.cuda.is_available()}')"
```

---

## 5. Hướng dẫn chạy dự án (Step-by-Step)

### Bước 1: Lấy mẫu kiến trúc từ không gian tìm kiếm

```bash
# Lấy 500 kiến trúc đại diện bằng PDWRS (Probability Density-Weighted Random Sampling)
python scripts/01_sample_architectures.py \
    --num_samples 500 \
    --method pdwrs \
    --seed 42 \
    --output data/raw/sampled_architectures.json
```

**Output:** `data/raw/sampled_architectures.json` — chứa 500 kiến trúc HyTra (4 stages × 4 ops)

### Bước 2: Đo latency trên thiết bị nguồn

```bash
# Đo trên RTX 4080 (GPU)
python scripts/02_measure_latency.py \
    --input data/raw/sampled_architectures.json \
    --device cuda \
    --warmup 10 --runs 30 \
    --output data/raw/latency_rtx4080.json

# Đo trên MacBook M1 (MPS backend)
python scripts/02_measure_latency.py \
    --input data/raw/sampled_architectures.json \
    --device mps \
    --output data/raw/latency_macbook_m1.json

# Đo trên iPhone 15 (CoreML export + benchmark)
python scripts/02_measure_latency.py \
    --input data/raw/sampled_architectures.json \
    --device coreml \
    --output data/raw/latency_ip15.json
```

**Output:** `data/raw/latency_<device>.json` — file JSON chứa latency từng kiến trúc

### Bước 3: Tiền xử lý và format dữ liệu

```bash
# Format dữ liệu thô → tensors PyTorch
python scripts/03_preprocess_data.py \
    --data_files data/raw/latency_rtx4080.json \
                 data/raw/latency_ip15.json \
                 data/raw/latency_macbook_m1.json \
    --hardware_names RTX4080 ip15 Macbook_M1 \
    --output data/processed/processed_mhlp_data.pt

# Hoặc sử dụng chế độ simulate (dữ liệu giả lập đa thiết bị)
python scripts/03_preprocess_data.py --simulate \
    --output data/processed/processed_mhlp_data.pt
```

**Quy trình tiền xử lý:**
1. **Hardware Encoding:** One-hot vector 6 chiều = Platform (3) + Architecture Type (3)
2. **Network Encoding:** DAG → X (16×9 node features) + A (16×16 adjacency matrix)
3. **Normalization:** Z-score normalization cho latency
4. **Output:** `.pt` file chứa tensors sẵn sàng cho training

### Bước 4: Huấn luyện mô hình MHLP

```bash
python scripts/04_train.py \
    --data data/processed/processed_mhlp_data.pt \
    --epochs 200 \
    --batch_size 32 \
    --lr 1e-3 \
    --weight_decay 1e-4 \
    --checkpoint_dir checkpoints/
```

**Hyperparameters mặc định:**

| Tham số | Giá trị | Mô tả |
|---|---|---|
| Optimizer | AdamW | Adaptive learning rate + weight decay |
| Learning rate | 1e-3 | Giảm dần theo CosineAnnealing |
| Batch size | 32 | |
| Epochs | 200 | Early stopping với patience=20 |
| GCN layers | 3 | Depth cho graph encoder |
| Attention heads | 4 | Multihead attention |
| Embed dim | 128 | Chiều embedding chung |
| Dropout | 0.1 | Regularization |

### Bước 5: Đánh giá mô hình (Evaluation)

```bash
python scripts/05_evaluate.py \
    --checkpoint checkpoints/mhlp_best.pt \
    --data data/processed/processed_mhlp_data.pt \
    --output results/
```

**Metrics đánh giá:**
- **MAE** (Mean Absolute Error): Sai số trung bình tuyệt đối
- **RMSE** (Root Mean Squared Error): Căn bậc hai sai số bình phương trung bình
- **MAPE** (Mean Absolute Percentage Error): Sai số phần trăm
- **Spearman ρ** (Rank Correlation): Tương quan thứ hạng (quan trọng cho NAS)

### Bước 6: Dự đoán latency cho kiến trúc mới

```bash
python scripts/06_predict.py \
    --checkpoint checkpoints/mhlp_best.pt \
    --arch "[[4,2,2,3],[4,4,2,3],[2,3,3,1],[3,3,0,0]]" \
    --hardware RTX4080
```

---

## 6. Tổ chức mã nguồn

### File chính

| File | Mô tả |
|---|---|
| `src/models/mhlp_model.py` | Định nghĩa `MHLPModel` (nn.Module) hoàn chỉnh |
| `src/models/gcn_layers.py` | Custom `GCNLayer` — không phụ thuộc torch_geometric |
| `src/data/preprocessing.py` | `encode_network()`, `encode_hardware()` |
| `src/data/dataset.py` | `MHLPDataset` (PyTorch Dataset) + `create_dataloaders()` |
| `scripts/04_train.py` | Script huấn luyện chính |
| `scripts/05_evaluate.py` | Script đánh giá + visualization |

### Mã hóa dữ liệu

**Hardware Encoding (one-hot, 6 dims):**

| Thiết bị | Platform | Arch Type | Vector |
|---|---|---|---|
| RTX 4080 | Desktop | GPU | `[1, 0, 0, 1, 0, 0]` |
| iPhone 15 | Mobile | NPU_GPU | `[0, 1, 0, 0, 1, 0]` |
| MacBook M1 | Laptop | ARM_SoC | `[0, 0, 1, 0, 0, 1]` |

**Network Encoding (DAG):**
- Mỗi kiến trúc = 4 stages × 4 operations = 16 nodes
- Node features (9 dims): op one-hot (6) + stage_pos (1) + layer_pos (1) + complexity (1)
- Adjacency: kết nối tuần tự trong stage + giữa stage + self-loops

---

## 7. Kết quả thực nghiệm (Placeholder)

> *Phần này sẽ được cập nhật sau khi hoàn thành huấn luyện.*

| Metric | RTX 4080 | iPhone 15 | MacBook M1 |
|---|---|---|---|
| MAE (ms) | — | — | — |
| RMSE (ms) | — | — | — |
| MAPE (%) | — | — | — |
| Spearman ρ | — | — | — |

---

## 8. Tài liệu tham khảo

1. Li, C., et al. **"BossNAS: Exploring Hybrid CNN-transformers with Block-wisely Self-supervised Neural Architecture Search."** ICCV 2021.
2. Dudziak, Ł., et al. **"BRP-NAS: Prediction-based NAS using GCNs."** NeurIPS 2020.
3. Lee, H., et al. **"Hardware-aware Neural Architecture Search: Survey and Taxonomy."** IJCAI 2021.
4. Kipf, T.N. & Welling, M. **"Semi-Supervised Classification with Graph Convolutional Networks."** ICLR 2017.
5. Vaswani, A., et al. **"Attention Is All You Need."** NeurIPS 2017.
6. White, C., et al. **"A Study on Encodings for Neural Architecture Search."** NeurIPS 2020.

---

## 9. Tác giả & Liên hệ

| Vai trò | Tên |
|---|---|
| Sinh viên thực hiện | *[Tên sinh viên]* |
| Giáo viên hướng dẫn | *[Tên GVHD]* |
| Đơn vị | *[Tên trường / Khoa]* |

---

<p align="center">
  <i>Khóa luận tốt nghiệp Đại học — 2025-2026</i>
</p>
