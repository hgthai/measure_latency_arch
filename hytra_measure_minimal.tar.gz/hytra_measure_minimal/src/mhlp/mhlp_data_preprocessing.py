"""
MHLP Data Preprocessing Pipeline
=================================

Nhiệm vụ 1: Format và tiền xử lý dữ liệu cho mô hình MHLP
(Multihardware Adaptive Latency Prediction).

Pipeline này thực hiện:
  1. Đọc dữ liệu đo latency thô từ file JSON
  2. Mã hóa phần cứng (Hardware Encoding) bằng one-hot encoding
  3. Mã hóa kiến trúc mạng (Network Encoding) dưới dạng DAG:
       - Ma trận đặc trưng node X (node feature matrix)
       - Ma trận kề A (adjacency matrix)
  4. Tạo PyTorch Dataset và DataLoader

Dữ liệu đầu vào: file JSON chứa kết quả đo latency với cấu trúc:
  {
    "results": [
      {
        "arch": [[op0, op1, op2, op3], ...],   # 4 stages × 4 ops
        "latency_ms": {"mean": ...},
        "params": ...,
        "complexity": ...
      }, ...
    ]
  }

Usage:
    /opt/tljh/user/bin/python mhlp_data_preprocessing.py \
        --data_files latency_rtx4080.json latency_ip15.json latency_macbook_m1.json \
        --hardware_names RTX4080 ip15 Macbook_M1 \
        --output processed_mhlp_data.pt

Author: MHLP Team
"""

import os
import sys
import json
import argparse
import numpy as np
import pandas as pd
from typing import Dict, List, Tuple, Optional

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader


# ============================================================================
# 1. Cấu hình không gian tìm kiếm HyTra
# ============================================================================

# 6 loại operation trong HyTra search space
NUM_OPS = 6
OP_NAMES = {
    0: "ResConv_s0",   # ResConv tại scale 0
    1: "ResConv_s1",   # ResConv tại scale 1
    2: "ResAtt_s0",    # Residual Attention scale 0
    3: "ResAtt_s1",    # Residual Attention scale 1
    4: "ResAtt_s2",    # Residual Attention scale 2
    5: "ResAtt_s3",    # Residual Attention scale 3 (heaviest)
}

NUM_STAGES = 4          # Số stage trong kiến trúc
OPS_PER_STAGE = 4       # Số layer/operation trong mỗi stage
TOTAL_NODES = NUM_STAGES * OPS_PER_STAGE  # 16 nodes tổng cộng


# ============================================================================
# 2. Hardware Encoding (Mã hóa phần cứng — MHLP paper-aligned 5D)
# ============================================================================

# Bảng phân loại phần cứng — MHLP Paper 5D encoding
# Vector: [is_desktop_cloud, is_mobile, has_cpu, has_gpu, has_asic_npu]
HARDWARE_CATALOG = {
    "RTX4080": {
        "is_desktop_cloud": 1, "is_mobile": 0,
        "has_cpu": 0, "has_gpu": 1, "has_asic_npu": 0,
        "description": "NVIDIA RTX 4080 - Desktop GPU with CUDA cores"
    },
    "ip15": {
        "is_desktop_cloud": 0, "is_mobile": 1,
        "has_cpu": 1, "has_gpu": 1, "has_asic_npu": 1,
        "description": "iPhone 15 - Mobile SoC (CPU + GPU + Apple Neural Engine)"
    },
    "Macbook_M1": {
        "is_desktop_cloud": 1, "is_mobile": 0,
        "has_cpu": 1, "has_gpu": 1, "has_asic_npu": 0,
        "description": "MacBook Pro M1 - Laptop ARM SoC (CPU + GPU, unified memory)"
    }
}

# Tên các chiều trong vector mã hóa phần cứng
HW_FEATURE_NAMES = [
    "is_desktop_cloud", "is_mobile",
    "has_cpu", "has_gpu", "has_asic_npu",
]

# Legacy aliases
PLATFORM_CLASSES = ["Desktop/Cloud", "Mobile"]
ARCH_TYPE_CLASSES = ["CPU", "GPU", "ASIC/NPU"]

# Tổng chiều dài vector mã hóa phần cứng = 5
HW_ENCODING_DIM = len(HW_FEATURE_NAMES)  # 5


def encode_hardware(hardware_name: str) -> np.ndarray:
    """
    Mã hóa phần cứng thành vector nhị phân 5 chiều (MHLP paper).

    Vector: [is_desktop_cloud, is_mobile, has_cpu, has_gpu, has_asic_npu]

    Mapping:
        "RTX4080"     -> [1, 0, 0, 1, 0]  Desktop + GPU
        "ip15"        -> [0, 1, 1, 1, 1]  Mobile + CPU + GPU + NPU
        "Macbook_M1"  -> [1, 0, 1, 1, 0]  Desktop/Laptop + CPU + GPU

    Args:
        hardware_name: Tên phần cứng (key trong HARDWARE_CATALOG)

    Returns:
        np.ndarray: Vector nhị phân kích thước (HW_ENCODING_DIM,) = (5,)
    """
    if hardware_name not in HARDWARE_CATALOG:
        raise ValueError(
            f"Unknown hardware: '{hardware_name}'. "
            f"Available: {list(HARDWARE_CATALOG.keys())}"
        )

    hw_info = HARDWARE_CATALOG[hardware_name]
    hw_vector = np.array(
        [float(hw_info[feat]) for feat in HW_FEATURE_NAMES],
        dtype=np.float32,
    )
    return hw_vector


def get_all_hardware_encodings() -> Dict[str, np.ndarray]:
    """
    Trả về dictionary mapping hardware_name -> one-hot vector
    cho toàn bộ phần cứng trong catalog.
    """
    encodings = {}
    for hw_name in HARDWARE_CATALOG:
        encodings[hw_name] = encode_hardware(hw_name)
    return encodings


# ============================================================================
# 3. Network Architecture Encoding (Mã hóa kiến trúc mạng dạng DAG)
# ============================================================================

def encode_network(arch_string: List[List[int]]) -> Tuple[np.ndarray, np.ndarray]:
    """
    Mã hóa một kiến trúc mạng (chuỗi kiến trúc) thành biểu diễn đồ thị DAG.

    Mỗi kiến trúc HyTra gồm 4 stages, mỗi stage có 4 operations.
    Tổng cộng 16 nodes trong đồ thị.

    Node Feature Matrix (X):
        Mỗi node có feature vector gồm:
        - One-hot encoding của operation type (6 dims)
        - Positional encoding: stage index normalized (1 dim)
        - Positional encoding: position within stage normalized (1 dim)
        - Complexity hint: op_value / (NUM_OPS - 1) normalized (1 dim)
        => Tổng: 6 + 1 + 1 + 1 = 9 dims per node

    Adjacency Matrix (A):
        Ma trận kề biểu diễn DAG (Directed Acyclic Graph):
        - Kết nối tuần tự trong mỗi stage: node_i -> node_{i+1}
        - Kết nối giữa các stage: last_node_of_stage_k -> first_node_of_stage_{k+1}
        - Self-loops cho mỗi node (để GCN aggregation bao gồm chính node đó)

    Args:
        arch_string: Chuỗi kiến trúc dạng list of lists,
                     ví dụ: [[4, 2, 2, 3], [4, 4, 2, 3], [2, 3, 3, 1], [3, 3, 0, 0]]

    Returns:
        X: np.ndarray shape (TOTAL_NODES, node_feature_dim) - ma trận đặc trưng node
        A: np.ndarray shape (TOTAL_NODES, TOTAL_NODES) - ma trận kề
    """
    assert len(arch_string) == NUM_STAGES, \
        f"Expected {NUM_STAGES} stages, got {len(arch_string)}"
    for stage in arch_string:
        assert len(stage) == OPS_PER_STAGE, \
            f"Expected {OPS_PER_STAGE} ops per stage, got {len(stage)}"

    node_feature_dim = NUM_OPS + 3  # 6 (one-hot) + 3 (positional + complexity)

    # ---- Xây dựng Node Feature Matrix X ----
    X = np.zeros((TOTAL_NODES, node_feature_dim), dtype=np.float32)

    for stage_idx, stage_ops in enumerate(arch_string):
        for pos_idx, op_id in enumerate(stage_ops):
            node_idx = stage_idx * OPS_PER_STAGE + pos_idx

            # (a) One-hot encoding cho operation type (6 dims)
            X[node_idx, op_id] = 1.0

            # (b) Stage position (normalized to [0, 1])
            X[node_idx, NUM_OPS] = stage_idx / (NUM_STAGES - 1)

            # (c) Position within stage (normalized to [0, 1])
            X[node_idx, NUM_OPS + 1] = pos_idx / (OPS_PER_STAGE - 1)

            # (d) Operation complexity hint (normalized)
            X[node_idx, NUM_OPS + 2] = op_id / (NUM_OPS - 1)

    # ---- Xây dựng Adjacency Matrix A (DAG) ----
    A = np.zeros((TOTAL_NODES, TOTAL_NODES), dtype=np.float32)

    for stage_idx in range(NUM_STAGES):
        base = stage_idx * OPS_PER_STAGE

        # Kết nối tuần tự trong mỗi stage: node_i -> node_{i+1}
        for i in range(OPS_PER_STAGE - 1):
            src = base + i
            dst = base + i + 1
            A[src, dst] = 1.0  # Cạnh có hướng: src -> dst

        # Kết nối giữa các stage: last_node_of_stage_k -> first_node_of_stage_{k+1}
        if stage_idx < NUM_STAGES - 1:
            last_node = base + OPS_PER_STAGE - 1
            first_next = (stage_idx + 1) * OPS_PER_STAGE
            A[last_node, first_next] = 1.0

    # Thêm self-loops (I) – cần thiết cho GCN aggregation
    A += np.eye(TOTAL_NODES, dtype=np.float32)

    return X, A


# ============================================================================
# 4. Đọc và Format dữ liệu thô
# ============================================================================

def load_raw_latency_data(
    data_files: List[str],
    hardware_names: List[str]
) -> pd.DataFrame:
    """
    Đọc nhiều file latency JSON (mỗi file tương ứng 1 hardware) và gộp thành
    một DataFrame thống nhất.

    Columns kết quả:
        - chuoi_kien_truc: list of lists (architecture encoding)
        - ten_phan_cung: str (hardware name)
        - do_tre_do_duoc: float (mean latency in ms)
        - complexity: float
        - params: int

    Args:
        data_files: Danh sách đường dẫn file JSON
        hardware_names: Danh sách tên phần cứng tương ứng

    Returns:
        pd.DataFrame với các cột đã format
    """
    assert len(data_files) == len(hardware_names), \
        "Số file dữ liệu phải bằng số tên phần cứng"

    all_rows = []

    for fpath, hw_name in zip(data_files, hardware_names):
        print(f"[INFO] Loading data from: {fpath} (hardware: {hw_name})")

        with open(fpath, 'r') as f:
            data = json.load(f)

        results = data.get("results", [])
        device_info = data.get("device_info", {})

        print(f"       Device: {device_info.get('gpu_name', device_info.get('platform', 'unknown'))}")
        print(f"       Num results: {len(results)}")

        for entry in results:
            row = {
                "chuoi_kien_truc": json.dumps(entry["arch"]),  # Serialize thành string để lưu trong DataFrame
                "ten_phan_cung": hw_name,
                "do_tre_do_duoc": entry["latency_ms"]["mean"],
                "complexity": entry.get("complexity", 0.0),
                "params": entry.get("params", 0),
                "arch_idx": entry.get("arch_idx", -1),
            }
            all_rows.append(row)

    df = pd.DataFrame(all_rows)
    print(f"\n[INFO] Total samples loaded: {len(df)}")
    print(f"[INFO] Hardware distribution:\n{df['ten_phan_cung'].value_counts().to_string()}")
    print(f"[INFO] Latency stats:\n{df['do_tre_do_duoc'].describe().to_string()}")

    return df


def preprocess_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Tiền xử lý DataFrame: thêm các cột encoding.

    Thêm cột:
        - hw_encoding: vector one-hot phần cứng (list of float)
        - node_features: serialized node feature matrix X
        - adjacency_matrix: serialized adjacency matrix A
    """
    print("\n[INFO] Preprocessing: encoding hardware and network architectures...")

    hw_encodings = []
    node_features_list = []
    adj_matrices_list = []

    for idx, row in df.iterrows():
        # Mã hóa phần cứng
        hw_vec = encode_hardware(row["ten_phan_cung"])
        hw_encodings.append(hw_vec.tolist())

        # Mã hóa kiến trúc mạng
        arch = json.loads(row["chuoi_kien_truc"])
        X, A = encode_network(arch)
        node_features_list.append(X.tolist())
        adj_matrices_list.append(A.tolist())

    df["hw_encoding"] = hw_encodings
    df["node_features"] = node_features_list
    df["adjacency_matrix"] = adj_matrices_list

    print(f"[INFO] Hardware encoding dim: {HW_ENCODING_DIM}")
    print(f"[INFO] Node feature dim: {NUM_OPS + 3}")
    print(f"[INFO] Adjacency matrix size: {TOTAL_NODES}x{TOTAL_NODES}")

    return df


# ============================================================================
# 5. PyTorch Dataset & DataLoader
# ============================================================================

class MHLPDataset(Dataset):
    """
    PyTorch Dataset cho MHLP.

    Mỗi sample trả về:
        - X:      torch.FloatTensor  (TOTAL_NODES, node_feature_dim)
                  Ma trận đặc trưng node
        - A:      torch.FloatTensor  (TOTAL_NODES, TOTAL_NODES)
                  Ma trận kề (adjacency matrix) của đồ thị DAG
        - hw:     torch.FloatTensor  (HW_ENCODING_DIM,)
                  Vector one-hot phần cứng
        - latency: torch.FloatTensor (1,)
                  Giá trị latency thực đo (target)
    """

    def __init__(
        self,
        data_files: Optional[List[str]] = None,
        hardware_names: Optional[List[str]] = None,
        dataframe: Optional[pd.DataFrame] = None,
        normalize_latency: bool = True
    ):
        """
        Khởi tạo dataset.

        Có thể khởi tạo bằng:
          (a) Cung cấp data_files + hardware_names để load từ JSON thô
          (b) Cung cấp dataframe đã tiền xử lý

        Args:
            data_files: Danh sách đường dẫn file JSON
            hardware_names: Danh sách tên phần cứng tương ứng
            dataframe: DataFrame đã preprocessed (ưu tiên nếu được cung cấp)
            normalize_latency: Có chuẩn hóa latency (z-score) hay không
        """
        if dataframe is not None:
            self.df = dataframe
        elif data_files is not None and hardware_names is not None:
            raw_df = load_raw_latency_data(data_files, hardware_names)
            self.df = preprocess_dataframe(raw_df)
        else:
            raise ValueError("Cần cung cấp data_files+hardware_names hoặc dataframe")

        # Chuyển đổi sang tensors
        self.node_features = []  # List of (TOTAL_NODES, feat_dim) tensors
        self.adj_matrices = []   # List of (TOTAL_NODES, TOTAL_NODES) tensors
        self.hw_vectors = []     # List of (HW_ENCODING_DIM,) tensors
        self.latencies = []      # List of scalar tensors

        for idx, row in self.df.iterrows():
            # Node features X
            X = torch.tensor(row["node_features"], dtype=torch.float32)
            self.node_features.append(X)

            # Adjacency matrix A
            A = torch.tensor(row["adjacency_matrix"], dtype=torch.float32)
            self.adj_matrices.append(A)

            # Hardware one-hot vector
            hw = torch.tensor(row["hw_encoding"], dtype=torch.float32)
            self.hw_vectors.append(hw)

            # Latency target
            lat = torch.tensor([row["do_tre_do_duoc"]], dtype=torch.float32)
            self.latencies.append(lat)

        # Stack để tính thống kê
        all_latencies = torch.cat(self.latencies)

        # Chuẩn hóa latency (z-score normalization)
        self.normalize_latency = normalize_latency
        self.latency_mean = all_latencies.mean().item()
        self.latency_std = all_latencies.std().item()

        if self.normalize_latency and self.latency_std > 1e-8:
            print(f"[INFO] Normalizing latency: mean={self.latency_mean:.4f}, std={self.latency_std:.4f}")
            self.latencies = [
                (lat - self.latency_mean) / self.latency_std
                for lat in self.latencies
            ]

        print(f"[INFO] Dataset created with {len(self)} samples")

    def __len__(self) -> int:
        return len(self.node_features)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor,
                                              torch.Tensor, torch.Tensor]:
        """
        Trả về một sample.

        Returns:
            X:       (TOTAL_NODES, node_feature_dim) - Node feature matrix
            A:       (TOTAL_NODES, TOTAL_NODES) - Adjacency matrix
            hw:      (HW_ENCODING_DIM,) - Hardware one-hot vector
            latency: (1,) - Target latency
        """
        return (
            self.node_features[idx],
            self.adj_matrices[idx],
            self.hw_vectors[idx],
            self.latencies[idx]
        )

    def denormalize_latency(self, normalized_lat: torch.Tensor) -> torch.Tensor:
        """Chuyển latency từ normalized về giá trị thực (ms)."""
        if self.normalize_latency and self.latency_std > 1e-8:
            return normalized_lat * self.latency_std + self.latency_mean
        return normalized_lat


def create_dataloaders(
    dataset: MHLPDataset,
    batch_size: int = 32,
    train_ratio: float = 0.8,
    val_ratio: float = 0.1,
    seed: int = 42,
    num_workers: int = 0
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Chia dataset thành Train/Val/Test và tạo DataLoader.

    Args:
        dataset: MHLPDataset instance
        batch_size: Kích thước batch
        train_ratio: Tỷ lệ tập train
        val_ratio: Tỷ lệ tập validation
        seed: Random seed
        num_workers: Số worker cho DataLoader

    Returns:
        (train_loader, val_loader, test_loader)
    """
    total = len(dataset)
    train_size = int(total * train_ratio)
    val_size = int(total * val_ratio)
    test_size = total - train_size - val_size

    print(f"\n[INFO] Splitting dataset: train={train_size}, val={val_size}, test={test_size}")

    generator = torch.Generator().manual_seed(seed)
    train_set, val_set, test_set = torch.utils.data.random_split(
        dataset, [train_size, val_size, test_size], generator=generator
    )

    train_loader = DataLoader(
        train_set, batch_size=batch_size, shuffle=True, num_workers=num_workers
    )
    val_loader = DataLoader(
        val_set, batch_size=batch_size, shuffle=False, num_workers=num_workers
    )
    test_loader = DataLoader(
        test_set, batch_size=batch_size, shuffle=False, num_workers=num_workers
    )

    print(f"[INFO] DataLoaders created (batch_size={batch_size})")
    print(f"       Train batches: {len(train_loader)}")
    print(f"       Val batches:   {len(val_loader)}")
    print(f"       Test batches:  {len(test_loader)}")

    return train_loader, val_loader, test_loader


# ============================================================================
# 6. Tiện ích: Simulation dữ liệu đa thiết bị (cho demo/testing)
# ============================================================================

def simulate_multi_device_data(
    arch_file: str = "sampled_500.json",
    latency_file: str = "latency_500.json",
    output_path: str = "simulated_multi_device.json"
) -> List[Dict]:
    """
    Tạo dữ liệu giả lập cho 3 thiết bị từ dữ liệu đo thực trên RTX 4080.

    Áp dụng hệ số chuyển đổi latency hợp lý:
        - RTX4080:     1.0x  (baseline)
        - ip15:        ~2.5-4.0x (mobile chậm hơn GPU)
        - Macbook_M1:  ~1.5-2.5x (ARM SoC hiệu quả nhưng chậm hơn RTX)

    Thêm noise ngẫu nhiên để giả lập sự biến thiên thực tế.

    Args:
        arch_file: Đường dẫn file kiến trúc sampled
        latency_file: Đường dẫn file latency đo từ RTX 4080
        output_path: Đường dẫn output

    Returns:
        List[Dict] chứa dữ liệu giả lập
    """
    base_dir = os.path.dirname(os.path.abspath(__file__))

    lat_path = os.path.join(base_dir, latency_file)
    with open(lat_path, 'r') as f:
        lat_data = json.load(f)

    results = lat_data["results"]
    np.random.seed(42)

    # Hệ số chuyển đổi latency cho mỗi thiết bị
    device_configs = {
        "RTX4080": {
            "scale_mean": 1.0,
            "scale_std": 0.05,
            "noise_std": 0.1,
        },
        "ip15": {
            "scale_mean": 3.2,
            "scale_std": 0.3,
            "noise_std": 0.5,
        },
        "Macbook_M1": {
            "scale_mean": 1.8,
            "scale_std": 0.15,
            "noise_std": 0.3,
        }
    }

    simulated = []
    for hw_name, cfg in device_configs.items():
        for entry in results:
            base_lat = entry["latency_ms"]["mean"]
            # Scale + noise
            scale = np.random.normal(cfg["scale_mean"], cfg["scale_std"])
            scale = max(scale, 0.5)  # Đảm bảo scale dương
            noise = np.random.normal(0, cfg["noise_std"])
            simulated_lat = base_lat * scale + noise
            simulated_lat = max(simulated_lat, 0.1)  # Đảm bảo latency dương

            simulated.append({
                "arch": entry["arch"],
                "ten_phan_cung": hw_name,
                "do_tre_do_duoc": simulated_lat,
                "complexity": entry.get("complexity", 0),
                "params": entry.get("params", 0),
            })

    # Lưu file
    out_path = os.path.join(base_dir, output_path)
    with open(out_path, 'w') as f:
        json.dump(simulated, f, indent=2)

    print(f"[INFO] Simulated {len(simulated)} samples for {len(device_configs)} devices")
    print(f"[INFO] Saved to: {out_path}")

    return simulated


# ============================================================================
# 7. Main: Chạy pipeline hoàn chỉnh
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="MHLP Data Preprocessing Pipeline"
    )
    parser.add_argument(
        "--data_files", nargs="+",
        help="Danh sách file JSON chứa latency measurements"
    )
    parser.add_argument(
        "--hardware_names", nargs="+",
        help="Tên phần cứng tương ứng với mỗi file"
    )
    parser.add_argument(
        "--simulate", action="store_true",
        help="Sử dụng dữ liệu giả lập đa thiết bị từ latency_500.json"
    )
    parser.add_argument(
        "--output", type=str, default="processed_mhlp_data.pt",
        help="Đường dẫn output file .pt"
    )
    parser.add_argument(
        "--batch_size", type=int, default=32,
        help="Batch size cho DataLoader"
    )
    parser.add_argument(
        "--no_normalize", action="store_true",
        help="Không chuẩn hóa latency"
    )
    args = parser.parse_args()

    base_dir = os.path.dirname(os.path.abspath(__file__))

    # ---- Bước A: Load & Format dữ liệu ----
    if args.simulate:
        # Chế độ simulate: tạo dữ liệu đa thiết bị từ file RTX 4080
        print("=" * 60)
        print(" MHLP Data Preprocessing - Simulate Mode")
        print("=" * 60)

        simulated = simulate_multi_device_data()

        # Chuyển simulated list thành DataFrame
        df = pd.DataFrame(simulated)
        df["chuoi_kien_truc"] = df["arch"].apply(json.dumps)
        df.rename(columns={"ten_phan_cung": "ten_phan_cung",
                           "do_tre_do_duoc": "do_tre_do_duoc"}, inplace=True)

        # Preprocess
        df = preprocess_dataframe(df)

    elif args.data_files and args.hardware_names:
        print("=" * 60)
        print(" MHLP Data Preprocessing - Multi-device Mode")
        print("=" * 60)

        # Resolve paths
        full_paths = []
        for fp in args.data_files:
            if not os.path.isabs(fp):
                fp = os.path.join(base_dir, fp)
            full_paths.append(fp)

        df = load_raw_latency_data(full_paths, args.hardware_names)
        df = preprocess_dataframe(df)

    else:
        print("=" * 60)
        print(" MHLP Data Preprocessing - Demo Mode (single device)")
        print("=" * 60)

        # Default: dùng latency_500.json với RTX4080
        default_file = os.path.join(base_dir, "latency_500.json")
        if os.path.exists(default_file):
            df = load_raw_latency_data([default_file], ["RTX4080"])
            df = preprocess_dataframe(df)
        else:
            print("[ERROR] No data files specified and default not found.")
            print("Usage: python mhlp_data_preprocessing.py --simulate")
            return

    # ---- Bước B: Tạo Dataset ----
    dataset = MHLPDataset(
        dataframe=df,
        normalize_latency=not args.no_normalize
    )

    # ---- Bước C: Tạo DataLoaders ----
    train_loader, val_loader, test_loader = create_dataloaders(
        dataset, batch_size=args.batch_size
    )

    # ---- Bước D: Verify một batch ----
    print("\n" + "=" * 60)
    print(" Verification: Sample Batch")
    print("=" * 60)

    for X, A, hw, latency in train_loader:
        print(f"  X (node features):     shape={X.shape}")      # (B, 16, 9)
        print(f"  A (adjacency matrix):  shape={A.shape}")      # (B, 16, 16)
        print(f"  hw (hardware one-hot): shape={hw.shape}")     # (B, 6)
        print(f"  latency (target):      shape={latency.shape}")  # (B, 1)
        print(f"\n  Sample hw vector:  {hw[0].tolist()}")
        print(f"  Sample latency:    {latency[0].item():.4f}")
        break

    # ---- Bước E: Lưu toàn bộ ----
    save_path = os.path.join(base_dir, args.output)
    save_dict = {
        "dataset_size": len(dataset),
        "node_feature_dim": NUM_OPS + 3,
        "num_nodes": TOTAL_NODES,
        "hw_encoding_dim": HW_ENCODING_DIM,
        "latency_mean": dataset.latency_mean,
        "latency_std": dataset.latency_std,
        "normalize_latency": dataset.normalize_latency,
        "node_features": torch.stack(dataset.node_features),
        "adj_matrices": torch.stack(dataset.adj_matrices),
        "hw_vectors": torch.stack(dataset.hw_vectors),
        "latencies": torch.stack(dataset.latencies),
    }
    torch.save(save_dict, save_path)
    print(f"\n[INFO] Saved processed data to: {save_path}")
    print(f"[INFO] Total size: {os.path.getsize(save_path) / 1024:.1f} KB")
    print("\nDone!")


if __name__ == "__main__":
    main()
