"""
MHLP Phase 2.2: Measure Latency on Target Device
================================================

Đo độ trễ thực tế của các kiến trúc đã sample trên thiết bị nguồn.
Script này sẽ:
1. Load các kiến trúc đã sample
2. Build model cho mỗi kiến trúc
3. Đo latency với warmup và nhiều lần chạy
4. Lưu kết quả để train MHLP

Usage:
    /opt/tljh/user/bin/python measure_latency.py --input sampled_architectures.json --device cuda
"""

import os
import sys
import json
import time
import argparse
from datetime import datetime
from tqdm import tqdm

# Add project paths
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'searching'))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'OpenSelfSup'))

import torch
import torch.nn as nn
import numpy as np


def get_device_info():
    """Thu thập thông tin về thiết bị."""
    info = {
        'platform': sys.platform,
        'python_version': sys.version,
        'pytorch_version': torch.__version__,
        'cuda_available': torch.cuda.is_available(),
    }
    
    if torch.cuda.is_available():
        info['cuda_version'] = torch.version.cuda
        info['gpu_name'] = torch.cuda.get_device_name(0)
        info['gpu_count'] = torch.cuda.device_count()
        info['gpu_memory_total'] = torch.cuda.get_device_properties(0).total_memory / 1e9
    
    return info


def build_hytra_block(stage_path, stage_idx, in_channels, out_channels, device):
    """
    Build một block của HyTra dựa trên path encoding.
    
    Args:
        stage_path: [op1, op2, op3, op4] - 4 ops per stage
        stage_idx: 0-3
        in_channels: input channels
        out_channels: output channels
        device: 'cuda' or 'cpu'
    
    Returns:
        nn.Module representing this stage
    """
    # Simplified HyTra block for latency measurement
    # Op 0-1: ResConv (lighter)
    # Op 2-3: ResConv with more channels
    # Op 4-5: Self-Attention (heavier)
    
    layers = []
    current_channels = in_channels
    
    for i, op in enumerate(stage_path):
        if op in [0, 1]:
            # ResConv - lightweight
            layers.append(nn.Sequential(
                nn.Conv2d(current_channels, out_channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True)
            ))
        elif op in [2, 3]:
            # ResConv - medium
            layers.append(nn.Sequential(
                nn.Conv2d(current_channels, out_channels * 2, 1, bias=False),
                nn.BatchNorm2d(out_channels * 2),
                nn.ReLU(inplace=True),
                nn.Conv2d(out_channels * 2, out_channels, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_channels),
                nn.ReLU(inplace=True)
            ))
        else:  # op in [4, 5]
            # Self-Attention - heavy
            layers.append(SelfAttentionBlock(current_channels, out_channels))
        
        current_channels = out_channels
    
    return nn.Sequential(*layers).to(device)


class SelfAttentionBlock(nn.Module):
    """Simplified self-attention block for latency measurement."""
    def __init__(self, in_channels, out_channels, num_heads=8):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_heads = num_heads
        
        # Project to out_channels if needed
        self.proj_in = nn.Conv2d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()
        
        # QKV projection
        self.qkv = nn.Conv2d(out_channels, out_channels * 3, 1)
        self.proj_out = nn.Conv2d(out_channels, out_channels, 1)
        self.norm = nn.BatchNorm2d(out_channels)
        
    def forward(self, x):
        B, C, H, W = x.shape
        x = self.proj_in(x)
        
        # Simple attention (flattened spatial)
        qkv = self.qkv(x)
        q, k, v = qkv.chunk(3, dim=1)
        
        # Reshape for attention
        q = q.view(B, self.num_heads, -1, H * W)
        k = k.view(B, self.num_heads, -1, H * W)
        v = v.view(B, self.num_heads, -1, H * W)
        
        # Attention
        attn = torch.softmax(q.transpose(-2, -1) @ k / (q.shape[-2] ** 0.5), dim=-1)
        out = (v @ attn).view(B, -1, H, W)
        
        out = self.proj_out(out)
        out = self.norm(out)
        
        return out


class HyTraLike(nn.Module):
    """
    Simplified HyTra-like model cho latency measurement.
    Không cần load full supernet, chỉ build kiến trúc cụ thể.
    """
    def __init__(self, arch, input_size=224, device='cuda'):
        super().__init__()
        self.arch = arch
        self.device = device
        
        # Stem (giống ResNet)
        self.stem = nn.Sequential(
            nn.Conv2d(3, 64, 7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(3, stride=2, padding=1)
        ).to(device)
        
        # Channel configs cho mỗi stage
        self.stage_channels = [
            (64, 256),    # Stage 0
            (256, 512),   # Stage 1
            (512, 1024),  # Stage 2
            (1024, 2048)  # Stage 3
        ]
        
        # Build stages
        self.stages = nn.ModuleList()
        for i, stage_path in enumerate(arch):
            in_c, out_c = self.stage_channels[i]
            stage = self._build_stage(stage_path, i, in_c, out_c)
            self.stages.append(stage)
        
        # Head
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(2048, 1000).to(device)
        
    def _build_stage(self, stage_path, stage_idx, in_channels, out_channels):
        """Build a stage based on path encoding."""
        layers = []
        current_c = in_channels
        
        # Downsample at the beginning of each stage (except stage 0)
        if stage_idx > 0:
            layers.append(nn.Sequential(
                nn.Conv2d(current_c, out_channels, 1, stride=2, bias=False),
                nn.BatchNorm2d(out_channels)
            ))
            current_c = out_channels
        
        for i, op in enumerate(stage_path):
            block = self._make_block(op, current_c, out_channels)
            layers.append(block)
            current_c = out_channels
            
        return nn.Sequential(*layers).to(self.device)
    
    def _make_block(self, op, in_c, out_c):
        """Create a block based on operation type."""
        if op in [0, 1]:
            # ResConv light
            return nn.Sequential(
                nn.Conv2d(in_c, out_c, 3, padding=1, bias=False),
                nn.BatchNorm2d(out_c),
                nn.ReLU(inplace=True)
            )
        elif op in [2, 3]:
            # ResConv medium (bottleneck)
            mid_c = out_c // 4
            return nn.Sequential(
                nn.Conv2d(in_c, mid_c, 1, bias=False),
                nn.BatchNorm2d(mid_c),
                nn.ReLU(inplace=True),
                nn.Conv2d(mid_c, mid_c, 3, padding=1, bias=False),
                nn.BatchNorm2d(mid_c),
                nn.ReLU(inplace=True),
                nn.Conv2d(mid_c, out_c, 1, bias=False),
                nn.BatchNorm2d(out_c),
                nn.ReLU(inplace=True)
            )
        else:  # op in [4, 5]
            # Attention block
            return SelfAttentionBlock(in_c, out_c)
    
    def forward(self, x):
        x = self.stem(x)
        for stage in self.stages:
            x = stage(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        x = self.fc(x)
        return x


def measure_latency(model, input_size, batch_size, device, 
                    warmup_runs=10, measure_runs=50):
    """
    Đo latency của model với GPU synchronization.
    
    Args:
        model: PyTorch model
        input_size: (C, H, W)
        batch_size: batch size
        device: 'cuda' or 'cpu'
        warmup_runs: số lần warmup
        measure_runs: số lần đo thực
    
    Returns:
        dict với mean, std, min, max latency (ms)
    """
    model.eval()
    
    # Create dummy input
    dummy_input = torch.randn(batch_size, *input_size).to(device)
    
    # Warmup
    with torch.no_grad():
        for _ in range(warmup_runs):
            _ = model(dummy_input)
            if device == 'cuda':
                torch.cuda.synchronize()
    
    # Measure
    latencies = []
    with torch.no_grad():
        for _ in range(measure_runs):
            if device == 'cuda':
                torch.cuda.synchronize()
                start = time.perf_counter()
                _ = model(dummy_input)
                torch.cuda.synchronize()
                end = time.perf_counter()
            else:
                start = time.perf_counter()
                _ = model(dummy_input)
                end = time.perf_counter()
            
            latencies.append((end - start) * 1000)  # Convert to ms
    
    latencies = np.array(latencies)
    
    return {
        'mean': float(np.mean(latencies)),
        'std': float(np.std(latencies)),
        'min': float(np.min(latencies)),
        'max': float(np.max(latencies)),
        'median': float(np.median(latencies)),
        'p95': float(np.percentile(latencies, 95)),
        'p99': float(np.percentile(latencies, 99))
    }


def measure_all_architectures(sampled_archs, device, batch_size=1, 
                              input_size=(3, 224, 224),
                              warmup_runs=10, measure_runs=50):
    """Đo latency cho tất cả các kiến trúc."""
    
    results = []
    failed = []
    
    print(f"\nMeasuring latency for {len(sampled_archs)} architectures...")
    print(f"Device: {device}, Batch size: {batch_size}")
    print(f"Input size: {input_size}")
    print(f"Warmup: {warmup_runs}, Measure runs: {measure_runs}")
    
    for i, arch_info in enumerate(tqdm(sampled_archs)):
        arch = arch_info['arch']
        
        try:
            # Build model
            model = HyTraLike(arch, input_size=input_size[1], device=device)
            model.eval()
            
            # Measure latency
            latency = measure_latency(
                model, input_size, batch_size, device,
                warmup_runs=warmup_runs, measure_runs=measure_runs
            )
            
            # Count parameters
            params = sum(p.numel() for p in model.parameters())
            
            result = {
                'arch_idx': i,
                'arch': arch,
                'complexity': arch_info.get('complexity', 0),
                'latency_ms': latency,
                'params': params,
                'device': device
            }
            results.append(result)
            
            # Cleanup
            del model
            if device == 'cuda':
                torch.cuda.empty_cache()
                
        except Exception as e:
            failed.append({
                'arch_idx': i,
                'arch': arch,
                'error': str(e)
            })
            print(f"\nFailed arch {i}: {e}")
    
    print(f"\nSuccessfully measured: {len(results)}")
    print(f"Failed: {len(failed)}")
    
    return results, failed


def main():
    parser = argparse.ArgumentParser(description='Measure HyTra architecture latency')
    parser.add_argument('--input', type=str, default='sampled_architectures.json',
                        help='Input file with sampled architectures')
    parser.add_argument('--output', type=str, default='latency_measurements.json',
                        help='Output file for latency results')
    parser.add_argument('--device', choices=['cuda', 'cpu'], default='cuda',
                        help='Device to measure on')
    parser.add_argument('--batch_size', type=int, default=1,
                        help='Batch size for measurement')
    parser.add_argument('--input_size', type=int, default=224,
                        help='Input image size')
    parser.add_argument('--warmup', type=int, default=10,
                        help='Warmup runs')
    parser.add_argument('--runs', type=int, default=50,
                        help='Measurement runs')
    parser.add_argument('--limit', type=int, default=None,
                        help='Limit number of architectures to measure (for testing)')
    
    args = parser.parse_args()
    
    print(f"\n{'='*60}")
    print("MHLP Phase 2.2: Latency Measurement")
    print(f"{'='*60}")
    
    # Get device info
    device_info = get_device_info()
    print(f"\n--- Device Information ---")
    for k, v in device_info.items():
        print(f"  {k}: {v}")
    
    # Load sampled architectures
    input_path = os.path.join(os.path.dirname(__file__), args.input)
    print(f"\nLoading architectures from: {input_path}")
    
    with open(input_path, 'r') as f:
        data = json.load(f)
    
    sampled_archs = data['architectures']
    print(f"Loaded {len(sampled_archs)} architectures")
    
    if args.limit:
        sampled_archs = sampled_archs[:args.limit]
        print(f"Limited to {len(sampled_archs)} architectures")
    
    # Measure latencies
    device = args.device
    if device == 'cuda' and not torch.cuda.is_available():
        print("CUDA not available, falling back to CPU")
        device = 'cpu'
    
    input_size = (3, args.input_size, args.input_size)
    
    results, failed = measure_all_architectures(
        sampled_archs,
        device=device,
        batch_size=args.batch_size,
        input_size=input_size,
        warmup_runs=args.warmup,
        measure_runs=args.runs
    )
    
    # Statistics
    if results:
        latencies = [r['latency_ms']['mean'] for r in results]
        print(f"\n--- Latency Statistics ---")
        print(f"  Min: {min(latencies):.2f} ms")
        print(f"  Max: {max(latencies):.2f} ms")
        print(f"  Mean: {np.mean(latencies):.2f} ms")
        print(f"  Std: {np.std(latencies):.2f} ms")
    
    # Save results
    output_data = {
        'timestamp': datetime.now().isoformat(),
        'device_info': device_info,
        'measurement_config': {
            'batch_size': args.batch_size,
            'input_size': list(input_size),
            'warmup_runs': args.warmup,
            'measure_runs': args.runs
        },
        'num_measured': len(results),
        'num_failed': len(failed),
        'results': results,
        'failed': failed
    }
    
    output_path = os.path.join(os.path.dirname(__file__), args.output)
    with open(output_path, 'w') as f:
        json.dump(output_data, f, indent=2)
    
    print(f"\nSaved results to: {output_path}")
    
    print(f"\n{'='*60}")
    print("NEXT STEP: Run train_mhlp.py to train the latency predictor")
    print(f"{'='*60}")


if __name__ == '__main__':
    main()
