"""
HyTra Architecture Encoding & Hardware Encoding for MHLP
=========================================================

Nhiệm vụ 1: Bộ mã hóa kiến trúc HyTra thành Đồ thị (HyTra → DAG Encoder)
Nhiệm vụ 2: Mã hóa phần cứng (Hardware Encoder)

Chuyển đổi mô tả kiến trúc HyTra (Hybrid CNN-Transformer) thành dạng đồ thị
(X, A) phù hợp cho mô hình MHLP (Multihardware Adaptive Latency Prediction).

Không gian HyTra từ BossNAS:
  - 4 stages × 4 layers = 16 choice blocks (fabric-like search space)
  - Toán tử: ResConv (CNN bottleneck), ResAtt (Transformer + PEG encoding)
  - Scales: 1/4 (56×56), 1/8 (28×28), 1/16 (14×14), 1/32 (7×7)
  - Ràng buộc: ResAtt chỉ xuất hiện ở scale 1/16 và 1/32
               (do self-attention O(n²) không khả thi với feature map lớn)
  - Path monotonicity: scale chỉ giảm hoặc giữ nguyên trong mỗi stage

Input format:
  arch = [('ResConv', 1/4), ('ResConv', 1/8), ..., ('ResAtt', 1/32)]
  Mỗi tuple: (block_type, scale_ratio), độ dài = 16

Output:
  X: Ma trận đặc trưng Node, shape (NUM_GRAPH_NODES, NODE_FEATURE_DIM)
  A: Ma trận kề (Adjacency Matrix), shape (NUM_GRAPH_NODES, NUM_GRAPH_NODES)

Usage:
    from hytra_encoding import encode_hytra_dag, encode_hardware
    X, A = encode_hytra_dag([('ResConv', 1/4), ..., ('ResAtt', 1/32)])
    hw = encode_hardware("RTX4080")

Author: MHLP Team — Khóa luận tốt nghiệp
"""

import os
import json
import numpy as np
from typing import Dict, List, Optional, Tuple, Union

import torch
from torch.utils.data import Dataset, DataLoader


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  1. CẤU HÌNH KHÔNG GIAN TÌM KIẾM HYTRA                               ║
# ║     (HyTra Search Space Configuration)                                 ║
# ╚══════════════════════════════════════════════════════════════════════════╝

# ── 1.1 Các loại block ứng viên ──────────────────────────────────────────
# ResConv: Residual Bottleneck CNN (1×1 → 3×3 → 1×1 conv, PEG, SE option)
# ResAtt:  Transformer Block (MHSA + PEG positional encoding + residual)
# Input:   Virtual source node (đại diện input image 224×224)
# Output:  Virtual sink node (đại diện classification head)
# Global:  Information hub node (kết nối tất cả, chuẩn hóa luồng thông tin)
BLOCK_TYPES: List[str] = ["ResConv", "ResAtt", "Input", "Output", "Global"]
NUM_BLOCK_TYPES: int = len(BLOCK_TYPES)  # 5

# ── 1.2 Các tỷ lệ scale ─────────────────────────────────────────────────
# Scale = tỷ lệ kích thước feature map so với input (224×224)
SCALE_VALUES: List[float] = [1.0, 1/4, 1/8, 1/16, 1/32]
NUM_SCALE_CLASSES: int = len(SCALE_VALUES)  # 5

# Bảng tra cứu chi tiết cho mỗi scale
SCALE_INFO: Dict[float, Dict] = {
    1.0:   {"fmap": 224, "channels": 64,   "label": "1 (224×224)",   "depth": -1},
    1/4:   {"fmap": 56,  "channels": 256,  "label": "1/4 (56×56)",   "depth": 3},
    1/8:   {"fmap": 28,  "channels": 512,  "label": "1/8 (28×28)",   "depth": 2},
    1/16:  {"fmap": 14,  "channels": 1024, "label": "1/16 (14×14)",  "depth": 1},
    1/32:  {"fmap": 7,   "channels": 2048, "label": "1/32 (7×7)",    "depth": 0},
}

# ── 1.3 Ràng buộc ResAtt ─────────────────────────────────────────────────
# ResAtt chỉ xuất hiện ở scale 1/16 (14×14) và 1/32 (7×7).
# Lý do: Self-attention có complexity O(n²) với n = H×W.
#   - 56×56 = 3,136 tokens → attention matrix 9.8M entries → quá lớn
#   - 28×28 = 784 tokens → 614K entries → vẫn quá lớn
#   - 14×14 = 196 tokens → 38K entries → chấp nhận được ✓
#   - 7×7 = 49 tokens → 2.4K entries → rất nhỏ ✓
RESATT_ALLOWED_SCALES: set = {1/16, 1/32}

# ── 1.4 Cấu trúc stages ─────────────────────────────────────────────────
NUM_STAGES: int = 4           # HyTra có 4 stages (tương ứng layer1-4)
LAYERS_PER_STAGE: int = 4     # Mỗi stage có 4 choice block layers
NUM_CHOICE_BLOCKS: int = NUM_STAGES * LAYERS_PER_STAGE  # 16

STAGE_NAMES: List[str] = ["Stage_0 (layer4)", "Stage_1 (layer3)",
                           "Stage_2 (layer2)", "Stage_3 (layer1)"]

# Stage depths: số mức scale khả dụng cho mỗi stage
# (Quyết định operations nào có thể xuất hiện trong stage đó)
# Stage 0: depth=4 → scales {1/32, 1/16, 1/8, 1/4} → ops {0,1,2,3,4,5}
# Stage 1: depth=3 → scales {1/32, 1/16, 1/8}      → ops {0,1,2,3,4}
# Stage 2: depth=2 → scales {1/32, 1/16}            → ops {0,1,2,3}
# Stage 3: depth=2 → scales {1/32, 1/16}            → ops {0,1,2,3}
STAGE_DEPTHS: List[int] = [4, 3, 2, 2]

# ── 1.5 BossNAS Op Index Mapping ─────────────────────────────────────────
# Trong code BossNAS (hytra_paths.py), mỗi operation-at-scale là một số nguyên.
# s_rank: depth index → danh sách op indices tại depth đó
# depth 0 (7×7, 2048ch):   ResAtt=0, ResConv=1
# depth 1 (14×14, 1024ch): ResAtt=2, ResConv=3
# depth 2 (28×28, 512ch):  ResConv=4 (ResAtt KHÔNG khả dụng)
# depth 3 (56×56, 256ch):  ResConv=5 (ResAtt KHÔNG khả dụng)
S_RANK: Dict[int, List[int]] = {0: [0, 1], 1: [2, 3], 2: [4], 3: [5]}

OP_INDEX_TO_TUPLE: Dict[int, Tuple[str, float]] = {
    0: ("ResAtt",  1/32),   # depth 0: Transformer block @ 7×7 feature map
    1: ("ResConv", 1/32),   # depth 0: CNN bottleneck @ 7×7 feature map
    2: ("ResAtt",  1/16),   # depth 1: Transformer block @ 14×14 feature map
    3: ("ResConv", 1/16),   # depth 1: CNN bottleneck @ 14×14 feature map
    4: ("ResConv", 1/8),    # depth 2: CNN bottleneck @ 28×28 feature map
    5: ("ResConv", 1/4),    # depth 3: CNN bottleneck @ 56×56 feature map
}

# ── 1.6 Cấu hình đồ thị DAG ─────────────────────────────────────────────
# Đồ thị bao gồm:
#   Node 0:     Input (virtual source — image input 224×224)
#   Nodes 1-16: 16 Choice Blocks (4 stages × 4 layers)
#   Node 17:    Output (virtual sink — classification head)
#   Node 18:    Global (information hub — kết nối tất cả nodes)
NUM_GRAPH_NODES: int = NUM_CHOICE_BLOCKS + 3  # 19

INPUT_NODE_IDX: int = 0
BLOCK_START_IDX: int = 1       # Blocks nằm ở indices 1 đến 16
BLOCK_END_IDX: int = 16        # (inclusive)
OUTPUT_NODE_IDX: int = 17
GLOBAL_NODE_IDX: int = 18

# ── 1.7 Node Feature Dimensions ──────────────────────────────────────────
# Cấu trúc vector đặc trưng cho mỗi node (14 chiều):
#
# ┌──────────────────────────────────────────────────────────────────────┐
# │ Dim 0-4:  Block type one-hot [ResConv, ResAtt, Input, Output, Global]│
# │ Dim 5:    Scale ratio (số học, e.g., 0.25 cho 1/4)                  │
# │ Dim 6-10: Scale one-hot [1, 1/4, 1/8, 1/16, 1/32]                  │
# │ Dim 11:   Stage index (chuẩn hóa [0, 1])                           │
# │ Dim 12:   Position in stage (chuẩn hóa [0, 1])                     │
# │ Dim 13:   ResAtt eligibility flag (1 nếu scale ∈ {1/16, 1/32})      │
# └──────────────────────────────────────────────────────────────────────┘
NODE_FEATURE_DIM: int = NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES + 3  # 14


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  2. HARDWARE ENCODING (Mã hóa phần cứng — Theo bài báo MHLP)          ║
# ╚══════════════════════════════════════════════════════════════════════════╝
#
# Bài báo MHLP: "Chúng tôi sử dụng kỹ thuật mã hóa one-hot đơn giản để
# phân biệt các loại nền tảng (đám mây/máy chủ vs. thiết bị di động) và
# các loại thiết bị cụ thể (CPU, GPU, FPGA, và ASIC). Nó cũng nắm bắt
# được các thiết kế không đồng nhất (heterogeneous) kết hợp giữa CPU và GPU."
#
# Vector mã hóa 5 chiều:
#   [is_desktop_cloud, is_mobile, has_cpu, has_gpu, has_asic_npu]
#
# ┌──────────────────────────────────────────────────────────────────────┐
# │ Dim 0: is_desktop_cloud  — Nền tảng máy bàn / đám mây / laptop     │
# │ Dim 1: is_mobile         — Nền tảng di động (smartphone, tablet)    │
# │ Dim 2: has_cpu           — Thiết bị có CPU tham gia inference       │
# │ Dim 3: has_gpu           — Thiết bị có GPU tham gia inference       │
# │ Dim 4: has_asic_npu      — Thiết bị có ASIC/NPU/Neural Engine      │
# └──────────────────────────────────────────────────────────────────────┘
#
# Thiết kế này cho phép mã hóa thiết bị heterogeneous:
#   - RTX4080:  chỉ GPU rời → [1, 0, 0, 1, 0]
#   - ip15:     SoC di động (CPU + GPU + ANE) → [0, 1, 1, 1, 1]
#   - Mac_M1:   SoC tích hợp laptop (CPU + GPU) → [1, 0, 1, 1, 0]

# Bảng phân loại phần cứng — MHLP Paper-aligned 5D encoding
HARDWARE_CATALOG: Dict[str, Dict] = {
    "RTX4080": {
        "is_desktop_cloud": 1,  # Desktop discrete GPU
        "is_mobile":        0,
        "has_cpu":          0,  # GPU-only inference (CUDA)
        "has_gpu":          1,
        "has_asic_npu":     0,
        "description": "NVIDIA RTX 4080 SUPER — Desktop discrete GPU (CUDA cores)",
        "compute": "Ada Lovelace, 10240 CUDA cores, 16GB GDDR6X",
    },
    "ip15": {
        "is_desktop_cloud": 0,
        "is_mobile":        1,  # Mobile SoC
        "has_cpu":          1,  # A16 Bionic CPU
        "has_gpu":          1,  # 5-core GPU
        "has_asic_npu":     1,  # Apple Neural Engine 16-core
        "description": "iPhone 15 — Mobile SoC (Apple A16 Bionic, ANE + GPU)",
        "compute": "Apple Neural Engine 16-core, 5-core GPU, 6-core CPU",
    },
    "Macbook_M1": {
        "is_desktop_cloud": 1,  # Desktop/Laptop
        "is_mobile":        0,
        "has_cpu":          1,  # 8-core ARM CPU
        "has_gpu":          1,  # 8-core integrated GPU
        "has_asic_npu":     0,  # Neural Engine có nhưng không dùng cho inference chính
        "description": "MacBook Pro M1 — Laptop ARM SoC (unified memory architecture)",
        "compute": "Apple M1, 8-core CPU + 8-core GPU + 16-core NE, 16GB unified",
    },
    "Xeon_Server_CPU": {
        "is_desktop_cloud": 1,
        "is_mobile":        0,
        "has_cpu":          1,
        "has_gpu":          0,
        "has_asic_npu":     0,
        "description": "Cloud/Server CPU-only inference profile (Xeon class)",
        "compute": "Multi-core x86 CPU, no GPU/NPU acceleration",
    },
    "Jetson_Orin_Edge": {
        "is_desktop_cloud": 1,
        "is_mobile":        0,
        "has_cpu":          1,
        "has_gpu":          1,
        "has_asic_npu":     1,
        "description": "Edge AI SoC profile (Jetson Orin class, CPU+GPU+NPU)",
        "compute": "Heterogeneous edge SoC with shared memory",
    },
    "Coral_Edge_TPU": {
        "is_desktop_cloud": 1,
        "is_mobile":        0,
        "has_cpu":          0,
        "has_gpu":          0,
        "has_asic_npu":     1,
        "description": "Edge TPU/ASIC acceleration profile",
        "compute": "ASIC/NPU-centric inference path",
    },
    "Snapdragon_8Gen3_Mobile": {
        "is_desktop_cloud": 0,
        "is_mobile":        1,
        "has_cpu":          1,
        "has_gpu":          1,
        "has_asic_npu":     0,
        "description": "Mobile SoC profile focused on CPU+GPU runtime",
        "compute": "Android flagship-class CPU+GPU pipeline",
    },
    "Dimensity_9200_NPU": {
        "is_desktop_cloud": 0,
        "is_mobile":        1,
        "has_cpu":          1,
        "has_gpu":          0,
        "has_asic_npu":     1,
        "description": "Mobile heterogeneous profile with CPU+NPU emphasis",
        "compute": "Mobile SoC path prioritizing NPU offloading",
    },
    "CortexA55_Mobile_CPU": {
        "is_desktop_cloud": 0,
        "is_mobile":        1,
        "has_cpu":          1,
        "has_gpu":          0,
        "has_asic_npu":     0,
        "description": "Mobile CPU-only low-power profile",
        "compute": "Entry-level ARM CPU inference without accelerators",
    },
    "Mobile_NPU_Lite": {
        "is_desktop_cloud": 0,
        "is_mobile":        1,
        "has_cpu":          0,
        "has_gpu":          0,
        "has_asic_npu":     1,
        "description": "Mobile NPU-dominant profile (minimal CPU/GPU involvement)",
        "compute": "Dedicated NPU execution profile",
    },
    "rtx3080": {
        "is_desktop_cloud": 1,
        "is_mobile":        0,
        "has_cpu":          0,
        "has_gpu":          1,
        "has_asic_npu":     0,
        "description": "NVIDIA RTX 3080 — Desktop discrete GPU",
        "compute": "Ampere, 8704 CUDA cores, 10GB GDDR6X",
    },
    "rtx4080": {
        "is_desktop_cloud": 1,
        "is_mobile":        0,
        "has_cpu":          0,
        "has_gpu":          1,
        "has_asic_npu":     0,
        "description": "NVIDIA RTX 4080 — Desktop discrete GPU",
        "compute": "Ada Lovelace, 9728 CUDA cores, 16GB GDDR6X",
    },
    "macbook_m1": {
        "is_desktop_cloud": 1,
        "is_mobile":        0,
        "has_cpu":          1,
        "has_gpu":          1,
        "has_asic_npu":     0,
        "description": "MacBook M1 — Laptop ARM SoC",
        "compute": "Apple M1, 8-core CPU + 8-core GPU",
    },
    "acer_nitro": {
        "is_desktop_cloud": 1,
        "is_mobile":        0,
        "has_cpu":          1,
        "has_gpu":          0,
        "has_asic_npu":     0,
        "description": "Acer Nitro 5 — Gaming laptop CPU inference",
        "compute": "Intel/AMD x86 CPU, Windows",
    },
    "asus_vivobook": {
        "is_desktop_cloud": 1,
        "is_mobile":        0,
        "has_cpu":          1,
        "has_gpu":          0,
        "has_asic_npu":     0,
        "description": "Asus Vivobook S14 — Thin and light laptop CPU",
        "compute": "Intel x86 CPU, Windows, low TDP",
    },
    "raspi4": {
        "is_desktop_cloud": 0,
        "is_mobile":        1,
        "has_cpu":          1,
        "has_gpu":          0,
        "has_asic_npu":     0,
        "description": "Raspberry Pi 4 — ARM edge device",
        "compute": "Cortex-A72 ARM CPU, 4GB RAM",
    },
}

# Tên các chiều trong vector mã hóa phần cứng (theo bài báo MHLP)
HW_FEATURE_NAMES: List[str] = [
    "is_desktop_cloud",
    "is_mobile",
    "has_cpu",
    "has_gpu",
    "has_asic_npu",
]

# Hỗ trợ alias tên thiết bị để tương thích dữ liệu/đặt tên khác nhau.
HARDWARE_NAME_ALIASES: Dict[str, str] = {
    "Mac_M1": "Macbook_M1",
    "MacM1": "Macbook_M1",
    "iphone15": "ip15",
    "iPhone15": "ip15",
}

# Tổng chiều dài vector mã hóa phần cứng = 5
HW_ENCODING_DIM: int = len(HW_FEATURE_NAMES)  # 5

# ── Legacy aliases (backward-compatibility) ──
PLATFORM_CLASSES: List[str] = ["Desktop/Cloud", "Mobile"]
ARCH_TYPE_CLASSES: List[str] = ["CPU", "GPU", "ASIC/NPU"]


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  3. KIỂM TRA TÍNH HỢP LỆ KIẾN TRÚC (Architecture Validation)         ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def validate_hytra_architecture(
    arch: List[Tuple[str, float]]
) -> Tuple[bool, List[str]]:
    """
    Kiểm tra tính hợp lệ của một kiến trúc HyTra.

    Các ràng buộc kiểm tra:
      1. Độ dài phải đúng bằng 16 (4 stages × 4 layers)
      2. Block type phải là 'ResConv' hoặc 'ResAtt'
      3. Scale ratio phải thuộc {1/4, 1/8, 1/16, 1/32}
      4. ResAtt chỉ được xuất hiện ở scale 1/16 hoặc 1/32

    Args:
        arch: Danh sách 16 tuples (block_type, scale_ratio)
              Ví dụ: [('ResConv', 1/4), ('ResAtt', 1/16), ...]

    Returns:
        (is_valid, errors): Tuple gồm flag hợp lệ và danh sách lỗi
    """
    errors: List[str] = []
    valid_block_types = {"ResConv", "ResAtt"}
    valid_scales = {1/4, 1/8, 1/16, 1/32}

    # Ràng buộc 1: Kiểm tra độ dài
    if len(arch) != NUM_CHOICE_BLOCKS:
        errors.append(
            f"[LEN] Kiến trúc phải có đúng {NUM_CHOICE_BLOCKS} blocks, "
            f"nhận được {len(arch)}"
        )
        return False, errors

    for i, (block_type, scale_ratio) in enumerate(arch):
        stage_idx = i // LAYERS_PER_STAGE
        pos_in_stage = i % LAYERS_PER_STAGE

        # Ràng buộc 2: Block type hợp lệ
        if block_type not in valid_block_types:
            errors.append(
                f"[BLOCK] Layer {i} (Stage {stage_idx}, Pos {pos_in_stage}): "
                f"block_type='{block_type}' không hợp lệ. "
                f"Chỉ chấp nhận: {valid_block_types}"
            )

        # Ràng buộc 3: Scale ratio hợp lệ
        if scale_ratio not in valid_scales:
            errors.append(
                f"[SCALE] Layer {i}: scale_ratio={scale_ratio} không hợp lệ. "
                f"Chỉ chấp nhận: {valid_scales}"
            )

        # Ràng buộc 4: ResAtt chỉ ở scale 1/16 và 1/32
        if block_type == "ResAtt" and scale_ratio not in RESATT_ALLOWED_SCALES:
            errors.append(
                f"[CONSTRAINT] Layer {i}: ResAtt không được phép ở scale "
                f"{scale_ratio}. ResAtt chỉ ở scales {RESATT_ALLOWED_SCALES}"
            )

    is_valid = len(errors) == 0
    return is_valid, errors


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  4. CHUYỂN ĐỔI TỪ BOSSNAS OP INDEX (Converter)                       ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def bossnas_to_tuples(
    op_indices: List[List[int]]
) -> List[Tuple[str, float]]:
    """
    Chuyển đổi từ định dạng BossNAS (op_index) sang định dạng tuple.

    Trong BossNAS, kiến trúc HyTra được biểu diễn dạng:
        [[op0, op1, op2, op3],  # Stage 0: 4 ops
         [op0, op1, op2, op3],  # Stage 1: 4 ops
         [op0, op1, op2, op3],  # Stage 2: 4 ops
         [op0, op1, op2, op3]]  # Stage 3: 4 ops

    Mỗi op_index ánh xạ:
        0 → ('ResAtt',  1/32)    1 → ('ResConv', 1/32)
        2 → ('ResAtt',  1/16)    3 → ('ResConv', 1/16)
        4 → ('ResConv', 1/8)     5 → ('ResConv', 1/4)

    Args:
        op_indices: List of lists, shape (4, 4), chứa op indices (0-5)

    Returns:
        List[Tuple[str, float]]: 16 tuples (block_type, scale_ratio)

    Raises:
        ValueError: Nếu op_index không hợp lệ

    Example:
        >>> bossnas_to_tuples([[4, 2, 2, 3], [4, 4, 2, 3],
        ...                    [2, 3, 3, 1], [3, 3, 0, 0]])
        [('ResConv', 0.125), ('ResAtt', 0.0625), ('ResAtt', 0.0625), ...]
    """
    if len(op_indices) != NUM_STAGES:
        raise ValueError(
            f"Cần {NUM_STAGES} stages, nhận được {len(op_indices)}"
        )

    tuples: List[Tuple[str, float]] = []

    for stage_idx, stage_ops in enumerate(op_indices):
        if len(stage_ops) != LAYERS_PER_STAGE:
            raise ValueError(
                f"Stage {stage_idx}: cần {LAYERS_PER_STAGE} ops, "
                f"nhận được {len(stage_ops)}"
            )

        # Xác định ops hợp lệ cho stage này
        max_depth = STAGE_DEPTHS[stage_idx]
        valid_ops = set()
        for depth in range(max_depth):
            valid_ops.update(S_RANK[depth])

        for pos, op_idx in enumerate(stage_ops):
            if op_idx not in OP_INDEX_TO_TUPLE:
                raise ValueError(
                    f"Stage {stage_idx}, Pos {pos}: "
                    f"op_index={op_idx} không tồn tại. "
                    f"Hợp lệ: {list(OP_INDEX_TO_TUPLE.keys())}"
                )
            if op_idx not in valid_ops:
                raise ValueError(
                    f"Stage {stage_idx}, Pos {pos}: "
                    f"op_index={op_idx} không khả dụng cho stage này. "
                    f"Stage {stage_idx} chỉ hỗ trợ: {sorted(valid_ops)}"
                )

            tuples.append(OP_INDEX_TO_TUPLE[op_idx])

    return tuples


def tuples_to_bossnas(
    arch: List[Tuple[str, float]]
) -> List[List[int]]:
    """
    Chuyển đổi ngược: từ tuple format → BossNAS op_index format.

    Args:
        arch: 16 tuples (block_type, scale_ratio)

    Returns:
        List[List[int]]: shape (4, 4), BossNAS op indices
    """
    # Inverse mapping
    tuple_to_op: Dict[Tuple[str, float], int] = {
        v: k for k, v in OP_INDEX_TO_TUPLE.items()
    }

    op_indices: List[List[int]] = []
    for stage_idx in range(NUM_STAGES):
        stage_ops: List[int] = []
        for pos in range(LAYERS_PER_STAGE):
            idx = stage_idx * LAYERS_PER_STAGE + pos
            block_type, scale = arch[idx]
            key = (block_type, scale)
            if key not in tuple_to_op:
                raise ValueError(f"Cannot map {key} to BossNAS op index")
            stage_ops.append(tuple_to_op[key])
        op_indices.append(stage_ops)

    return op_indices


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  5. NHIỆM VỤ 1: BỘ MÃ HÓA KIẾN TRÚC HYTRA → ĐỒ THỊ DAG            ║
# ║     (HyTra to DAG Encoder — Core Function)                            ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def encode_hytra_dag(
    arch: List[Tuple[str, float]],
    add_global_node: bool = True,
    validate: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Mã hóa kiến trúc HyTra thành biểu diễn đồ thị DAG: (X, A).

    ┌────────────────────────────────────────────────────────────────────┐
    │                    CẤU TRÚC ĐỒ THỊ DAG                           │
    │                                                                    │
    │  [Input]─→[B0]─→[B1]─→[B2]─→[B3]──→[B4]─→...─→[B15]─→[Output]  │
    │     │       │     │     │     │       │            │        │      │
    │     └───────┴─────┴─────┴─────┴───────┴────────────┴────────┘     │
    │                           ↕                                        │
    │                       [Global]                                     │
    │              (kết nối hai chiều với tất cả nodes)                  │
    └────────────────────────────────────────────────────────────────────┘

    Node Features (X): Mỗi node có vector 14 chiều gồm:
      - Block type one-hot (5d): [ResConv, ResAtt, Input, Output, Global]
      - Scale ratio numerical (1d): giá trị scale thực (e.g., 0.0625)
      - Scale one-hot (5d): [1, 1/4, 1/8, 1/16, 1/32]
      - Stage position normalized (1d): stage_idx / 3
      - Layer position normalized (1d): pos_in_stage / 3
      - ResAtt eligibility flag (1d): 1 nếu scale cho phép ResAtt

    Adjacency Matrix (A): Ma trận kề có hướng (DAG) gồm:
      - Kết nối tuần tự trong mỗi stage: B_i → B_{i+1}
      - Kết nối xuyên stage: B_{4k+3} → B_{4(k+1)} (last → first)
      - Input → B_0 (nguồn vào)
      - B_15 → Output (nguồn ra)
      - Global ↔ tất cả nodes (hai chiều, hub thông tin)
      - Self-loops trên mỗi node (cho GCN aggregation)

    Args:
        arch: Danh sách 16 tuples (block_type, scale_ratio)
              Ví dụ: [('ResConv', 1/4), ('ResAtt', 1/16), ...]
        add_global_node: Có thêm node Global hay không (default: True)
        validate: Có kiểm tra tính hợp lệ hay không (default: True)

    Returns:
        X: np.ndarray shape (NUM_GRAPH_NODES, NODE_FEATURE_DIM)
           Ma trận đặc trưng node. NUM_GRAPH_NODES=19, NODE_FEATURE_DIM=14
        A: np.ndarray shape (NUM_GRAPH_NODES, NUM_GRAPH_NODES)
           Ma trận kề (adjacency matrix) của đồ thị DAG

    Raises:
        ValueError: Nếu kiến trúc không hợp lệ
    """
    # ── Validation ──
    if validate:
        is_valid, errors = validate_hytra_architecture(arch)
        if not is_valid:
            raise ValueError(
                f"Kiến trúc HyTra không hợp lệ:\n" +
                "\n".join(f"  • {e}" for e in errors)
            )

    # ── Số nodes ──
    num_nodes = NUM_GRAPH_NODES if add_global_node else (NUM_GRAPH_NODES - 1)

    # ── Khởi tạo ma trận ──
    X = np.zeros((num_nodes, NODE_FEATURE_DIM), dtype=np.float32)
    A = np.zeros((num_nodes, num_nodes), dtype=np.float32)

    # ═══════════════════════════════════════════════════════════════════════
    # PHẦN A: Xây dựng Ma trận Đặc trưng Node X
    # ═══════════════════════════════════════════════════════════════════════

    # ── A1: Mã hóa node Input (node 0) ──
    # Input node đại diện cho ảnh đầu vào 224×224
    X[INPUT_NODE_IDX, BLOCK_TYPES.index("Input")] = 1.0   # one-hot: Input
    X[INPUT_NODE_IDX, NUM_BLOCK_TYPES] = 1.0               # scale = 1.0 (full)
    X[INPUT_NODE_IDX, NUM_BLOCK_TYPES + 1 + 0] = 1.0      # scale one-hot: 1
    X[INPUT_NODE_IDX, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES] = 0.0  # stage: 0
    X[INPUT_NODE_IDX, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES + 1] = 0.0  # pos: 0

    # ── A2: Mã hóa 16 Choice Block nodes (nodes 1-16) ──
    for i, (block_type, scale_ratio) in enumerate(arch):
        node_idx = BLOCK_START_IDX + i   # node index = i + 1
        stage_idx = i // LAYERS_PER_STAGE
        pos_in_stage = i % LAYERS_PER_STAGE

        # (a) Block type one-hot [5 dims]
        # ResConv → [1,0,0,0,0], ResAtt → [0,1,0,0,0]
        bt_idx = BLOCK_TYPES.index(block_type)
        X[node_idx, bt_idx] = 1.0

        # (b) Scale ratio numerical [1 dim]
        # Giá trị thực: 0.25 (1/4), 0.125 (1/8), 0.0625 (1/16), 0.03125 (1/32)
        X[node_idx, NUM_BLOCK_TYPES] = scale_ratio

        # (c) Scale one-hot [5 dims]
        # Tìm index trong SCALE_VALUES sử dụng tolerance cho floating point
        scale_idx = _find_scale_index(scale_ratio)
        X[node_idx, NUM_BLOCK_TYPES + 1 + scale_idx] = 1.0

        # (d) Stage index normalized [1 dim]
        # stage_idx ∈ {0, 1, 2, 3} → normalized ∈ [0.0, 1.0]
        X[node_idx, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES] = (
            stage_idx / (NUM_STAGES - 1)
        )

        # (e) Position within stage normalized [1 dim]
        # pos_in_stage ∈ {0, 1, 2, 3} → normalized ∈ [0.0, 1.0]
        X[node_idx, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES + 1] = (
            pos_in_stage / (LAYERS_PER_STAGE - 1)
        )

        # (f) ResAtt eligibility flag [1 dim]
        # = 1.0 nếu scale cho phép ResAtt (1/16 hoặc 1/32), ngược lại 0.0
        X[node_idx, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES + 2] = (
            1.0 if scale_ratio in RESATT_ALLOWED_SCALES else 0.0
        )

    # ── A3: Mã hóa node Output (node 17) ──
    # Output nhận output từ block cuối cùng
    last_scale = arch[-1][1]
    X[OUTPUT_NODE_IDX, BLOCK_TYPES.index("Output")] = 1.0     # one-hot: Output
    X[OUTPUT_NODE_IDX, NUM_BLOCK_TYPES] = last_scale           # scale = last block
    last_scale_idx = _find_scale_index(last_scale)
    X[OUTPUT_NODE_IDX, NUM_BLOCK_TYPES + 1 + last_scale_idx] = 1.0
    X[OUTPUT_NODE_IDX, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES] = 1.0      # stage: cuối
    X[OUTPUT_NODE_IDX, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES + 1] = 1.0  # pos: cuối

    # ── A4: Mã hóa node Global (node 18) — nếu có ──
    if add_global_node:
        X[GLOBAL_NODE_IDX, BLOCK_TYPES.index("Global")] = 1.0  # one-hot: Global
        X[GLOBAL_NODE_IDX, NUM_BLOCK_TYPES] = 0.5              # scale: neutral
        # Global không thuộc stage cụ thể nào → giá trị trung bình
        X[GLOBAL_NODE_IDX, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES] = 0.5
        X[GLOBAL_NODE_IDX, NUM_BLOCK_TYPES + 1 + NUM_SCALE_CLASSES + 1] = 0.5

    # ═══════════════════════════════════════════════════════════════════════
    # PHẦN B: Xây dựng Ma trận Kề A (Adjacency Matrix — DAG)
    # ═══════════════════════════════════════════════════════════════════════

    # ── B1: Kết nối tuần tự trong mỗi stage ──
    # B_0→B_1→B_2→B_3 | B_4→B_5→B_6→B_7 | B_8→B_9→B_10→B_11 | B_12→...→B_15
    for stage in range(NUM_STAGES):
        base = stage * LAYERS_PER_STAGE + BLOCK_START_IDX
        for j in range(LAYERS_PER_STAGE - 1):
            src = base + j
            dst = base + j + 1
            A[src, dst] = 1.0  # Cạnh có hướng: src → dst

    # ── B2: Kết nối xuyên stage ──
    # Block cuối stage k → Block đầu stage k+1
    # B_3 → B_4, B_7 → B_8, B_11 → B_12
    for stage in range(NUM_STAGES - 1):
        last_in_stage = (stage + 1) * LAYERS_PER_STAGE  # node index  (offset +1)
        first_in_next = last_in_stage + BLOCK_START_IDX  # +1 for Input offset
        A[last_in_stage, first_in_next] = 1.0

    # ── B3: Kết nối Input → Block đầu tiên ──
    A[INPUT_NODE_IDX, BLOCK_START_IDX] = 1.0

    # ── B4: Kết nối Block cuối cùng → Output ──
    A[BLOCK_END_IDX, OUTPUT_NODE_IDX] = 1.0

    # ── B5: Kết nối Global ↔ tất cả nodes (nếu có) ──
    # Global node đóng vai trò "information hub":
    #   - Global → node_i: broadcast thông tin tổng hợp
    #   - node_i → Global: thu thập thông tin từ mỗi node
    if add_global_node:
        for i in range(num_nodes):
            if i != GLOBAL_NODE_IDX:
                A[GLOBAL_NODE_IDX, i] = 1.0   # Global → node_i
                A[i, GLOBAL_NODE_IDX] = 1.0   # node_i → Global

    # ── B6: Self-loops (cần thiết cho GCN aggregation) ──
    # H' = σ(D̃^{-1/2} Ã D̃^{-1/2} H W)  với Ã = A + I
    np.fill_diagonal(A, 1.0)

    return X, A


def _find_scale_index(scale_ratio: float, tol: float = 1e-6) -> int:
    """
    Tìm index của scale_ratio trong SCALE_VALUES với tolerance cho FP error.

    Args:
        scale_ratio: Giá trị scale (e.g., 0.0625 cho 1/16)
        tol: Tolerance cho so sánh floating point

    Returns:
        Index trong SCALE_VALUES
    """
    for idx, val in enumerate(SCALE_VALUES):
        if abs(scale_ratio - val) < tol:
            return idx
    raise ValueError(
        f"scale_ratio={scale_ratio} không nằm trong SCALE_VALUES={SCALE_VALUES}"
    )


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  6. NHIỆM VỤ 2: MÃ HÓA PHẦN CỨNG (Hardware Encoder)                 ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def encode_hardware(hardware_name: str) -> torch.Tensor:
    """
    Mã hóa phần cứng thành vector nhị phân 5 chiều theo bài báo MHLP.

    Bài báo MHLP: "Chúng tôi sử dụng kỹ thuật mã hóa one-hot đơn giản để
    phân biệt các loại nền tảng (đám mây/máy chủ vs. thiết bị di động) và
    các loại thiết bị cụ thể (CPU, GPU, FPGA, và ASIC). Nó cũng nắm bắt
    được các thiết kế không đồng nhất (heterogeneous) kết hợp giữa CPU và GPU."

    Cấu trúc vector 5 chiều:
      [is_desktop_cloud, is_mobile, has_cpu, has_gpu, has_asic_npu]

    Mapping 3 thiết bị:
      "RTX4080"     → [1, 0, 0, 1, 0]  Desktop + GPU (discrete, CUDA)
      "ip15"        → [0, 1, 1, 1, 1]  Mobile + Heterogeneous (CPU + GPU + NPU)
            "Mac_M1" / "Macbook_M1" → [1, 0, 1, 1, 0]  Desktop/Laptop + Heterogeneous (CPU + GPU)

    Ưu điểm so với flat one-hot 6D cũ:
      - Nắm bắt thiết kế heterogeneous (nhiều bit = 1 đồng thời)
      - Phân biệt platform (desktop vs. mobile) VÀ compute units (CPU/GPU/NPU)
      - Dễ mở rộng: thêm thiết bị mới chỉ cần thêm entry vào HARDWARE_CATALOG
      - Mô hình có thể học ảnh hưởng riêng lẻ của từng compute unit

    Args:
        hardware_name: Tên phần cứng (key trong HARDWARE_CATALOG)

    Returns:
        torch.Tensor shape (5,): Vector nhị phân phần cứng

    Raises:
        ValueError: Nếu hardware_name không có trong HARDWARE_CATALOG
    """
    canonical_name = HARDWARE_NAME_ALIASES.get(hardware_name, hardware_name)

    if canonical_name not in HARDWARE_CATALOG:
        raise ValueError(
            f"Unknown hardware: '{hardware_name}'. "
            f"Available: {list(HARDWARE_CATALOG.keys()) + list(HARDWARE_NAME_ALIASES.keys())}"
        )

    hw_info = HARDWARE_CATALOG[canonical_name]

    # Xây dựng vector 5D từ HARDWARE_CATALOG theo thứ tự HW_FEATURE_NAMES
    # [is_desktop_cloud, is_mobile, has_cpu, has_gpu, has_asic_npu]
    hw_vector = torch.tensor(
        [float(hw_info[feat]) for feat in HW_FEATURE_NAMES],
        dtype=torch.float32,
    )

    return hw_vector


def get_all_hardware_encodings() -> Dict[str, torch.Tensor]:
    """Trả về encoding cho toàn bộ phần cứng trong catalog."""
    return {name: encode_hardware(name) for name in HARDWARE_CATALOG}


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  7. PYTORCH DATASET & DATALOADER                                       ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class HyTraMHLPDataset(Dataset):
    """
    PyTorch Dataset cho MHLP với kiến trúc HyTra.

    Mỗi sample gồm:
      - X:       (NUM_GRAPH_NODES, NODE_FEATURE_DIM) = (19, 14) node features
      - A:       (NUM_GRAPH_NODES, NUM_GRAPH_NODES) = (19, 19) adjacency matrix
      - hw:      (HW_ENCODING_DIM,) = (5,) hardware binary vector
      - latency: (1,) target latency (ms)

    Hỗ trợ 2 chế độ khởi tạo:
      (a) Từ BossNAS JSON files (latency_500.json + hardware names)
      (b) Từ dữ liệu trực tiếp (list of dicts)
    """

    def __init__(
        self,
        data: Optional[List[Dict]] = None,
        json_files: Optional[List[str]] = None,
        hardware_names: Optional[List[str]] = None,
        normalize_latency: bool = True,
    ):
        """
        Args:
            data: List of dicts, mỗi dict chứa:
                  {'arch': list_of_tuples_or_bossnas, 'hardware': str, 'latency': float}
            json_files: List đường dẫn BossNAS latency JSON files
            hardware_names: Tên phần cứng cho mỗi JSON file
            normalize_latency: Chuẩn hóa latency bằng z-score
        """
        self.samples: List[Dict] = []

        if data is not None:
            self._load_from_data(data)
        elif json_files is not None and hardware_names is not None:
            self._load_from_json(json_files, hardware_names)
        else:
            raise ValueError(
                "Cần cung cấp 'data' hoặc 'json_files' + 'hardware_names'"
            )

        # Chuyển đổi sang tensors
        self.X_tensors: List[torch.Tensor] = []
        self.A_tensors: List[torch.Tensor] = []
        self.hw_tensors: List[torch.Tensor] = []
        self.lat_tensors: List[torch.Tensor] = []

        self.hw_names: List[str] = []
        for sample in self.samples:
            self.X_tensors.append(torch.tensor(sample["X"], dtype=torch.float32))
            self.A_tensors.append(torch.tensor(sample["A"], dtype=torch.float32))
            self.hw_tensors.append(torch.as_tensor(sample["hw"], dtype=torch.float32))
            self.lat_tensors.append(
                torch.tensor([sample["latency"]], dtype=torch.float32)
            )
            self.hw_names.append(sample.get("hw_name", "unknown"))

        # Z-score normalization cho latency
        all_lats = torch.cat(self.lat_tensors)
        self.latency_mean = all_lats.mean().item()
        self.latency_std = all_lats.std().item()
        self.normalize_latency = normalize_latency

        if normalize_latency and self.latency_std > 1e-8:
            self.lat_tensors = [
                (lat - self.latency_mean) / self.latency_std
                for lat in self.lat_tensors
            ]
            print(f"[INFO] Latency z-score: mean={self.latency_mean:.4f}, "
                  f"std={self.latency_std:.4f}")

        print(f"[INFO] Dataset: {len(self)} samples, "
              f"X={self.X_tensors[0].shape}, A={self.A_tensors[0].shape}, "
              f"hw={self.hw_tensors[0].shape}")

    def _load_from_data(self, data: List[Dict]) -> None:
        """Load từ list of dicts."""
        for item in data:
            # Parse architecture
            arch = item["arch"]
            if isinstance(arch[0], (list, tuple)) and isinstance(arch[0][0], int):
                # BossNAS format: [[4, 2, 2, 3], ...] → convert to tuples
                arch = bossnas_to_tuples(arch)

            X, A = encode_hytra_dag(arch)
            hw = encode_hardware(item["hardware"])

            self.samples.append({
                "X": X, "A": A, "hw": hw,
                "latency": float(item["latency"]),
                "arch_tuples": arch,
                "hw_name": item["hardware"],
            })

    def _load_from_json(
        self, json_files: List[str], hardware_names: List[str]
    ) -> None:
        """Load từ BossNAS latency JSON files."""
        for fpath, hw_name in zip(json_files, hardware_names):
            print(f"[INFO] Loading: {fpath} ({hw_name})")
            with open(fpath, "r") as f:
                data = json.load(f)

            hw_vec = encode_hardware(hw_name)

            for entry in data.get("results", []):
                arch_bossnas = entry["arch"]

                # Convert op indices → tuples, xử lý lỗi nếu op ngoài range
                try:
                    arch_tuples = bossnas_to_tuples(arch_bossnas)
                except ValueError:
                    continue  # Skip invalid architectures

                X, A = encode_hytra_dag(arch_tuples, validate=False)

                self.samples.append({
                    "X": X, "A": A, "hw": hw_vec,
                    "latency": float(entry["latency_ms"]["mean"]),
                    "arch_tuples": arch_tuples,
                })

        print(f"[INFO] Loaded {len(self.samples)} samples from "
              f"{len(json_files)} files")

    def __len__(self) -> int:
        return len(self.X_tensors)

    def __getitem__(
        self, idx: int
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        return (
            self.X_tensors[idx],
            self.A_tensors[idx],
            self.hw_tensors[idx],
            self.lat_tensors[idx],
        )

    def denormalize(self, normalized: torch.Tensor) -> torch.Tensor:
        """Chuyển latency normalized → thực (ms)."""
        if self.normalize_latency and self.latency_std > 1e-8:
            return normalized * self.latency_std + self.latency_mean
        return normalized


def create_dataloaders(
    dataset: HyTraMHLPDataset,
    batch_size: int = 32,
    train_ratio: float = 0.8,
    val_ratio: float = 0.1,
    seed: int = 42,
) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    Chia dataset thành Train/Val/Test và tạo DataLoaders.

    Returns:
        (train_loader, val_loader, test_loader)
    """
    total = len(dataset)
    train_size = int(total * train_ratio)
    val_size = int(total * val_ratio)
    test_size = total - train_size - val_size

    gen = torch.Generator().manual_seed(seed)
    train_set, val_set, test_set = torch.utils.data.random_split(
        dataset, [train_size, val_size, test_size], generator=gen
    )

    train_loader = DataLoader(train_set, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_set, batch_size=batch_size, shuffle=False)
    test_loader = DataLoader(test_set, batch_size=batch_size, shuffle=False)

    print(f"[INFO] Split: train={train_size}, val={val_size}, test={test_size}")
    return train_loader, val_loader, test_loader


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  8. TIỆN ÍCH: HIỂN THỊ & DEBUG                                        ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def pretty_print_architecture(arch: List[Tuple[str, float]]) -> str:
    """Hiển thị kiến trúc HyTra một cách dễ đọc."""
    lines = ["HyTra Architecture (16 layers):", "─" * 55]
    for i, (bt, sr) in enumerate(arch):
        stage = i // LAYERS_PER_STAGE
        pos = i % LAYERS_PER_STAGE
        scale_label = SCALE_INFO.get(sr, {}).get("label", f"{sr}")
        att_flag = " ★" if bt == "ResAtt" else ""
        lines.append(
            f"  Stage {stage} | Layer {pos} | {bt:8s} @ {scale_label:16s}{att_flag}"
        )
        if pos == 3 and stage < 3:
            lines.append("  " + "─" * 52)
    return "\n".join(lines)


def print_graph_summary(X: np.ndarray, A: np.ndarray) -> None:
    """In tóm tắt về đồ thị DAG."""
    num_nodes = X.shape[0]
    num_edges = int(A.sum()) - int(np.trace(A))  # Trừ self-loops

    print(f"Graph Summary:")
    print(f"  Nodes: {num_nodes}")
    print(f"  Edges: {num_edges} (excluding self-loops)")
    print(f"  Node feature dim: {X.shape[1]}")
    print(f"  Adjacency matrix: {A.shape}")
    print(f"  A is symmetric: {np.allclose(A, A.T)}")
    print(f"  Self-loops: {int(np.trace(A))}")

    # Degree statistics
    degrees = A.sum(axis=1) - np.diag(A)  # Exclude self-loops
    print(f"  Degree (out): min={degrees.min():.0f}, "
          f"max={degrees.max():.0f}, mean={degrees.mean():.1f}")


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  9. MAIN: DEMO & VERIFICATION                                         ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def main():
    """Demo: Mã hóa kiến trúc HyTra và phần cứng."""
    print("=" * 70)
    print("  HyTra Encoding for MHLP — Demo")
    print("=" * 70)

    # ── Demo 1: Mã hóa từ tuple format ──
    print("\n▶ Demo 1: Encode từ tuple format")
    sample_arch: List[Tuple[str, float]] = [
        # Stage 0 (layer4): bắt đầu ở scale trung bình
        ("ResConv", 1/8),   ("ResAtt",  1/16),  ("ResAtt",  1/16),  ("ResConv", 1/16),
        # Stage 1 (layer3): chuyển sang scale nhỏ hơn
        ("ResConv", 1/8),   ("ResConv", 1/8),   ("ResAtt",  1/16),  ("ResConv", 1/16),
        # Stage 2 (layer2): scale nhỏ, chủ yếu CNN
        ("ResAtt",  1/16),  ("ResConv", 1/16),  ("ResConv", 1/16),  ("ResConv", 1/32),
        # Stage 3 (layer1): scale nhỏ nhất, mix CNN + Transformer
        ("ResConv", 1/16),  ("ResConv", 1/16),  ("ResAtt",  1/32),  ("ResAtt",  1/32),
    ]

    print(pretty_print_architecture(sample_arch))

    X, A = encode_hytra_dag(sample_arch)
    print(f"\n  X shape: {X.shape}  (expected: ({NUM_GRAPH_NODES}, {NODE_FEATURE_DIM}))")
    print(f"  A shape: {A.shape}  (expected: ({NUM_GRAPH_NODES}, {NUM_GRAPH_NODES}))")
    print_graph_summary(X, A)

    # ── Demo 2: Mã hóa từ BossNAS op_index format ──
    print(f"\n{'─' * 70}")
    print("▶ Demo 2: Convert từ BossNAS format")
    bossnas_arch = [[4, 2, 2, 3], [4, 4, 2, 3], [2, 3, 3, 1], [3, 3, 0, 0]]
    print(f"  BossNAS format: {bossnas_arch}")

    tuples = bossnas_to_tuples(bossnas_arch)
    print(f"  → Tuple format:")
    for i, (bt, sr) in enumerate(tuples):
        print(f"    Layer {i:2d}: {bt:8s} @ {sr}")

    X2, A2 = encode_hytra_dag(tuples)
    print(f"\n  X shape: {X2.shape}")
    print(f"  A shape: {A2.shape}")

    # ── Demo 3: Hardware Encoding (5D — MHLP paper-aligned) ──
    print(f"\n{'─' * 70}")
    print("▶ Demo 3: Hardware Encoding (5D MHLP)")
    print(f"  Format: {HW_FEATURE_NAMES}")
    for hw_name in HARDWARE_CATALOG:
        vec = encode_hardware(hw_name)
        desc = HARDWARE_CATALOG[hw_name]["description"]
        print(f"  {hw_name:12s} → {vec.tolist()}")
        print(f"  {'':12s}   {desc}")

    # ── Demo 4: Validation ──
    print(f"\n{'─' * 70}")
    print("▶ Demo 4: Architecture Validation")

    # Hợp lệ
    valid, errors = validate_hytra_architecture(sample_arch)
    print(f"  Sample arch: valid={valid}, errors={len(errors)}")

    # Không hợp lệ: ResAtt ở scale 1/4
    bad_arch = [("ResAtt", 1/4)] + list(sample_arch[1:])
    valid, errors = validate_hytra_architecture(bad_arch)
    print(f"  Bad arch:    valid={valid}")
    for e in errors:
        print(f"    ✗ {e}")

    # ── Demo 5: Node feature vector ──
    print(f"\n{'─' * 70}")
    print("▶ Demo 5: Node feature vectors (first 5 nodes)")
    node_names = ["Input", "Block_0", "Block_1", "Block_2", "Block_3"]
    for i, name in enumerate(node_names):
        print(f"  {name:10s}: {X[i].tolist()}")

    print(f"\n{'=' * 70}")
    print("  HyTra Encoding — Ready for MHLP!")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    main()
