#!/usr/bin/env python3
"""Retrain a fixed MicroHyTra architecture on CIFAR-10.

This module intentionally avoids torchvision dependency by reading the
`cifar-10-batches-py` files directly.
"""

from __future__ import annotations

import os
import pickle
import random
import warnings
from dataclasses import dataclass
from typing import Dict, List, Sequence, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from new_supernet import MicroHyTra_2x4, architecture_to_string, validate_architecture


_CIFAR_MEAN = torch.tensor([0.4914, 0.4822, 0.4465], dtype=torch.float32)
_CIFAR_STD = torch.tensor([0.2470, 0.2435, 0.2616], dtype=torch.float32)


@dataclass
class RetrainConfig:
    cifar_root: str = "src/data/cifar/cifar-10-batches-py"
    output_dir: str = "results/mhlp_microhytra_cifar10"
    epochs: int = 30
    batch_size: int = 128
    lr: float = 3e-4
    weight_decay: float = 5e-4
    num_workers: int = 4
    label_smoothing: float = 0.1


def _load_single_batch(file_path: str) -> Tuple[np.ndarray, np.ndarray]:
    with open(file_path, "rb") as f:
        # CIFAR legacy pickle may trigger a NumPy deprecation warning on newer versions.
        with warnings.catch_warnings():
            warnings.filterwarnings(
                "ignore",
                message=r"dtype\(\): align should.*",
                category=np.exceptions.VisibleDeprecationWarning,
            )
            data = pickle.load(f, encoding="latin1")

    # CIFAR pickles may use either str or bytes keys depending on loader settings.
    image_data = data["data"] if "data" in data else data[b"data"]
    labels = data["labels"] if "labels" in data else data[b"labels"]

    # CIFAR batch format: N x 3072, channel-first flattened.
    images = image_data.reshape(-1, 3, 32, 32)
    labels_np = np.asarray(labels, dtype=np.int64)
    return images, labels_np


def _load_cifar10_arrays(cifar_root: str, train: bool) -> Tuple[np.ndarray, np.ndarray]:
    if not os.path.isdir(cifar_root):
        raise FileNotFoundError(
            f"CIFAR-10 folder not found: {cifar_root}. "
            "Expected path containing data_batch_1 ... data_batch_5 and test_batch."
        )

    if train:
        batch_names = [f"data_batch_{idx}" for idx in range(1, 6)]
    else:
        batch_names = ["test_batch"]

    all_images: List[np.ndarray] = []
    all_labels: List[np.ndarray] = []

    for name in batch_names:
        path = os.path.join(cifar_root, name)
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Missing CIFAR batch file: {path}")
        images, labels = _load_single_batch(path)
        all_images.append(images)
        all_labels.append(labels)

    images_cat = np.concatenate(all_images, axis=0)
    labels_cat = np.concatenate(all_labels, axis=0)
    return images_cat, labels_cat


class Cifar10BatchDataset(Dataset):
    """CIFAR-10 dataset from raw batch files with lightweight augmentation."""

    def __init__(self, cifar_root: str, train: bool, augment: bool):
        self.images, self.labels = _load_cifar10_arrays(cifar_root, train=train)
        self.augment = augment

    def __len__(self) -> int:
        return int(self.labels.shape[0])

    def _augment_tensor(self, x: torch.Tensor) -> torch.Tensor:
        # Random crop with 4-pixel zero padding.
        x = F.pad(x, pad=(4, 4, 4, 4), mode="constant", value=0.0)
        top = random.randint(0, 8)
        left = random.randint(0, 8)
        x = x[:, top : top + 32, left : left + 32]

        # Random horizontal flip.
        if random.random() < 0.5:
            x = torch.flip(x, dims=[2])

        return x

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, torch.Tensor]:
        image = self.images[idx]  # uint8, CHW
        label = int(self.labels[idx])

        x = torch.tensor(image, dtype=torch.float32) / 255.0

        if self.augment:
            x = self._augment_tensor(x)

        x = (x - _CIFAR_MEAN[:, None, None]) / _CIFAR_STD[:, None, None]
        y = torch.tensor(label, dtype=torch.long)

        return x, y


class MicroHyTraClassifier(nn.Module):
    """Classifier head on top of fixed MicroHyTra_2x4 architecture path."""

    def __init__(
        self,
        arch_list: Sequence[str],
        num_classes: int = 10,
        stem_channels: int = 48,
        dropout: float = 0.1,
    ):
        super().__init__()
        validate_architecture(arch_list)
        self.arch_list = list(arch_list)

        self.backbone = MicroHyTra_2x4(in_channels=3, stem_channels=stem_channels, attn_heads=4)
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.dropout = nn.Dropout(p=dropout)
        self.fc = nn.Linear(stem_channels, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feat = self.backbone(x, arch_list=self.arch_list)
        feat = self.pool(feat).flatten(1)
        feat = self.dropout(feat)
        logits = self.fc(feat)
        return logits


@torch.no_grad()
def _evaluate(model: nn.Module, loader: DataLoader, device: torch.device) -> Dict[str, float]:
    model.eval()
    criterion = nn.CrossEntropyLoss()

    total_loss = 0.0
    total_correct = 0
    total_samples = 0

    for images, labels in loader:
        images = images.to(device, non_blocking=True)
        labels = labels.to(device, non_blocking=True)

        logits = model(images)
        loss = criterion(logits, labels)

        preds = logits.argmax(dim=1)
        total_correct += int((preds == labels).sum().item())
        total_loss += float(loss.item()) * images.size(0)
        total_samples += int(images.size(0))

    avg_loss = total_loss / max(total_samples, 1)
    acc1 = 100.0 * total_correct / max(total_samples, 1)

    return {"loss": avg_loss, "acc1": acc1}


def retrain_architecture_on_cifar10(
    arch_list: Sequence[str],
    cfg: RetrainConfig,
    device: torch.device,
) -> Dict[str, float | str]:
    """Retrain one selected architecture on CIFAR-10 and return summary metrics."""
    validate_architecture(arch_list)
    os.makedirs(cfg.output_dir, exist_ok=True)

    train_set = Cifar10BatchDataset(cifar_root=cfg.cifar_root, train=True, augment=True)
    test_set = Cifar10BatchDataset(cifar_root=cfg.cifar_root, train=False, augment=False)

    train_loader = DataLoader(
        train_set,
        batch_size=cfg.batch_size,
        shuffle=True,
        num_workers=cfg.num_workers,
        pin_memory=True,
        drop_last=True,
    )
    test_loader = DataLoader(
        test_set,
        batch_size=cfg.batch_size,
        shuffle=False,
        num_workers=cfg.num_workers,
        pin_memory=True,
        drop_last=False,
    )

    model = MicroHyTraClassifier(arch_list=arch_list).to(device)

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=cfg.lr,
        weight_decay=cfg.weight_decay,
    )
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=cfg.epochs)
    criterion = nn.CrossEntropyLoss(label_smoothing=cfg.label_smoothing)

    best_acc1 = 0.0
    best_ckpt = os.path.join(cfg.output_dir, "best_microhytra_cifar10.pth")

    arch_str = architecture_to_string(arch_list)
    print("[Step 5] Retraining selected architecture on CIFAR-10")
    print(f"  Architecture: {arch_str}")
    print(f"  Train samples: {len(train_set)}, Test samples: {len(test_set)}")

    for epoch in range(1, cfg.epochs + 1):
        model.train()
        running_loss = 0.0
        running_correct = 0
        seen = 0

        for images, labels in train_loader:
            images = images.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)

            logits = model(images)
            loss = criterion(logits, labels)

            optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()

            preds = logits.argmax(dim=1)
            running_correct += int((preds == labels).sum().item())
            running_loss += float(loss.item()) * images.size(0)
            seen += int(images.size(0))

        scheduler.step()

        train_loss = running_loss / max(seen, 1)
        train_acc1 = 100.0 * running_correct / max(seen, 1)

        eval_stats = _evaluate(model, test_loader, device)
        test_acc1 = float(eval_stats["acc1"])

        if test_acc1 > best_acc1:
            best_acc1 = test_acc1
            torch.save(
                {
                    "model_state_dict": model.state_dict(),
                    "arch_list": list(arch_list),
                    "arch_string": arch_str,
                    "best_acc1": best_acc1,
                    "epoch": epoch,
                },
                best_ckpt,
            )

        if epoch == 1 or epoch % 10 == 0 or epoch == cfg.epochs:
            print(
                f"[CIFAR-10] Epoch {epoch:03d}/{cfg.epochs} | "
                f"Train Loss={train_loss:.4f} | Train Acc={train_acc1:.2f}% | "
                f"Test Acc={test_acc1:.2f}% | Best={best_acc1:.2f}%"
            )

    final_eval = _evaluate(model, test_loader, device)

    return {
        "best_test_acc1": float(best_acc1),
        "final_test_acc1": float(final_eval["acc1"]),
        "final_test_loss": float(final_eval["loss"]),
        "checkpoint": best_ckpt,
        "arch_string": arch_str,
    }


__all__ = [
    "RetrainConfig",
    "retrain_architecture_on_cifar10",
]
