#!/usr/bin/env python3
"""CLI entry point for MHLP meta-learning training."""

import argparse
import json
import os
import random
import sys
from datetime import datetime
from typing import Dict, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from hytra_encoding import HW_ENCODING_DIM, NODE_FEATURE_DIM, HyTraMHLPDataset
from mhlp_predictor import MHLPPredictor
from train_meta_learning import create_task_dataloaders, train_meta_learning
from train_mhlp import load_csv_data


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Train MHLP with MAML meta-learning from CSV",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument(
        "--data_path",
        type=str,
        default="src/mhlp/hytra_latency_dataset.csv",
        help="Path to CSV file with columns: architecture_string, hardware_type, latency_ms",
    )
    parser.add_argument("--epochs", type=int, default=100, help="Meta-training epochs")
    parser.add_argument("--batch_size", type=int, default=64, help="Task dataloader batch size")
    parser.add_argument("--inner_lr", type=float, default=0.01, help="Inner-loop learning rate")
    parser.add_argument("--inner_steps", type=int, default=1, help="Inner-loop steps")
    parser.add_argument("--support_ratio", type=float, default=0.5, help="Support/query split ratio")
    parser.add_argument("--meta_lr", type=float, default=1e-3, help="Outer-loop learning rate")
    parser.add_argument("--weight_decay", type=float, default=1e-4, help="Meta optimizer weight decay")
    parser.add_argument("--log_interval", type=int, default=10, help="Epoch logging interval")
    parser.add_argument(
        "--val_ratio",
        type=float,
        default=0.0,
        help="Validation ratio per hardware task (0 to disable validation)",
    )

    parser.add_argument("--seed", type=int, default=42, help="Random seed")
    parser.add_argument(
        "--device",
        type=str,
        default="auto",
        choices=["auto", "cpu", "cuda"],
        help="Compute device",
    )

    parser.add_argument("--gcn_hidden", type=int, default=128)
    parser.add_argument("--mlp_hidden", type=int, default=64)
    parser.add_argument("--embed_dim", type=int, default=128)
    parser.add_argument("--num_gcn_layers", type=int, default=3)
    parser.add_argument("--num_attn_heads", type=int, default=4)
    parser.add_argument("--ffn_dim", type=int, default=512)
    parser.add_argument("--predictor_hidden", type=int, default=128)
    parser.add_argument("--dropout", type=float, default=0.1)

    parser.add_argument(
        "--run_name",
        type=str,
        default="",
        help="Run name for saved artifacts. If empty, auto-generated",
    )
    parser.add_argument(
        "--out_dir",
        type=str,
        default="results/meta_learning",
        help="Output directory for checkpoint and history",
    )
    parser.add_argument(
        "--log_transform",
        action="store_true",
        help="Apply log(latency) before training",
    )

    return parser.parse_args()


def set_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)


def resolve_device(device_arg: str) -> torch.device:
    if device_arg == "cuda" and not torch.cuda.is_available():
        print("[WARN] CUDA requested but unavailable. Falling back to CPU.")
        return torch.device("cpu")
    if device_arg == "auto":
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(device_arg)


def split_task_dataloaders(
    dataset: HyTraMHLPDataset,
    batch_size: int,
    val_ratio: float,
    seed: int,
) -> Tuple[Dict[str, DataLoader], Optional[Dict[str, DataLoader]]]:
    task_loaders = create_task_dataloaders(dataset, batch_size=batch_size, shuffle=True)

    if val_ratio <= 0.0:
        return task_loaders, None

    train_task_loaders: Dict[str, DataLoader] = {}
    val_task_loaders: Dict[str, DataLoader] = {}

    for task_idx, task_name in enumerate(sorted(task_loaders.keys())):
        task_dataset = task_loaders[task_name].dataset
        n_samples = len(task_dataset)

        if n_samples < 2:
            train_task_loaders[task_name] = DataLoader(
                task_dataset,
                batch_size=batch_size,
                shuffle=True,
                drop_last=False,
            )
            continue

        n_val = max(1, int(n_samples * val_ratio))
        n_val = min(n_val, n_samples - 1)

        generator = torch.Generator().manual_seed(seed + task_idx)
        perm = torch.randperm(n_samples, generator=generator).tolist()

        val_ids = perm[:n_val]
        train_ids = perm[n_val:]

        train_subset = Subset(task_dataset, train_ids)
        val_subset = Subset(task_dataset, val_ids)

        train_task_loaders[task_name] = DataLoader(
            train_subset,
            batch_size=batch_size,
            shuffle=True,
            drop_last=False,
        )
        val_task_loaders[task_name] = DataLoader(
            val_subset,
            batch_size=batch_size,
            shuffle=False,
            drop_last=False,
        )

        print(
            f"  [Task Split] {task_name}: train={len(train_subset)}, val={len(val_subset)}"
        )

    return train_task_loaders, val_task_loaders


def build_model(args: argparse.Namespace, device: torch.device) -> MHLPPredictor:
    model = MHLPPredictor(
        node_feat_dim=NODE_FEATURE_DIM,
        hw_input_dim=HW_ENCODING_DIM,
        gcn_hidden_dim=args.gcn_hidden,
        mlp_hidden_dim=args.mlp_hidden,
        embed_dim=args.embed_dim,
        num_gcn_layers=args.num_gcn_layers,
        num_attn_heads=args.num_attn_heads,
        ffn_dim=args.ffn_dim,
        predictor_hidden=args.predictor_hidden,
        dropout=args.dropout,
    ).to(device)
    return model


def main() -> None:
    args = parse_args()
    set_seed(args.seed)

    device = resolve_device(args.device)
    print("=" * 72)
    print("MHLP Meta-Learning Entry Point")
    print(f"Device: {device}")
    print(f"Data: {args.data_path}")
    print(f"Epochs: {args.epochs}")
    print("=" * 72)

    data = load_csv_data(args.data_path, log_transform=args.log_transform)
    dataset = HyTraMHLPDataset(data=data, normalize_latency=True)

    train_task_loaders, val_task_loaders = split_task_dataloaders(
        dataset=dataset,
        batch_size=args.batch_size,
        val_ratio=args.val_ratio,
        seed=args.seed,
    )

    model = build_model(args, device)
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=args.meta_lr,
        weight_decay=args.weight_decay,
    )

    history = train_meta_learning(
        meta_model=model,
        meta_optimizer=optimizer,
        dataloaders_dict=train_task_loaders,
        num_epochs=args.epochs,
        inner_lr=args.inner_lr,
        inner_steps=args.inner_steps,
        support_ratio=args.support_ratio,
        device=device,
        log_interval=args.log_interval,
        val_dataloaders_dict=val_task_loaders,
    )

    run_name = args.run_name.strip()
    if not run_name:
        run_name = f"meta_{args.epochs}ep_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    out_dir = os.path.abspath(args.out_dir)
    os.makedirs(out_dir, exist_ok=True)

    ckpt_path = os.path.join(out_dir, f"{run_name}.pth")
    history_path = os.path.join(out_dir, f"{run_name}_history.json")
    config_path = os.path.join(out_dir, f"{run_name}_config.json")

    torch.save(
        {
            "model_state_dict": model.state_dict(),
            "optimizer_state_dict": optimizer.state_dict(),
            "history": history,
            "args": vars(args),
            "device": str(device),
        },
        ckpt_path,
    )

    with open(history_path, "w") as f:
        json.dump(history, f, indent=2)

    with open(config_path, "w") as f:
        json.dump(vars(args), f, indent=2)

    print("\n" + "=" * 72)
    print("Training complete")
    print(f"Checkpoint: {ckpt_path}")
    print(f"History:    {history_path}")
    print(f"Config:     {config_path}")
    if history.get("meta_loss"):
        best_idx = int(np.argmin(history["meta_loss"]))
        print(f"Best meta-loss: {history['meta_loss'][best_idx]:.6f} (epoch {best_idx + 1})")
        print(f"Final meta-loss: {history['meta_loss'][-1]:.6f}")
    print("=" * 72)


if __name__ == "__main__":
    main()
