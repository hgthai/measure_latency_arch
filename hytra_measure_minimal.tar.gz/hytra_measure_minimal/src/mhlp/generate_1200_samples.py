# generate_1200_samples.py
# Chạy PHẦN A trên server GPU trước
# Sau đó copy file arch_1200_fixed.json sang các thiết bị khác

"""
HƯỚNG DẪN CHẠY:
  Server RTX 4060: python generate_1200_samples.py --phase generate --device cuda --device-name rtx4060
  Server RTX 3050: python generate_1200_samples.py --phase measure  --device cuda --device-name rtx3050
  Server RTX 5060: python generate_1200_samples.py --phase measure  --device cuda --device-name rtx5060
  MacBook M1:      python generate_1200_samples.py --phase measure  --device mps  --device-name macbook_m1
  Windows CPU:     python generate_1200_samples.py --phase measure  --device cpu  --device-name windows_cpu
  Raspberry Pi:    python generate_1200_samples.py --phase measure  --device cpu  --device-name raspi4 --n-samples 600
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json
import os
import random
import sys
import time
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

# ── Path setup ──────────────────────────────────────────────────────────────
_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, _SCRIPT_DIR)
sys.path.insert(0, os.path.join(_SCRIPT_DIR, "..", "searching"))
sys.path.insert(0, os.path.join(_SCRIPT_DIR, "..", "OpenSelfSup"))


def _resolve_path(path: str) -> str:
    """Resolve CLI-provided paths robustly.

    - Absolute paths are kept as-is.
    - Relative paths are resolved relative to the current working directory.

    This makes commands from the repository root write to the requested repo paths.
    """
    if os.path.isabs(path):
        return path
    return os.path.abspath(path)

from hytra_latency_pipeline import (
    HyTraCIFARProxyModel,
    HyTraProxyModel,
    OP_INDEX_TO_TUPLE,
    RESTRICTED_PATHS,
    STAGE_DEPTHS,
    TUPLE_TO_OP_INDEX,
    _arch_string_to_tuples,
    _synchronize,
    _tuples_to_arch_string,
    measure_latency_full,
    NUM_STAGES,
    LAYERS_PER_STAGE,
)
from hytra_cifar_paths import (
    OP_INDEX_TO_TUPLE_CIFAR,
    RESTRICTED_PATHS_CIFAR,
    STAGE_DEPTHS_CIFAR,
    WIDTH_MULTS_CIFAR,
    count_resatt_cifar,
    downsample_pattern_cifar,
    make_hytra_cifar_arch,
    hytra_cifar_arch_to_string,
    parse_hytra_cifar_arch_string,
    tuples_to_op_indices_cifar,
)

LAST_CIFAR_GENERATION_METADATA: Dict[str, Any] = {}


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  PHẦN A: SINH 1200 MẪU STRATIFIED                                        ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def count_resatt(arch_tuples: List[Tuple[str, float]]) -> int:
    """Đếm số ResAtt blocks trong kiến trúc."""
    return sum(1 for bt, _ in arch_tuples if bt == "ResAtt")


def classify_arch(arch_tuples: List[Tuple[str, float]]) -> str:
    """
    Phân loại kiến trúc vào 1 trong 4 nhóm:
      pure_conv   : 0 ResAtt blocks
      heavy_attn  : ≥6 ResAtt blocks
      hybrid      : 3–5 ResAtt blocks
      random      : còn lại (1–2 ResAtt blocks)
    """
    n = count_resatt(arch_tuples)
    if n == 0:
        return "pure_conv"
    elif n >= 6:
        return "heavy_attn"
    elif 3 <= n <= 5:
        return "hybrid"
    else:
        return "light_attn"  # 1–2 ResAtt — nhóm random sẽ cover


def generate_stratified_1200(seed: int = 42) -> List[Dict[str, Any]]:
    """
    Sinh 1200 mẫu stratified đảm bảo diversity.

    Phân bổ:
      pure_conv  : 250 mẫu — CNN baseline
      heavy_attn : 250 mẫu — Transformer-heavy
      hybrid     : 450 mẫu — Vùng BossNAS thường tìm ra
      random     : 250 mẫu — Coverage tổng quát

    Returns:
        List 1200 dicts, mỗi dict có:
          arch_id, arch_string, arch_tuples, op_indices,
          group, n_resatt, complexity
    """
    rng = random.Random(seed)

    TARGETS = {
        "pure_conv":  250,
        "heavy_attn": 250,
        "hybrid":     450,
        "random":     250,
    }

    groups: Dict[str, List[Dict[str, Any]]] = {k: [] for k in TARGETS}
    seen_strings: set[str] = set()

    conv_ops = {1, 3, 4, 5}
    attn_ops = {0, 2}

    def _count_resatt_from_op_indices(op_indices: List[List[int]]) -> int:
        return sum(1 for stage in op_indices for op in stage if op in attn_ops)

    def _build_arch_info(op_indices: List[List[int]], group: str) -> Dict[str, Any]:
        arch_tuples: List[Tuple[str, float]] = []
        for stage in op_indices:
            for op in stage:
                arch_tuples.append(OP_INDEX_TO_TUPLE[op])
        arch_str = _tuples_to_arch_string(arch_tuples)
        n_resatt = count_resatt(arch_tuples)
        complexity = sum(op * 1.5 + 1 for stage in op_indices for op in stage)
        return {
            "arch_tuples": arch_tuples,
            "arch_string": arch_str,
            "op_indices": op_indices,
            "complexity": complexity,
            "group": group,
            "n_resatt": n_resatt,
        }

    # Precompute stage-path buckets by attention-count for each stage.
    stage_paths_by_attn: List[Dict[int, List[List[int]]]] = []
    stage_possible_counts: List[List[int]] = []
    for stage_idx in range(NUM_STAGES):
        depth = STAGE_DEPTHS[stage_idx]
        paths = RESTRICTED_PATHS[depth]
        buckets: Dict[int, List[List[int]]] = {}
        for path in paths:
            attn_count = sum(1 for op in path if op in attn_ops)
            buckets.setdefault(attn_count, []).append(list(path))
        stage_paths_by_attn.append(buckets)
        stage_possible_counts.append(sorted(buckets.keys()))

    stage_min = [min(v) for v in stage_possible_counts]
    stage_max = [max(v) for v in stage_possible_counts]

    def _sample_counts_for_total(total_attn: int) -> Optional[List[int]]:
        """Randomized backtracking to find per-stage attention counts summing to total_attn."""
        chosen: List[int] = []

        def rec(stage_idx: int, remaining: int) -> bool:
            if stage_idx == NUM_STAGES:
                return remaining == 0

            # Prune by min/max possible of remaining stages (including this one).
            min_possible = sum(stage_min[stage_idx:])
            max_possible = sum(stage_max[stage_idx:])
            if remaining < min_possible or remaining > max_possible:
                return False

            options = stage_possible_counts[stage_idx][:]
            rng.shuffle(options)
            for c in options:
                if c > remaining:
                    continue

                # Prune for next stages.
                next_min = sum(stage_min[stage_idx + 1 :]) if stage_idx + 1 < NUM_STAGES else 0
                next_max = sum(stage_max[stage_idx + 1 :]) if stage_idx + 1 < NUM_STAGES else 0
                next_remaining = remaining - c
                if next_remaining < next_min or next_remaining > next_max:
                    continue

                chosen.append(c)
                if rec(stage_idx + 1, next_remaining):
                    return True
                chosen.pop()

            return False

        ok = rec(0, total_attn)
        return chosen if ok else None

    def _sample_op_indices_for_attn_range(
        group: str,
        min_attn_total: int,
        max_attn_total: int,
        *,
        max_tries: int = 10_000,
    ) -> Optional[List[List[int]]]:
        for _ in range(max_tries):
            target_total = rng.randint(min_attn_total, max_attn_total)
            counts = _sample_counts_for_total(target_total)
            if counts is None:
                continue
            op_indices: List[List[int]] = []
            for stage_idx, attn_count in enumerate(counts):
                pool = stage_paths_by_attn[stage_idx][attn_count]
                op_indices.append(rng.choice(pool))
            # Safety check.
            total = _count_resatt_from_op_indices(op_indices)
            if min_attn_total <= total <= max_attn_total:
                return op_indices
        return None

    def _fill_group(
        group: str,
        n_target: int,
        *,
        sampler,
        max_tries: int = 1_000_000,
    ) -> None:
        tries = 0
        while len(groups[group]) < n_target and tries < max_tries:
            tries += 1
            op_indices = sampler()
            if op_indices is None:
                continue
            arch_info = _build_arch_info(op_indices, group)
            arch_str = arch_info["arch_string"]
            if arch_str in seen_strings:
                continue
            seen_strings.add(arch_str)
            groups[group].append(arch_info)

        if len(groups[group]) < n_target:
            raise RuntimeError(
                f"Không thể sinh đủ nhóm '{group}': {len(groups[group])}/{n_target} "
                f"sau {tries} lần thử."
            )

    print("=" * 60)
    print("  SINH 1200 MẪU STRATIFIED")
    print("=" * 60)
    print(f"  Mục tiêu: {TARGETS}")

    def _sample_random_op_indices() -> List[List[int]]:
        op_indices: List[List[int]] = []
        for stage_idx in range(NUM_STAGES):
            depth = STAGE_DEPTHS[stage_idx]
            path = rng.choice(RESTRICTED_PATHS[depth])
            op_indices.append(list(path))
        return op_indices

    def _sample_pure_conv_op_indices() -> Optional[List[List[int]]]:
        op_indices: List[List[int]] = []
        for stage_idx in range(NUM_STAGES):
            pool = stage_paths_by_attn[stage_idx].get(0)
            if not pool:
                return None
            op_indices.append(rng.choice(pool))
        return op_indices

    # Build each group by construction (avoids rare-event rejection sampling).
    _fill_group("pure_conv", TARGETS["pure_conv"], sampler=_sample_pure_conv_op_indices)
    print(f"  ✅ pure_conv  : {len(groups['pure_conv'])}/{TARGETS['pure_conv']}")

    _fill_group(
        "hybrid",
        TARGETS["hybrid"],
        sampler=lambda: _sample_op_indices_for_attn_range("hybrid", 3, 5),
    )
    print(f"  ✅ hybrid     : {len(groups['hybrid'])}/{TARGETS['hybrid']}")

    # For heavy_attn, cap max by what's achievable from stage path buckets.
    max_total_attn = sum(stage_max)
    _fill_group(
        "heavy_attn",
        TARGETS["heavy_attn"],
        sampler=lambda: _sample_op_indices_for_attn_range(
            "heavy_attn", 6, max_total_attn
        ),
    )
    print(f"  ✅ heavy_attn : {len(groups['heavy_attn'])}/{TARGETS['heavy_attn']}")

    _fill_group("random", TARGETS["random"], sampler=_sample_random_op_indices)
    print(f"  ✅ random     : {len(groups['random'])}/{TARGETS['random']}")

    # ── Báo cáo kết quả ─────────────────────────────────────────────────
    for name, target in TARGETS.items():
        actual = len(groups[name])
        status = "✅" if actual >= target else "⚠️ THIẾU"
        print(f"  {status} {name:12s}: {actual}/{target}")

    # ── Merge và shuffle ─────────────────────────────────────────────────
    all_samples = []
    for group_name, archs in groups.items():
        all_samples.extend(archs)

    rng.shuffle(all_samples)

    # Gán arch_id sau khi shuffle
    for i, s in enumerate(all_samples):
        s["arch_id"] = i

    # ── Thống kê ResAtt distribution ────────────────────────────────────
    print(f"\n  Total: {len(all_samples)} mẫu")
    print(f"\n  ResAtt distribution:")
    resatt_counts = [s["n_resatt"] for s in all_samples]
    for n in range(0, 13):
        count = resatt_counts.count(n)
        if count > 0:
            bar = "█" * (count // 10)
            print(f"    {n:2d} ResAtt: {count:4d} mẫu {bar}")

    if resatt_counts:
        pct_with_attn = sum(1 for x in resatt_counts if x > 0) / len(resatt_counts) * 100
        print(f"\n  Có ResAtt: {pct_with_attn:.1f}%")
        print(f"  Không ResAtt: {100 - pct_with_attn:.1f}%")

    return all_samples


def _classify_cifar_group(n_resatt: int) -> str:
    if n_resatt == 0:
        return "cnn_dominant"
    if n_resatt <= 2:
        return "light_hybrid"
    if n_resatt <= 4:
        return "balanced_hybrid"
    return "attention_dominant"


def _format_width_mult(width_mult: float) -> str:
    key = f"{width_mult:.2f}".rstrip("0")
    if key.endswith("."):
        key += "0"
    return key


def _build_cifar_sample_info(
    op_indices: List[List[int]],
    group: str,
    width_mult: float,
) -> Dict[str, Any]:
    arch_tuples = [
        OP_INDEX_TO_TUPLE_CIFAR[op]
        for stage in op_indices
        for op in stage
    ]
    arch_obj = make_hytra_cifar_arch(arch_tuples, width_mult)
    n_resatt = count_resatt_cifar(arch_tuples)
    arch_str = hytra_cifar_arch_to_string(arch_obj)
    complexity_proxy = 0.0
    for block_type, scale in arch_tuples:
        complexity_proxy += (2.0 if block_type == "ResAtt" else 1.0) / max(scale, 1 / 8)
    complexity_proxy *= width_mult * width_mult
    return {
        "arch_tuples": arch_tuples,
        "downsample_pattern": downsample_pattern_cifar(arch_tuples),
        "width_mult": width_mult,
        "arch_string": arch_str,
        "architecture_string": arch_str,
        "op_indices": op_indices,
        "complexity": complexity_proxy,
        "complexity_proxy": complexity_proxy,
        "group": group,
        "n_resatt": n_resatt,
    }


def _all_unique_cifar_candidates() -> List[Dict[str, Any]]:
    candidates: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for p0 in RESTRICTED_PATHS_CIFAR[0]:
        for p1 in RESTRICTED_PATHS_CIFAR[1]:
            for p2 in RESTRICTED_PATHS_CIFAR[2]:
                op_indices = [list(p0), list(p1), list(p2)]
                arch_tuples = [
                    OP_INDEX_TO_TUPLE_CIFAR[op]
                    for stage in op_indices
                    for op in stage
                ]
                group = _classify_cifar_group(count_resatt_cifar(arch_tuples))
                for width_mult in WIDTH_MULTS_CIFAR:
                    candidate = _build_cifar_sample_info(op_indices, group, width_mult)
                    arch_str = candidate["arch_string"]
                    if arch_str in seen:
                        continue
                    seen.add(arch_str)
                    candidates.append(candidate)
    return candidates


def generate_stratified_cifar(
    seed: int = 42,
    n: int = 1200,
    *,
    allow_duplicates: bool = False,
) -> List[Dict[str, Any]]:
    """Generate a unique fixed HyTra-CIFAR sample set.

    The full Micro-HyTra space currently has 2160 unique width-aware
    architecture strings.  Recommended thesis-scale fixed sets are 800 or
    1200 samples; smaller values are useful for pilots and tests.
    """
    if allow_duplicates:
        print("  NOTE: --allow-duplicates is ignored for hytra_cifar; fixed sets are always unique.")

    rng = random.Random(seed)
    all_candidates = _all_unique_cifar_candidates()
    total_unique_space = len(all_candidates)
    if n > total_unique_space:
        raise ValueError(
            f"Requested {n} HyTra-CIFAR samples, but only {total_unique_space} "
            "unique architectures exist. Lower --n-samples; do not duplicate latency samples."
        )

    base_targets = {
        "cnn_dominant": 300,
        "light_hybrid": 250,
        "balanced_hybrid": 500,
        "attention_dominant": 150,
    }
    if n != 1200:
        scale = n / 1200.0
        targets = {k: int(round(v * scale)) for k, v in base_targets.items()}
        delta = n - sum(targets.values())
        targets["balanced_hybrid"] += delta
    else:
        targets = dict(base_targets)

    buckets: Dict[str, List[Dict[str, Any]]] = {
        "cnn_dominant": [],
        "light_hybrid": [],
        "balanced_hybrid": [],
        "attention_dominant": [],
    }
    for candidate in all_candidates:
        buckets[candidate["group"]].append(candidate)
    for bucket in buckets.values():
        rng.shuffle(bucket)

    print("=" * 60)
    print(f"  SINH {n} MẪU STRATIFIED HYTRA-CIFAR UNIQUE")
    print("=" * 60)
    print(f"  Full unique space: {total_unique_space}")
    print(f"  Recommended thesis sizes: 800 or 1200")
    print(f"  Target allocation: {targets}")

    samples: List[Dict[str, Any]] = []
    seen_arch_strings: set[str] = set()
    shortfalls: Dict[str, int] = {}

    for group, target in targets.items():
        added = 0
        for candidate in buckets[group]:
            arch_str = candidate["arch_string"]
            if arch_str in seen_arch_strings:
                continue
            samples.append(dict(candidate))
            seen_arch_strings.add(arch_str)
            added += 1
            if added == target:
                break
        if added < target:
            shortfalls[group] = target - added
            print(
                f"  WARNING {group:20s}: generated {added}/{target} unique samples "
                f"from {len(buckets[group])} candidates; backfilling from remaining unique pool."
            )
        else:
            print(f"  OK {group:20s}: {added} samples from {len(buckets[group])} candidates")

    if len(samples) < n:
        remaining = [
            candidate for candidate in all_candidates
            if candidate["arch_string"] not in seen_arch_strings
        ]
        rng.shuffle(remaining)
        needed = n - len(samples)
        if needed > len(remaining):
            raise RuntimeError(
                f"Could not backfill {needed} unique HyTra-CIFAR samples; "
                f"only {len(remaining)} unique candidates remain."
            )
        for candidate in remaining[:needed]:
            samples.append(dict(candidate))
            seen_arch_strings.add(candidate["arch_string"])
        print(f"  OK backfill            : {needed} additional unique samples")

    rng.shuffle(samples)
    for i, sample in enumerate(samples):
        sample["arch_id"] = i

    arch_strings = [sample["arch_string"] for sample in samples]
    unique_samples = len(set(arch_strings))
    duplicate_count = len(arch_strings) - unique_samples
    if duplicate_count:
        raise RuntimeError(f"HyTra-CIFAR generation produced {duplicate_count} duplicate architecture strings")

    group_distribution: Dict[str, int] = {}
    resatt_distribution: Dict[str, int] = {}
    downsample_pattern_distribution: Dict[str, int] = {}
    width_mult_distribution: Dict[str, int] = {}
    for sample in samples:
        group_distribution[sample["group"]] = group_distribution.get(sample["group"], 0) + 1
        resatt_key = str(sample["n_resatt"])
        resatt_distribution[resatt_key] = resatt_distribution.get(resatt_key, 0) + 1
        pattern_key = str(sample["downsample_pattern"])
        downsample_pattern_distribution[pattern_key] = downsample_pattern_distribution.get(pattern_key, 0) + 1
        wm_key = _format_width_mult(float(sample["width_mult"]))
        width_mult_distribution[wm_key] = width_mult_distribution.get(wm_key, 0) + 1

    global LAST_CIFAR_GENERATION_METADATA
    LAST_CIFAR_GENERATION_METADATA = {
        "search_space": "hytra_cifar",
        "search_space_version": "micro_hytra_cifar_v1",
        "requested_samples": n,
        "seed": seed,
        "unique_samples": unique_samples,
        "seed": seed,
        "duplicate_count": duplicate_count,
        "total_unique_space": total_unique_space,
        "recommended_sample_sizes": [800, 1200],
        "architecture_schema": {
            "arch_string": "wm=<width_mult>|<block_type>@<scale>|... for 8 blocks",
            "op_indices": "3 stages with depths [3, 3, 2] using OP_INDEX_TO_TUPLE_CIFAR",
            "width_mult": WIDTH_MULTS_CIFAR,
            "input_size": 32,
        },
        "group_distribution": group_distribution,
        "resatt_distribution": resatt_distribution,
        "downsample_pattern_distribution": downsample_pattern_distribution,
        "width_mult_distribution": width_mult_distribution,
        "shortfalls_backfilled": shortfalls,
        "generated_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
    }
    return samples


def save_fixed_set(
    samples: List[Dict],
    output_path: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """
    Lưu 1200 mẫu ra JSON để tất cả devices đo cùng 1 set.

    QUAN TRỌNG: Tất cả devices phải load file này,
    không được generate lại riêng.
    """
    # Convert arch_tuples sang serializable format
    serializable = []
    for s in samples:
        record = {
            "arch_id":     s["arch_id"],
            "arch_string": s["arch_string"],
            "architecture_string": s["arch_string"],
            "architecture_string": s.get("architecture_string", s["arch_string"]),
            "op_indices":  s["op_indices"],   # [[4,2,0,1], ...]
            "downsample_pattern": s.get("downsample_pattern", []),
            "width_mult":  s.get("width_mult", 1.0),
            "group":       s["group"],
            "n_resatt":    s["n_resatt"],
            "complexity":  s.get("complexity", s.get("complexity_proxy")),
            "complexity_proxy": s.get("complexity_proxy", s.get("complexity")),
            # arch_tuples không JSON-serializable trực tiếp
            # → reconstruct từ arch_string khi load
        }
        serializable.append(record)

    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    payload = {
        "version": "1.0",
        "total": len(serializable),
        "description": "1200 stratified HyTra architectures for MHLP",
        "sampling": {
            "pure_conv": 250,
            "heavy_attn": 250,
            "hybrid": 450,
            "random": 250,
        },
        "architectures": serializable,
    }
    if metadata:
        if metadata.get("search_space") == "hytra_cifar":
            payload["description"] = "Unique stratified HyTra-CIFAR architectures for MHLP"
            payload["sampling"] = metadata.get("group_distribution", {})
        payload.update(metadata)

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)

    print(f"\n✅ Saved {len(serializable)} mẫu → {output_path}")
    print(f"   Copy file này sang TẤT CẢ devices trước khi đo!")


def load_fixed_set(json_path: str) -> List[Dict]:
    """Load file JSON và reconstruct arch_tuples từ arch_string."""
    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)

    samples = []
    for record in data["architectures"]:
        arch_string = record.get("arch_string") or record.get("architecture_string")
        if data.get("search_space") == "hytra_cifar" or arch_string.startswith("wm="):
            arch_obj = parse_hytra_cifar_arch_string(arch_string)
            arch_tuples = arch_obj["blocks"]
            width_mult = arch_obj["width_mult"]
        else:
            arch_tuples = _arch_string_to_tuples(arch_string)
            width_mult = record.get("width_mult", 1.0)
        samples.append({
            **record,
            "arch_string": arch_string,
            "architecture_string": arch_string,
            "arch_tuples": arch_tuples,
            "width_mult": width_mult,
        })

    print(f"✅ Loaded {len(samples)} mẫu từ {json_path}")
    return samples


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  PHẦN B: ĐO LATENCY TRÊN TỪNG DEVICE                                     ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def _measurement_metadata(
    *,
    search_space: str,
    proxy_model: str,
    input_size: int,
    batch_size: int,
    warmup_iters: int,
    measure_iters: int,
    device_used: str,
    hardware_label: str,
) -> Dict[str, Any]:
    metadata: Dict[str, Any] = {
        "search_space": search_space,
        "proxy_model": proxy_model,
        "input_size": input_size,
        "batch_size": batch_size,
        "warmup_iters": warmup_iters,
        "measure_iters": measure_iters,
        "device_used": device_used,
        "hardware_label": hardware_label,
        "torch_version": torch.__version__,
        "cuda_available": torch.cuda.is_available(),
        "measured_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
    }
    if torch.cuda.is_available():
        metadata["gpu_name"] = torch.cuda.get_device_name(0)
    return metadata


def measure_on_device(
    samples: List[Dict],
    device_name: str,
    hardware_label: str,
    *,
    input_size: int = 32,      # CIFAR size — không phải 224!
    batch_size: int = 1,
    warmup_iters: int = 20,
    measure_iters: int = 50,
    save_every: int = 50,
    output_path: str,
    resume: bool = True,
    search_space: str = "hytra_imagenet",
) -> List[Dict]:
    """
    Đo latency của tất cả mẫu trong samples trên device hiện tại.

    Args:
        samples:        List arch dicts từ load_fixed_set()
        device_name:    "cuda" | "mps" | "cpu"
        hardware_label: Tên thiết bị lưu vào CSV ("rtx4060", "macbook_m1", ...)
        input_size:     32 cho CIFAR, 224 cho ImageNet
        warmup_iters:   Số lần warmup (giảm xuống 20 vì CIFAR nhỏ hơn)
        measure_iters:  Số lần đo (giảm xuống 50 vì đo nhiều device)
        save_every:     Lưu checkpoint mỗi N mẫu
        output_path:    File JSON kết quả cho device này
        resume:         Tiếp tục từ checkpoint nếu bị interrupt

    Returns:
        List dicts với latency stats
    """
    # ── Kiểm tra device ──────────────────────────────────────────────────
    if device_name == "cuda":
        if not torch.cuda.is_available():
            print("⚠️  CUDA không khả dụng, fallback → cpu")
            device_name = "cpu"
        else:
            gpu_name = torch.cuda.get_device_name(0)
            print(f"  GPU: {gpu_name}")

    elif device_name == "mps":
        if not (hasattr(torch.backends, "mps") and
                torch.backends.mps.is_available()):
            print("⚠️  MPS không khả dụng, fallback → cpu")
            device_name = "cpu"
        else:
            print("  Device: Apple Silicon MPS")

    device = torch.device(device_name)
    proxy_model_name = "HyTraCIFARProxyModel" if search_space == "hytra_cifar" else "HyTraProxyModel"
    if search_space == "hytra_cifar":
        if input_size != 32:
            raise ValueError("HyTra-CIFAR latency measurement requires input_size=32")
        assert proxy_model_name == "HyTraCIFARProxyModel"
    run_metadata = _measurement_metadata(
        search_space=search_space,
        proxy_model=proxy_model_name,
        input_size=input_size,
        batch_size=batch_size,
        warmup_iters=warmup_iters,
        measure_iters=measure_iters,
        device_used=device_name,
        hardware_label=hardware_label,
    )

    # ── Resume logic ─────────────────────────────────────────────────────
    completed_ids = set()
    results = []

    if resume and os.path.exists(output_path):
        with open(output_path, encoding="utf-8") as f:
            existing = json.load(f)
        results = existing.get("measurements", [])
        completed_ids = {r["arch_id"] for r in results}
        print(f"  Resume: {len(completed_ids)} mẫu đã đo, "
              f"còn {len(samples) - len(completed_ids)} mẫu")

    remaining = [s for s in samples if s["arch_id"] not in completed_ids]

    print(f"\n  Bắt đầu đo {len(remaining)} mẫu...")
    print(f"  Input size: {input_size}×{input_size} (batch={batch_size})")
    print(f"  Warmup: {warmup_iters}, Measure: {measure_iters}")
    print(f"  Output: {output_path}")
    print(f"  Proxy model: {proxy_model_name}")
    print("-" * 60)

    input_tensor = torch.randn(
        batch_size, 3, input_size, input_size, device=device
    )

    failures = []
    t_start_total = time.time()

    for i, sample in enumerate(remaining):
        arch_id = sample["arch_id"]
        arch_tuples = sample["arch_tuples"]
        width_mult = float(sample.get("width_mult", 1.0))

        try:
            # Build model
            if search_space == "hytra_cifar":
                model = HyTraCIFARProxyModel(
                    arch_tuples, input_size=input_size, width_mult=width_mult
                ).to(device).eval()
            else:
                model = HyTraProxyModel(
                    arch_tuples, input_size=input_size
                ).to(device).eval()

            # Measure
            stats = measure_latency_full(
                model, input_tensor, device_name,
                warmup_iters=warmup_iters,
                measure_iters=measure_iters,
            )

            results.append({
                "arch_id":      arch_id,
                "arch_string":  sample["arch_string"],
                "architecture_string": sample["arch_string"],
                "hardware":     hardware_label,
                "device_used":  device_name,
                "input_size":   input_size,
                "proxy_model":  proxy_model_name,
                "latency_ms":   stats["median"],   # dùng median làm giá trị chính
                "stats":        stats,
                "group":        sample["group"],
                "n_resatt":     sample["n_resatt"],
            })

            # Cleanup
            del model
            if device_name == "cuda":
                torch.cuda.empty_cache()

            # Progress log
            elapsed = time.time() - t_start_total
            avg_per_sample = elapsed / (i + 1)
            remaining_count = len(remaining) - i - 1
            eta_min = remaining_count * avg_per_sample / 60

            print(f"  [{i+1:4d}/{len(remaining)}] "
                  f"arch#{arch_id:4d} | "
                  f"lat={stats['median']:7.2f}ms | "
                  f"resatt={sample['n_resatt']:2d} | "
                  f"ETA={eta_min:.0f}min")

        except Exception as e:
            print(f"  ❌ arch#{arch_id}: {e}")
            failures.append({"arch_id": arch_id, "error": str(e)})

        # Save checkpoint
        if (i + 1) % save_every == 0:
            _save_checkpoint(results, failures, hardware_label, output_path, metadata=run_metadata)
            print(f"  💾 Checkpoint saved ({len(results)} mẫu)")

    # Final save
    _save_checkpoint(results, failures, hardware_label, output_path, metadata=run_metadata)

    elapsed_total = time.time() - t_start_total
    print(f"\n{'='*60}")
    print(f"  ✅ HOÀN TẤT đo trên {hardware_label}")
    print(f"  Thành công: {len(results)} mẫu")
    print(f"  Thất bại  : {len(failures)} mẫu")
    print(f"  Thời gian : {elapsed_total/60:.1f} phút")
    print(f"  Kết quả   : {output_path}")

    return results


def _save_checkpoint(results, failures, hardware_label, output_path, metadata: Optional[Dict[str, Any]] = None):
    """Lưu checkpoint để resume nếu bị interrupt."""
    payload = {
        "hardware": hardware_label,
        "total": len(results),
        "total_measured": len(results),
        "total_failed": len(failures),
        "measurements": results,
        "failures": failures,
        "measured_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
    }
    if metadata:
        payload.update(metadata)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  PHẦN C: AGGREGATE TẤT CẢ DEVICES → CSV CUỐI CÙNG                       ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def aggregate_all_devices(
    result_files: List[str],
    output_csv: str,
    output_json: str,
) -> None:
    """
    Gộp kết quả từ tất cả devices thành 1 CSV duy nhất cho MHLP.

    CSV format (giống pipeline gốc):
        architecture_string, hardware_type, latency_ms

    Args:
        result_files: List đường dẫn các file JSON từng device
        output_csv:   File CSV đầu ra
        output_json:  File JSON metadata
    """
    import csv

    all_rows = []
    summary = {}

    for fpath in result_files:
        if not os.path.exists(fpath):
            print(f"⚠️  Không tìm thấy: {fpath}")
            continue

        with open(fpath, encoding="utf-8") as f:
            data = json.load(f)

        hardware = data["hardware"]
        measurements = data["measurements"]

        print(f"  {hardware:20s}: {len(measurements):4d} mẫu")
        summary[hardware] = len(measurements)

        for m in measurements:
            all_rows.append({
                "architecture_string": m.get("architecture_string") or m["arch_string"],
                "hardware_type":       m["hardware"],
                "latency_ms":          m["latency_ms"],
            })

    # Lưu CSV
    with open(output_csv, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["architecture_string", "hardware_type", "latency_ms"]
        )
        writer.writeheader()
        writer.writerows(all_rows)

    # Lưu JSON metadata
    metadata: Dict[str, Any] = {
        "total_rows": len(all_rows),
        "devices": summary,
        "description": "MHLP latency dataset",
    }
    for fpath in result_files:
        if os.path.exists(fpath):
            with open(fpath, encoding="utf-8") as f:
                first = json.load(f)
            for key in [
                "search_space", "proxy_model", "input_size", "batch_size",
                "warmup_iters", "measure_iters", "device_used", "hardware_label",
                "torch_version", "cuda_available", "gpu_name",
            ]:
                if key in first:
                    metadata[key] = first[key]
            break
    with open(output_json, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print(f"\n✅ Aggregate hoàn tất")
    print(f"   CSV : {output_csv} ({len(all_rows)} dòng)")
    print(f"   Devices: {list(summary.keys())}")


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  CLI                                                                      ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def parse_args():
    p = argparse.ArgumentParser(
        description="Generate 1200 stratified samples + measure latency",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    p.add_argument("--phase", required=True,
                   choices=["generate", "measure", "aggregate"],
                   help=(
                       "generate: sinh 1200 mẫu (chạy 1 lần trên server) | "
                       "measure: đo latency (chạy trên từng device) | "
                       "aggregate: gộp tất cả → CSV"
                   ))
    p.add_argument("--search-space", default="hytra_imagenet",
                   choices=["hytra_imagenet", "hytra_cifar"],
                   help="Search space to generate/measure")

    # Generate phase
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--fixed-set", type=str,
                   default=os.path.join(_SCRIPT_DIR, "arch_1200_fixed.json"),
                   help="Path file JSON chứa 1200 mẫu cố định")

    # Measure phase
    p.add_argument("--device", type=str, default="cuda",
                   choices=["cuda", "mps", "cpu"])
    p.add_argument("--device-name", type=str, default=None,
                   help="Label thiết bị: rtx4060, rtx3050, rtx5060, "
                        "macbook_m1, windows_cpu, raspi4")
    p.add_argument("--input-size", type=int, default=32,
                   help="Input image size (32 cho CIFAR, 224 cho ImageNet)")
    p.add_argument("--batch-size", type=int, default=1)
    p.add_argument("--warmup", type=int, default=20)
    p.add_argument("--runs", type=int, default=50)
    p.add_argument("--n-samples", type=int, default=1200,
                   help="Số mẫu cần đo (Raspi dùng 600)")
    p.add_argument("--allow-duplicates", action="store_true",
                   help="Allow duplicate architecture strings in HyTra-CIFAR generation")
    p.add_argument("--output-dir", type=str,
                   default=os.path.join(_SCRIPT_DIR, "latency_raw"),
                   help="Thư mục lưu kết quả từng device")
    p.add_argument("--no-resume", action="store_true",
                   help="Đo lại từ đầu, không resume")

    # Aggregate phase
    p.add_argument("--output-csv", type=str,
                   default=os.path.join(_SCRIPT_DIR, "hytra_latency_dataset_1200.csv"))
    p.add_argument("--output-json", type=str,
                   default=os.path.join(_SCRIPT_DIR, "hytra_latency_dataset_1200.json"))

    return p.parse_args()


def main():
    args = parse_args()

    if (
        args.search_space == "hytra_cifar"
        and os.path.basename(args.fixed_set) == "arch_1200_fixed.json"
    ):
        args.fixed_set = os.path.join(_SCRIPT_DIR, "arch_1200_cifar_fixed.json")

    # Canonicalize paths so the script works from any cwd.
    args.fixed_set = _resolve_path(args.fixed_set)
    args.output_dir = _resolve_path(args.output_dir)
    args.output_csv = _resolve_path(args.output_csv)
    args.output_json = _resolve_path(args.output_json)

    # ── PHASE: generate ──────────────────────────────────────────────────
    if args.phase == "generate":
        print(f"\n🔧 PHASE: GENERATE {args.n_samples} MẪU STRATIFIED")
        if args.search_space == "hytra_cifar":
            samples = generate_stratified_cifar(
                seed=args.seed,
                n=args.n_samples,
                allow_duplicates=args.allow_duplicates,
            )
            metadata = LAST_CIFAR_GENERATION_METADATA
        else:
            samples = generate_stratified_1200(seed=args.seed)
            metadata = None
        save_fixed_set(samples, args.fixed_set, metadata=metadata)
        print(f"\n📋 BƯỚC TIẾP THEO:")
        print(f"   1. Copy file '{args.fixed_set}' sang tất cả devices")
        print(f"   2. Chạy trên RTX 4060:")
        print(f"      python generate_1200_samples.py --phase measure "
              f"--device cuda --device-name rtx4060")
        print(f"   3. Chạy tương tự trên các device khác")
        print(f"   4. Sau khi tất cả xong, chạy aggregate")

    # ── PHASE: measure ───────────────────────────────────────────────────
    elif args.phase == "measure":
        if args.device_name is None:
            print("❌ Cần chỉ định --device-name")
            print("   Ví dụ: --device-name rtx4060")
            sys.exit(1)

        if not os.path.exists(args.fixed_set):
            print(f"❌ Không tìm thấy file: {args.fixed_set}")
            print(f"   Chạy phase generate trước!")
            sys.exit(1)

        print(f"\n📏 PHASE: ĐO LATENCY trên {args.device_name.upper()}")

        # Load fixed set
        samples = load_fixed_set(args.fixed_set)

        # Giới hạn số mẫu nếu cần (Raspi)
        if args.n_samples < len(samples):
            print(f"  Giới hạn: {args.n_samples}/{len(samples)} mẫu")
            samples = samples[:args.n_samples]

        # Output path
        os.makedirs(args.output_dir, exist_ok=True)
        output_path = os.path.join(
            args.output_dir,
            f"{args.device_name}.json"
        )

        # Measure
        measure_on_device(
            samples=samples,
            device_name=args.device,
            hardware_label=args.device_name,
            input_size=args.input_size,
            batch_size=args.batch_size,
            warmup_iters=args.warmup,
            measure_iters=args.runs,
            output_path=output_path,
            resume=not args.no_resume,
            search_space=args.search_space,
        )

    # ── PHASE: aggregate ─────────────────────────────────────────────────
    elif args.phase == "aggregate":
        print("\n📦 PHASE: AGGREGATE TẤT CẢ DEVICES")

        output_csv_raw_dir = os.path.join(os.path.dirname(args.output_csv), "latency_raw")
        fixed_set_raw_dir = os.path.join(os.path.dirname(args.fixed_set), "latency_raw")
        raw_dir = output_csv_raw_dir if os.path.exists(output_csv_raw_dir) else fixed_set_raw_dir

        # Tự động tìm tất cả file JSON trong thư mục raw
        result_files = []
        if os.path.exists(raw_dir):
            for fname in sorted(os.listdir(raw_dir)):
                if fname.endswith(".json"):
                    result_files.append(os.path.join(raw_dir, fname))

        if not result_files:
            print(f"❌ Không tìm thấy file kết quả trong {raw_dir}")
            sys.exit(1)

        print(f"  Tìm thấy {len(result_files)} device files:")
        for f in result_files:
            print(f"    - {os.path.basename(f)}")

        aggregate_all_devices(
            result_files=result_files,
            output_csv=args.output_csv,
            output_json=args.output_json,
        )


if __name__ == "__main__":
    main()
