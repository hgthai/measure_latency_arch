#!/usr/bin/env python3
"""
Train MHLP Model — Multihardware Adaptive Latency Prediction
=============================================================

Script huấn luyện mô hình MHLP trên dữ liệu latency thực đo từ 3 thiết bị:
  - RTX 4080 SUPER (Desktop GPU)
  - iPhone 15 (Mobile NPU/GPU)
  - MacBook M1 (Laptop ARM SoC)

Dữ liệu đầu vào: CSV với cột (architecture_string, hardware_type, latency_ms)
Architecture string: "ResConv@0.125|ResAtt@0.0625|..." (16 blocks, pipe-separated)

Pipeline:
  1. Đọc CSV → parse architecture strings → encode DAG (19 nodes, 14 features)
    2. Encode hardware → MHLP paper 5D binary vector
  3. Train/Val/Test split (80/10/10)
  4. Huấn luyện với MSE + Rank loss
  5. Đánh giá: MAPE, SRCC (Spearman Rank Correlation Coefficient)
  6. Lưu checkpoint tốt nhất

Usage:
    python train_mhlp.py --data_path hytra_latency_dataset.csv --epochs 300
    python train_mhlp.py --eval --checkpoint mhlp_best.pth --data_path hytra_latency_dataset.csv

Author: MHLP Team — Khóa luận tốt nghiệp
"""

import os
import sys
import csv
import json
import time
import argparse
import warnings
from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

# ── Local imports ──
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from hytra_encoding import (
    encode_hytra_dag,
    encode_hardware,
    HyTraMHLPDataset,
    create_dataloaders,
    NUM_GRAPH_NODES,
    NODE_FEATURE_DIM,
    HW_ENCODING_DIM,
)
from mhlp_predictor import MHLPPredictor, train_one_epoch, evaluate


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  1. PARSE ARCHITECTURE STRING → TUPLES                                 ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def arch_string_to_tuples(s: str) -> List[Tuple[str, float]]:
    """
    Parse architecture string thành list of tuples.

    "ResConv@0.125|ResAtt@0.0625|..." → [("ResConv", 0.125), ("ResAtt", 0.0625), ...]
    """
    parts = s.strip().split("|")
    tuples = []
    for p in parts:
        bt, sr = p.split("@")
        tuples.append((bt, float(sr)))
    return tuples


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  2. LOAD CSV → LIST OF DICTS                                           ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def load_csv_data(csv_path: str, log_transform: bool = False) -> List[Dict]:
    """
    Đọc CSV và chuyển thành list of dicts cho HyTraMHLPDataset.

    CSV columns: architecture_string, hardware_type, latency_ms

    Args:
        csv_path: Path to CSV file
        log_transform: If True, apply log(latency) transform.
            This helps MAPE by equalizing relative errors across
            different latency ranges.

    Returns:
        List of {'arch': list_of_tuples, 'hardware': str, 'latency': float}
    """
    data = []
    skipped = 0

    with open(csv_path, "r") as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                arch_str = row["architecture_string"]
                hw_name = row["hardware_type"]
                latency = float(row["latency_ms"])

                # Parse architecture string → tuples
                arch_tuples = arch_string_to_tuples(arch_str)

                if len(arch_tuples) != 16:
                    skipped += 1
                    continue

                data.append({
                    "arch": arch_tuples,
                    "hardware": hw_name,
                    "latency": np.log(latency) if log_transform else latency,
                    "latency_ms": latency,  # Keep original for metrics
                })
            except (ValueError, KeyError) as e:
                skipped += 1
                continue

    print(f"[INFO] Loaded {len(data)} samples from {csv_path}")
    if skipped > 0:
        print(f"[WARN] Skipped {skipped} invalid rows")

    # Hardware distribution
    hw_counts = {}
    for d in data:
        hw_counts[d["hardware"]] = hw_counts.get(d["hardware"], 0) + 1
    print(f"[INFO] Hardware distribution: {hw_counts}")

    # Latency stats
    lats = [d["latency_ms"] for d in data]
    print(f"[INFO] Latency: min={min(lats):.3f}, max={max(lats):.3f}, "
          f"mean={np.mean(lats):.3f}, median={np.median(lats):.3f} ms")

    return data


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  3. METRICS: MAPE, SRCC, KENDALL TAU                                   ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def compute_mape(preds: np.ndarray, targets: np.ndarray) -> float:
    """Mean Absolute Percentage Error (%)."""
    mask = np.abs(targets) > 1e-6  # Avoid division by zero
    if mask.sum() == 0:
        return float("inf")
    return 100.0 * np.mean(np.abs((preds[mask] - targets[mask]) / targets[mask]))


def compute_srcc(preds: np.ndarray, targets: np.ndarray) -> float:
    """Spearman Rank Correlation Coefficient."""
    from scipy.stats import spearmanr
    corr, pval = spearmanr(preds, targets)
    return corr


def compute_kendall_tau(preds: np.ndarray, targets: np.ndarray) -> float:
    """Kendall Tau rank correlation."""
    from scipy.stats import kendalltau
    corr, pval = kendalltau(preds, targets)
    return corr


def compute_all_metrics(
    preds: np.ndarray, targets: np.ndarray
) -> Dict[str, float]:
    """Compute all evaluation metrics."""
    return {
        "mse":  float(np.mean((preds - targets) ** 2)),
        "rmse": float(np.sqrt(np.mean((preds - targets) ** 2))),
        "mae":  float(np.mean(np.abs(preds - targets))),
        "mape": compute_mape(preds, targets),
        "srcc": compute_srcc(preds, targets),
        "kendall_tau": compute_kendall_tau(preds, targets),
        "r2": float(1.0 - np.sum((preds - targets) ** 2)
                     / max(np.sum((targets - targets.mean()) ** 2), 1e-8)),
    }


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  4. RANK LOSS (Hỗ trợ ordering constraint)                             ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class RankLoss(nn.Module):
    """
    Pairwise rank loss: khuyến khích mô hình bảo toàn thứ tự latency.

    Nếu target_i > target_j thì pred_i nên > pred_j.
    Loss = max(0, margin - (pred_i - pred_j)) khi target_i > target_j.
    """

    def __init__(self, margin: float = 0.1):
        super().__init__()
        self.margin = margin

    def forward(
        self, preds: torch.Tensor, targets: torch.Tensor
    ) -> torch.Tensor:
        """
        Args:
            preds:   (B, 1) predicted latencies
            targets: (B, 1) target latencies
        """
        preds = preds.squeeze(-1)      # (B,)
        targets = targets.squeeze(-1)  # (B,)
        B = preds.shape[0]
        if B < 2:
            return torch.tensor(0.0, device=preds.device)

        # Subsample pairs for efficiency (avoid O(B²) memory)
        max_pairs = min(B, 32)
        idx = torch.randperm(B, device=preds.device)[:max_pairs]
        p_sub = preds[idx]
        t_sub = targets[idx]

        # Pairwise differences
        pred_diff = p_sub.unsqueeze(1) - p_sub.unsqueeze(0)      # (M, M)
        target_diff = t_sub.unsqueeze(1) - t_sub.unsqueeze(0)    # (M, M)

        # Mask: only consider pairs where target_i > target_j
        mask = (target_diff > 0).float()

        # Hinge loss: max(0, margin - pred_diff) when target_i > target_j
        loss = F.relu(self.margin - pred_diff) * mask

        # Average over valid pairs
        num_pairs = mask.sum()
        if num_pairs > 0:
            return loss.sum() / num_pairs
        return torch.tensor(0.0, device=preds.device)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  5. COMBINED LOSS                                                       ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class CombinedLoss(nn.Module):
    """MSE + λ_rank × RankLoss.

    Note: Không dùng MAPE-like loss trên z-score normalized targets
    vì targets ≈ 0 gây division by zero → NaN.
    """

    def __init__(
        self,
        lambda_rank: float = 0.1,
        lambda_mape: float = 0.0,  # Disabled for z-score normalized targets
        rank_margin: float = 0.1,
    ):
        super().__init__()
        self.mse = nn.SmoothL1Loss()  # Huber loss: robust to outliers
        self.rank_loss = RankLoss(margin=rank_margin)
        self.lambda_rank = lambda_rank

    def forward(
        self, preds: torch.Tensor, targets: torch.Tensor
    ) -> torch.Tensor:
        loss_mse = self.mse(preds, targets)
        loss_rank = self.rank_loss(preds, targets)

        total = loss_mse + self.lambda_rank * loss_rank
        return total


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  6. TRAINING LOOP                                                       ║
# ╚══════════════════════════════════════════════════════════════════════════╝

@torch.no_grad()
def evaluate_full(
    model: MHLPPredictor,
    loader: DataLoader,
    dataset: HyTraMHLPDataset,
    device: torch.device,
    log_transform: bool = False,
) -> Dict[str, float]:
    """
    Đánh giá toàn diện: denormalize predictions → tính metrics trên giá trị thực (ms).

    Args:
        log_transform: If True, apply exp() after denormalization to get ms.

    Returns:
        Dict with keys: mse, rmse, mae, mape, srcc, kendall_tau, r2
    """
    model.eval()
    all_preds, all_targets = [], []

    for X, A, hw, lat in loader:
        X, A, hw, lat = X.to(device), A.to(device), hw.to(device), lat.to(device)
        pred = model(X, A, hw)
        all_preds.append(pred.cpu())
        all_targets.append(lat.cpu())

    preds = torch.cat(all_preds).numpy().flatten()
    targets = torch.cat(all_targets).numpy().flatten()

    # Denormalize về ms thực
    preds_ms = dataset.denormalize(torch.tensor(preds)).numpy()
    targets_ms = dataset.denormalize(torch.tensor(targets)).numpy()

    # If log-transformed, apply exp to get ms
    if log_transform:
        preds_ms = np.exp(preds_ms)
        targets_ms = np.exp(targets_ms)

    metrics = compute_all_metrics(preds_ms, targets_ms)
    return metrics


def train(args):
    """Main training function."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\n{'═' * 72}")
    print(f"  MHLP Training — Multihardware Adaptive Latency Prediction")
    print(f"{'═' * 72}")
    print(f"  Device: {device}")
    print(f"  Data:   {args.data_path}")
    print(f"  Epochs: {args.epochs}")
    print(f"  LR:     {args.lr}")
    print(f"  Batch:  {args.batch_size}")
    print(f"{'═' * 72}\n")

    # ── 1. Load data ──
    data = load_csv_data(args.data_path, log_transform=args.log_transform)
    use_log = args.log_transform
    if use_log:
        print(f"  [INFO] Using log-transform on latency")

    # Oversample minority hardware classes for balanced training
    if args.oversample:
        hw_counts = {}
        hw_data = {}
        for d in data:
            hw = d["hardware"]
            hw_counts[hw] = hw_counts.get(hw, 0) + 1
            if hw not in hw_data:
                hw_data[hw] = []
            hw_data[hw].append(d)

        max_count = max(hw_counts.values())
        augmented = []
        for hw, items in hw_data.items():
            rng = np.random.RandomState(args.seed)
            n_extra = max_count - len(items)
            if n_extra > 0:
                extra_idx = rng.choice(len(items), size=n_extra, replace=True)
                augmented.extend(items)
                augmented.extend([items[i] for i in extra_idx])
                print(f"  [INFO] Oversampled {hw}: {len(items)} → {max_count}")
            else:
                augmented.extend(items)

        data = augmented
        print(f"  [INFO] After oversampling: {len(data)} total samples")

    # ── 2. Create dataset ──
    dataset = HyTraMHLPDataset(
        data=data,
        normalize_latency=True,
    )

    # ── 3. Create dataloaders ──
    train_loader, val_loader, test_loader = create_dataloaders(
        dataset,
        batch_size=args.batch_size,
        train_ratio=0.8,
        val_ratio=0.1,
        seed=args.seed,
    )

    # ── 4. Create model ──
    model = MHLPPredictor(
        node_feat_dim=NODE_FEATURE_DIM,    # 14
        hw_input_dim=HW_ENCODING_DIM,      # 5 (MHLP paper 5D encoding)
        gcn_hidden_dim=args.gcn_hidden,     # 128
        mlp_hidden_dim=args.mlp_hidden,     # 64
        embed_dim=args.embed_dim,           # 128
        num_gcn_layers=args.num_gcn_layers, # 3
        num_attn_heads=args.num_attn_heads, # 4
        ffn_dim=args.ffn_dim,               # 512
        predictor_hidden=args.pred_hidden,  # 128
        dropout=args.dropout,               # 0.1
    ).to(device)

    total_params = model.count_parameters()
    print(f"\n  Model: MHLPPredictor ({total_params:,} params)")
    for name, count in model.get_component_params().items():
        pct = 100.0 * count / total_params
        print(f"    {name:22s}: {count:>8,}  ({pct:5.1f}%)")

    # ── 5. Loss, optimizer, scheduler ──
    criterion = CombinedLoss(
        lambda_rank=args.lambda_rank,
        lambda_mape=args.lambda_mape,
    )

    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )

    # Cosine annealing with warm restarts
    scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
        optimizer,
        T_0=args.T_0,            # First restart period
        T_mult=args.T_mult,      # Period multiplier after restart
        eta_min=args.lr * 0.01,  # Minimum LR = 1% of initial
    )

    # ── 6. Training loop ──
    best_val_mape = float("inf")
    best_val_srcc = -1.0
    best_epoch = 0
    patience_counter = 0
    history = []

    print(f"\n{'─' * 72}")
    print(f"  Training started...")
    print(f"{'─' * 72}")
    print(f"  {'Epoch':>5s}  {'Train Loss':>10s}  {'Val MSE':>8s}  "
          f"{'Val MAE':>8s}  {'Val MAPE':>9s}  {'Val SRCC':>9s}  "
          f"{'LR':>10s}  {'Best':>4s}")
    print(f"  {'─' * 5}  {'─' * 10}  {'─' * 8}  {'─' * 8}  "
          f"{'─' * 9}  {'─' * 9}  {'─' * 10}  {'─' * 4}")

    start_time = time.time()

    for epoch in range(1, args.epochs + 1):
        # Train
        model.train()
        total_loss = 0.0
        num_batches = 0

        for X, A, hw, lat in train_loader:
            X, A, hw, lat = X.to(device), A.to(device), hw.to(device), lat.to(device)
            pred = model(X, A, hw)
            loss = criterion(pred, lat)

            optimizer.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            total_loss += loss.item()
            num_batches += 1

        train_loss = total_loss / max(num_batches, 1)
        scheduler.step()

        # Evaluate on validation set
        val_metrics = evaluate_full(model, val_loader, dataset, device, log_transform=use_log)
        val_mape = val_metrics["mape"]
        val_srcc = val_metrics["srcc"]
        val_mse = val_metrics["mse"]
        val_mae = val_metrics["mae"]
        current_lr = optimizer.param_groups[0]["lr"]

        is_best = val_mape < best_val_mape
        if is_best:
            best_val_mape = val_mape
            best_val_srcc = val_srcc
            best_epoch = epoch
            patience_counter = 0

            # Save best checkpoint
            # Convert args to pure Python types (avoid numpy in checkpoint)
            args_dict = {}
            for k, v in vars(args).items():
                if isinstance(v, (int, float, str, bool, type(None))):
                    args_dict[k] = v
                else:
                    args_dict[k] = str(v)

            checkpoint = {
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "scheduler_state_dict": scheduler.state_dict(),
                "val_mape": float(val_mape),
                "val_srcc": float(val_srcc),
                "val_metrics": {k: float(v) for k, v in val_metrics.items()},
                "latency_mean": float(dataset.latency_mean),
                "latency_std": float(dataset.latency_std),
                "args": args_dict,
            }
            ckpt_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)),
                args.checkpoint,
            )
            torch.save(checkpoint, ckpt_path)
        else:
            patience_counter += 1

        # Log
        best_flag = " ★" if is_best else ""
        history.append({
            "epoch": epoch,
            "train_loss": float(train_loss),
            "val_mape": float(val_mape),
            "val_srcc": float(val_srcc),
            "val_mse": float(val_mse),
            "val_mae": float(val_mae),
            "lr": float(current_lr),
        })

        if epoch <= 10 or epoch % args.log_every == 0 or is_best or epoch == args.epochs:
            print(f"  {epoch:5d}  {train_loss:10.6f}  {val_mse:8.4f}  "
                  f"{val_mae:8.4f}  {val_mape:8.3f}%  {val_srcc:9.6f}  "
                  f"{current_lr:10.2e}{best_flag}")

        # Early stopping
        if patience_counter >= args.patience:
            print(f"\n  ⚠ Early stopping at epoch {epoch} "
                  f"(no improvement for {args.patience} epochs)")
            break

    elapsed = time.time() - start_time

    # ── 7. Final evaluation on test set ──
    print(f"\n{'═' * 72}")
    print(f"  Training completed in {elapsed:.1f}s ({elapsed/60:.1f}min)")
    print(f"{'═' * 72}")
    print(f"  Best epoch: {best_epoch}")
    print(f"  Best val MAPE: {best_val_mape:.3f}%")
    print(f"  Best val SRCC: {best_val_srcc:.6f}")

    # Load best checkpoint for test evaluation
    ckpt_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        args.checkpoint,
    )
    if not os.path.exists(ckpt_path):
        print("\n  ⚠ No checkpoint saved (training may have diverged).")
        print("    Evaluating with final model weights instead.")
    else:
        checkpoint = torch.load(ckpt_path, map_location=device, weights_only=False)
        model.load_state_dict(checkpoint["model_state_dict"])

    test_metrics = evaluate_full(model, test_loader, dataset, device, log_transform=use_log)

    print(f"\n{'─' * 72}")
    print(f"  TEST SET EVALUATION (best checkpoint, epoch {best_epoch})")
    print(f"{'─' * 72}")
    print(f"    MSE:         {test_metrics['mse']:.6f}")
    print(f"    RMSE:        {test_metrics['rmse']:.4f} ms")
    print(f"    MAE:         {test_metrics['mae']:.4f} ms")
    print(f"    MAPE:        {test_metrics['mape']:.3f}%")
    print(f"    SRCC:        {test_metrics['srcc']:.6f}")
    print(f"    Kendall Tau: {test_metrics['kendall_tau']:.6f}")
    print(f"    R²:          {test_metrics['r2']:.6f}")

    # Target check
    mape_ok = test_metrics["mape"] < 5.0
    srcc_ok = test_metrics["srcc"] > 0.95
    print(f"\n  Targets:")
    print(f"    MAPE  < 5%:   {'✅ PASS' if mape_ok else '❌ FAIL'} ({test_metrics['mape']:.3f}%)")
    print(f"    SRCC  > 0.95: {'✅ PASS' if srcc_ok else '❌ FAIL'} ({test_metrics['srcc']:.6f})")

    # Per-hardware evaluation
    print(f"\n{'─' * 72}")
    print(f"  PER-HARDWARE EVALUATION")
    print(f"{'─' * 72}")

    evaluate_per_hardware(model, dataset, data, device, log_transform=use_log)

    # Save training history
    history_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "training_history.json",
    )
    with open(history_path, "w") as f:
        json.dump(history, f, indent=2)
    print(f"\n  Training history saved to: training_history.json")
    print(f"  Best checkpoint saved to:  {args.checkpoint}")
    print(f"{'═' * 72}")


def evaluate_per_hardware(
    model: MHLPPredictor,
    dataset: HyTraMHLPDataset,
    data: List[Dict],
    device: torch.device,
    log_transform: bool = False,
):
    """Evaluate per hardware type."""
    model.eval()

    # Group by hardware
    hw_groups = {}
    for i, d in enumerate(data):
        hw = d["hardware"]
        if hw not in hw_groups:
            hw_groups[hw] = []
        hw_groups[hw].append(i)

    for hw_name, indices in sorted(hw_groups.items()):
        preds_list = []
        targets_list = []

        for idx in indices:
            X, A, hw, lat = dataset[idx]
            X = X.unsqueeze(0).to(device)
            A = A.unsqueeze(0).to(device)
            hw = hw.unsqueeze(0).to(device)

            with torch.no_grad():
                pred = model(X, A, hw)

            # Denormalize
            pred_ms = dataset.denormalize(pred.cpu()).item()
            target_ms = dataset.denormalize(lat).item()

            if log_transform:
                pred_ms = np.exp(pred_ms)
                target_ms = np.exp(target_ms)

            preds_list.append(pred_ms)
            targets_list.append(target_ms)

        preds_arr = np.array(preds_list)
        targets_arr = np.array(targets_list)

        metrics = compute_all_metrics(preds_arr, targets_arr)
        print(f"\n  {hw_name} ({len(indices)} samples):")
        print(f"    MAPE: {metrics['mape']:.3f}%  |  SRCC: {metrics['srcc']:.6f}  |  "
              f"MAE: {metrics['mae']:.4f}ms  |  RMSE: {metrics['rmse']:.4f}ms")


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  7. EVALUATION-ONLY MODE                                                ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def eval_only(args):
    """Load checkpoint and evaluate."""
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(f"\n{'═' * 72}")
    print(f"  MHLP Evaluation — Loading checkpoint")
    print(f"{'═' * 72}")

    # Load data
    use_log = args.log_transform
    data = load_csv_data(args.data_path, log_transform=use_log)
    dataset = HyTraMHLPDataset(data=data, normalize_latency=True)
    _, _, test_loader = create_dataloaders(
        dataset, batch_size=args.batch_size, seed=args.seed,
    )

    # Load model
    ckpt_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        args.checkpoint,
    )
    checkpoint = torch.load(ckpt_path, map_location=device, weights_only=False)

    saved_args = checkpoint.get("args", {})
    model = MHLPPredictor(
        node_feat_dim=NODE_FEATURE_DIM,
        hw_input_dim=HW_ENCODING_DIM,
        gcn_hidden_dim=saved_args.get("gcn_hidden", 128),
        mlp_hidden_dim=saved_args.get("mlp_hidden", 64),
        embed_dim=saved_args.get("embed_dim", 128),
        num_gcn_layers=saved_args.get("num_gcn_layers", 3),
        num_attn_heads=saved_args.get("num_attn_heads", 4),
        ffn_dim=saved_args.get("ffn_dim", 512),
        predictor_hidden=saved_args.get("pred_hidden", 128),
        dropout=saved_args.get("dropout", 0.1),
    ).to(device)

    model.load_state_dict(checkpoint["model_state_dict"])
    print(f"  Loaded checkpoint from epoch {checkpoint.get('epoch', '?')}")
    print(f"  Checkpoint val MAPE: {checkpoint.get('val_mape', '?'):.3f}%")

    # Evaluate
    test_metrics = evaluate_full(model, test_loader, dataset, device, log_transform=use_log)

    print(f"\n{'─' * 72}")
    print(f"  TEST SET EVALUATION")
    print(f"{'─' * 72}")
    for k, v in test_metrics.items():
        if k == "mape":
            print(f"    {k:15s}: {v:.3f}%")
        else:
            print(f"    {k:15s}: {v:.6f}")

    print(f"\n  Per-hardware:")
    evaluate_per_hardware(model, dataset, data, device, log_transform=use_log)
    print(f"{'═' * 72}")


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  8. ARGUMENT PARSER                                                     ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def parse_args():
    parser = argparse.ArgumentParser(
        description="Train MHLP Latency Predictor",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    # Data
    parser.add_argument("--data_path", type=str, required=True,
                        help="Path to CSV (architecture_string, hardware_type, latency_ms)")
    parser.add_argument("--seed", type=int, default=42,
                        help="Random seed for reproducibility")
    parser.add_argument("--log_transform", action="store_true",
                        help="Apply log-transform to latency before training. "
                             "Improves MAPE by equalizing relative errors across "
                             "different latency ranges.")
    parser.add_argument("--oversample", action="store_true",
                        help="Oversample minority hardware classes to balance training.")

    # Model architecture
    parser.add_argument("--gcn_hidden", type=int, default=128,
                        help="GCN hidden dimension")
    parser.add_argument("--mlp_hidden", type=int, default=64,
                        help="Hardware MLP hidden dimension")
    parser.add_argument("--embed_dim", type=int, default=128,
                        help="Embedding dimension (shared between components)")
    parser.add_argument("--num_gcn_layers", type=int, default=3,
                        help="Number of GCN layers")
    parser.add_argument("--num_attn_heads", type=int, default=4,
                        help="Number of attention heads")
    parser.add_argument("--ffn_dim", type=int, default=512,
                        help="FFN hidden dimension in attention fusion")
    parser.add_argument("--pred_hidden", type=int, default=128,
                        help="Predictor hidden dimension")
    parser.add_argument("--dropout", type=float, default=0.1,
                        help="Dropout rate")

    # Training
    parser.add_argument("--epochs", type=int, default=300,
                        help="Number of training epochs")
    parser.add_argument("--batch_size", type=int, default=64,
                        help="Batch size")
    parser.add_argument("--lr", type=float, default=1e-3,
                        help="Initial learning rate")
    parser.add_argument("--weight_decay", type=float, default=1e-4,
                        help="Weight decay (L2 regularization)")
    parser.add_argument("--patience", type=int, default=50,
                        help="Early stopping patience")
    parser.add_argument("--log_every", type=int, default=10,
                        help="Print log every N epochs")

    # Loss weights
    parser.add_argument("--lambda_rank", type=float, default=0.1,
                        help="Weight for rank loss")
    parser.add_argument("--lambda_mape", type=float, default=0.05,
                        help="Weight for MAPE-like loss")

    # Scheduler
    parser.add_argument("--T_0", type=int, default=30,
                        help="CosineAnnealingWarmRestarts T_0")
    parser.add_argument("--T_mult", type=int, default=2,
                        help="CosineAnnealingWarmRestarts T_mult")

    # Checkpoint
    parser.add_argument("--checkpoint", type=str, default="mhlp_best.pth",
                        help="Checkpoint filename")

    # Mode
    parser.add_argument("--eval", action="store_true",
                        help="Evaluation-only mode (requires --checkpoint)")

    return parser.parse_args()


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  MAIN                                                                   ║
# ╚══════════════════════════════════════════════════════════════════════════╝

if __name__ == "__main__":
    args = parse_args()

    # Reproducibility
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(args.seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False

    if args.eval:
        eval_only(args)
    else:
        train(args)
