#!/usr/bin/env python3
"""
MAML Training Loop for MHLP — Model-Agnostic Meta-Learning
===========================================================

Huấn luyện bộ dự đoán MHLP bằng Meta-Learning (MAML) để có khả năng
khái quát hóa trên nhiều thiết bị phần cứng. Mỗi thiết bị phần cứng
được xem là một "Task" (Tác vụ) riêng biệt.

Phương pháp: MAML (Finn et al., 2017)
  - Outer Loop (Meta-level):  Cập nhật tham số toàn cục θ
  - Inner Loop (Task-level):  Thích nghi θ → θ'_t cho task t

Pipeline mỗi meta-step:
  1. Với mỗi task (hardware device) trong meta-batch:
     a. Lấy batch dữ liệu → Chia thành Support Set và Query Set
     b. Inner Loop: Tính loss trên Support → gradient descent → fast weights
     c. Outer Loop: Tính meta-loss trên Query với fast weights
  2. Cộng dồn meta-loss qua tất cả tasks
  3. Cập nhật θ bằng meta_optimizer.step()

Usage:
    from train_meta_learning import train_meta_learning, create_task_dataloaders

    # Tạo dataloaders cho từng hardware
    dataloaders_dict = create_task_dataloaders(dataset, batch_size=32)

    # Huấn luyện MAML
    meta_model = MHLPPredictor(hw_input_dim=5, ...)
    meta_optimizer = torch.optim.Adam(meta_model.parameters(), lr=1e-3)
    train_meta_learning(meta_model, meta_optimizer, dataloaders_dict,
                        num_epochs=100, inner_lr=0.01, inner_steps=1)

Author: MHLP Team — Khóa luận tốt nghiệp
"""

import os
import sys
import copy
import time
from typing import Dict, List, Optional, Tuple
from collections import OrderedDict

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Subset

try:
    from torch.func import functional_call
except ImportError:
    from torch.nn.utils.stateless import functional_call

# ── Local imports ──
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  1. TIỆN ÍCH CHO MAML (MAML Utilities)                                ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def split_support_query(
    batch: Tuple[torch.Tensor, ...],
    support_ratio: float = 0.5,
) -> Tuple[Tuple[torch.Tensor, ...], Tuple[torch.Tensor, ...]]:
    """
    Chia một batch thành Support Set và Query Set.

    Support Set: Dùng cho inner-loop (thích nghi đặc thù task).
    Query Set:   Dùng cho outer-loop (cập nhật siêu tham số meta).

    Args:
        batch:         Tuple (X, A, hw, latency) — mỗi tensor shape (B, ...)
        support_ratio: Tỷ lệ dành cho support set (default: 0.5 = 50/50)

    Returns:
        (support_batch, query_batch): Mỗi cái là tuple (X, A, hw, latency)
    """
    network_features, hw, latency = _unpack_batch(batch)

    if isinstance(network_features, (tuple, list)):
        B = network_features[0].size(0)
    else:
        B = network_features.size(0)

    n_support = max(1, int(B * support_ratio))
    n_support = min(n_support, B - 1)

    if isinstance(network_features, (tuple, list)):
        support_network = tuple(feat[:n_support] for feat in network_features)
        query_network = tuple(feat[n_support:] for feat in network_features)
    else:
        support_network = network_features[:n_support]
        query_network = network_features[n_support:]

    support = (
        support_network,
        hw[:n_support],
        latency[:n_support],
    )
    query = (
        query_network,
        hw[n_support:],
        latency[n_support:],
    )

    return support, query


def compute_task_loss(
    model: nn.Module,
    batch: Tuple[torch.Tensor, ...],
    params: Optional[OrderedDict] = None,
    device: torch.device = torch.device("cpu"),
) -> torch.Tensor:
    """
    Tính MSE loss cho một task (hardware device) cụ thể.

    Hỗ trợ 2 chế độ:
      (a) params=None → Dùng tham số mặc định của model (standard forward)
      (b) params≠None → Dùng fast weights (cho inner-loop MAML)

    Hàm forward của model nhận ưu tiên: model(network_features, hardware_features),
    trong đó network_features có thể là tuple (X, A) cho bài toán đồ thị.
    Hàm vẫn hỗ trợ backward-compatibility với model(X, A, hardware_features).

    Args:
        model:  MHLPPredictor — model dự đoán latency
        batch:  Tuple (X, A, hw, latency) từ DataLoader
        params: OrderedDict of fast weights (hoặc None để dùng model gốc)
        device: Thiết bị tính toán

    Returns:
        loss: Scalar MSE loss
    """
    network_features, hw, latency = _move_batch_to_device(batch, device)
    pred = functional_forward(model, network_features, hw, params=params)

    loss = F.mse_loss(pred, latency)
    return loss


def functional_forward(
    model: nn.Module,
    network_features,
    hardware_features: torch.Tensor,
    params: Optional[OrderedDict] = None,
) -> torch.Tensor:
    """
    Forward pass sử dụng fast weights thay vì tham số gốc của model.

    Đây là kỹ thuật cốt lõi của MAML: thay thế tham số model bằng
    fast weights (θ' = θ - α∇L) trong inner-loop, trong khi vẫn
    giữ computation graph để tính gradient bậc hai cho outer-loop.

    Cách hoạt động:
      1. Lưu tham số gốc của model
      2. Gán fast weights vào model
      3. Thực hiện forward pass
      4. Khôi phục tham số gốc

    Args:
        model:            MHLPPredictor
        network_features: Đặc trưng mạng, thường là tuple (X, A)
        hardware_features: Hardware features (B, hw_dim)
        params:           OrderedDict — fast weights từ inner-loop (optional)

    Returns:
        pred: Predicted latency (B, 1)
    """
    if params is None:
        try:
            return model(network_features, hardware_features)
        except TypeError:
            if isinstance(network_features, (tuple, list)) and len(network_features) == 2:
                return model(network_features[0], network_features[1], hardware_features)
            raise

    try:
        return functional_call(
            model,
            params,
            args=(network_features, hardware_features),
        )
    except TypeError:
        if isinstance(network_features, (tuple, list)) and len(network_features) == 2:
            return functional_call(
                model,
                params,
                args=(network_features[0], network_features[1], hardware_features),
            )
        raise


def _unpack_batch(batch: Tuple[torch.Tensor, ...]):
    """
    Chuẩn hóa batch về dạng (network_features, hardware_features, latency).

    Hỗ trợ 2 định dạng:
      - (X, A, hw, latency)
      - (network_features, hw, latency) với network_features = (X, A)
    """
    if len(batch) == 4:
        X, A, hw, latency = batch
        return (X, A), hw, latency

    if len(batch) == 3:
        network_features, hw, latency = batch
        if isinstance(network_features, (tuple, list)) and len(network_features) == 2:
            return tuple(network_features), hw, latency
        raise ValueError(
            "Expected network_features to be a tuple/list (X, A) when batch has 3 items."
        )

    raise ValueError(
        "Expected batch format (X, A, hw, latency) or ((X, A), hw, latency)."
    )


def _move_batch_to_device(
    batch: Tuple[torch.Tensor, ...],
    device: torch.device,
):
    """Đưa batch về device và giữ nguyên cấu trúc standardized."""
    network_features, hw, latency = _unpack_batch(batch)

    if isinstance(network_features, (tuple, list)):
        network_features = tuple(feat.to(device) for feat in network_features)
    else:
        network_features = network_features.to(device)

    return network_features, hw.to(device), latency.to(device)


def _network_batch_size(network_features) -> int:
    """Lấy batch size từ network_features (tensor hoặc tuple tensor)."""
    if isinstance(network_features, (tuple, list)):
        return network_features[0].size(0)
    return network_features.size(0)


def inner_loop_update(
    model: nn.Module,
    support_batch: Tuple[torch.Tensor, ...],
    inner_lr: float,
    inner_steps: int,
    device: torch.device,
) -> OrderedDict:
    """
    Inner Loop của MAML — Thích nghi mô hình cho một task cụ thể.

    Thuật toán:
      θ'₀ = θ  (khởi tạo từ meta-parameters)
      for step in range(inner_steps):
          L_support = MSE(model(support; θ'ₛ), target)
          θ'ₛ₊₁ = θ'ₛ - α · ∇_{θ'ₛ} L_support

    Sử dụng torch.autograd.grad() thay vì loss.backward() để:
      - Không thay đổi .grad của meta-parameters
      - Giữ computation graph (create_graph=True) cho gradient bậc hai
      - Cho phép outer-loop tính ∂L_query/∂θ thông qua θ'

    Args:
        model:         MHLPPredictor
        support_batch: Tuple (X, A, hw, latency) — Support Set của task
        inner_lr:      Learning rate cho inner-loop (α)
        inner_steps:   Số bước gradient descent trong inner-loop (1 hoặc 2)
        device:        Thiết bị tính toán

    Returns:
        fast_weights: OrderedDict — Tham số đã thích nghi θ'
    """
    # Khởi tạo fast weights = bản copy tham số hiện tại của model
    fast_weights = OrderedDict(
        (name, p.clone()) for name, p in model.named_parameters()
    )

    for step in range(inner_steps):
        # Tính loss trên Support Set với fast weights hiện tại
        support_loss = compute_task_loss(
            model, support_batch, params=fast_weights, device=device
        )

        # Tính gradient ∂L/∂θ' bằng torch.autograd.grad
        # create_graph=True: giữ graph cho gradient bậc hai (cần cho outer-loop)
        # allow_unused=True:  tránh lỗi nếu có param không tham gia forward
        grads = torch.autograd.grad(
            outputs=support_loss,
            inputs=list(fast_weights.values()),
            create_graph=True,   # QUAN TRỌNG: cho phép higher-order gradient
            allow_unused=True,
        )

        # Cập nhật fast weights: θ' = θ' - α · ∇L
        updated_weights = OrderedDict()
        for (name, weight), grad in zip(fast_weights.items(), grads):
            if grad is not None:
                updated_weights[name] = weight - inner_lr * grad
            else:
                # Param không có gradient (e.g., BatchNorm running stats)
                updated_weights[name] = weight

        fast_weights = updated_weights

    return fast_weights


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  2. TẠO TASK DATALOADERS (Chia dữ liệu theo Hardware)                 ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def create_task_dataloaders(
    dataset,
    batch_size: int = 32,
    shuffle: bool = True,
) -> Dict[str, DataLoader]:
    """
    Chia dataset thành các DataLoader riêng cho từng hardware (= 1 Task).

    Trong MAML, mỗi hardware device là một task riêng biệt.
    Hàm này nhóm dữ liệu theo hardware_name và tạo DataLoader cho mỗi nhóm.

    Args:
        dataset:    HyTraMHLPDataset — dataset tổng (all hardware)
        batch_size: Batch size cho mỗi task DataLoader
        shuffle:    Có shuffle hay không

    Returns:
        Dict[str, DataLoader]: keys = hardware names, values = DataLoaders
            Ví dụ: {'RTX4080': DataLoader(...), 'ip15': DataLoader(...), ...}
    """
    # Nhóm indices theo hardware name — dùng hw_names list trực tiếp
    hw_indices: Dict[str, List[int]] = {}
    for idx in range(len(dataset)):
        hw_name = dataset.hw_names[idx]
        if hw_name not in hw_indices:
            hw_indices[hw_name] = []
        hw_indices[hw_name].append(idx)

    # Tạo DataLoader cho từng hardware
    dataloaders: Dict[str, DataLoader] = {}
    for hw_name, indices in hw_indices.items():
        subset = Subset(dataset, indices)
        dataloaders[hw_name] = DataLoader(
            subset, batch_size=batch_size, shuffle=shuffle, drop_last=False,
        )
        print(f"  [MAML Task] {hw_name}: {len(indices)} samples, "
              f"{len(dataloaders[hw_name])} batches")

    return dataloaders


def _tensor_to_hw_name(hw_tensor: torch.Tensor, dataset) -> str:
    """
    Map hardware encoding tensor về tên hardware.

    So sánh hw_tensor với encoding của từng thiết bị trong
    HARDWARE_CATALOG để tìm tên tương ứng.

    Args:
        hw_tensor: Vector encoding phần cứng (5D)
        dataset:   Dataset chứa thông tin samples

    Returns:
        str: Tên hardware (e.g., 'RTX4080')
    """
    from hytra_encoding import encode_hardware, HARDWARE_CATALOG

    for hw_name in HARDWARE_CATALOG:
        ref = torch.as_tensor(encode_hardware(hw_name), dtype=torch.float32)
        if torch.allclose(hw_tensor, ref, atol=1e-6):
            return hw_name

    return "unknown"


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  3. VÒNG LẶP HUẤN LUYỆN META-LEARNING (MAML Training Loop)           ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def train_meta_learning(
    meta_model: nn.Module,
    meta_optimizer: torch.optim.Optimizer,
    dataloaders_dict: Dict[str, DataLoader],
    num_epochs: int = 100,
    inner_lr: float = 0.01,
    inner_steps: int = 1,
    support_ratio: float = 0.5,
    device: torch.device = torch.device("cpu"),
    log_interval: int = 10,
    val_dataloaders_dict: Optional[Dict[str, DataLoader]] = None,
) -> Dict[str, List[float]]:
    """
    Vòng lặp huấn luyện Meta-Learning (MAML) cho MHLP.

    ╔══════════════════════════════════════════════════════════════════╗
    ║                    MAML ALGORITHM                               ║
    ╠══════════════════════════════════════════════════════════════════╣
    ║                                                                  ║
    ║  Input: meta_model (θ), meta_optimizer, task dataloaders         ║
    ║                                                                  ║
    ║  for epoch in range(num_epochs):                                 ║
    ║      meta_loss = 0                                               ║
    ║                                                                  ║
    ║      for task_name, task_loader in dataloaders_dict:   ← Tasks   ║
    ║          batch = next(task_loader)                                ║
    ║          support, query = split(batch)   ← Data Splitting        ║
    ║                                                                  ║
    ║          ┌─ Inner Loop (Task-level) ─────────────────────┐       ║
    ║          │ θ' = θ                                        │       ║
    ║          │ for step in range(inner_steps):                │       ║
    ║          │     L_s = MSE(model(support; θ'), target)     │       ║
    ║          │     θ' = θ' - α · ∇_{θ'} L_s                 │       ║
    ║          └───────────────────────────────────────────────┘       ║
    ║                                                                  ║
    ║          ┌─ Outer Loop (Meta-level) ─────────────────────┐       ║
    ║          │ L_q = MSE(model(query; θ'), target)           │       ║
    ║          │ meta_loss += L_q    ← Accumulate              │       ║
    ║          └───────────────────────────────────────────────┘       ║
    ║                                                                  ║
    ║      meta_optimizer.zero_grad()                                  ║
    ║      meta_loss.backward()    ← Gradient through θ' → θ          ║
    ║      meta_optimizer.step()   ← Update θ                         ║
    ║                                                                  ║
    ╚══════════════════════════════════════════════════════════════════╝

    Tham số quan trọng:
      - inner_lr (α):     Learning rate cho inner-loop.
                           Quá lớn → overshoot; Quá nhỏ → adapt chậm.
                           Khuyến nghị: 0.001 - 0.05
      - inner_steps (K):  Số bước gradient descent trong inner-loop.
                           1-step thường đủ; 2-step cho precision cao hơn
                           nhưng tốn bộ nhớ hơn (gradient bậc hai sâu hơn).
      - support_ratio:    Tỷ lệ support/query. 0.5 = chia đều.
                           Tăng → inner-loop tốt hơn, query ít hơn.

    Args:
        meta_model:          MHLPPredictor — mô hình MHLP.
                             forward(X, A, hardware_features) → latency.
        meta_optimizer:      Optimizer cho outer-loop (e.g., Adam(lr=1e-3))
        dataloaders_dict:    Dict[str, DataLoader] — keys = tên hardware
                             (e.g., 'RTX4080', 'ip15', 'Macbook_M1'),
                             values = dataloader cho hardware đó.
        num_epochs:          Số epoch meta-learning
        inner_lr:            Learning rate cho inner-loop (α)
        inner_steps:         Số bước gradient descent trong inner-loop
        support_ratio:       Tỷ lệ batch dành cho Support Set (0-1)
        device:              Thiết bị tính toán (cpu/cuda)
        log_interval:        In log mỗi bao nhiêu epoch
        val_dataloaders_dict: DataLoader validation (optional, để theo dõi)

    Returns:
        history: Dict chứa lịch sử training:
            - 'meta_loss':     List[float] — meta-loss mỗi epoch
            - 'task_losses':   List[Dict[str, float]] — loss mỗi task mỗi epoch
            - 'val_meta_loss': List[float] — validation meta-loss (nếu có)
    """
    meta_model.to(device)
    meta_model.train()

    # Lịch sử training
    history: Dict[str, list] = {
        "meta_loss": [],
        "task_losses": [],
        "val_meta_loss": [],
    }

    # Tạo iterators cho mỗi task dataloader
    task_names = list(dataloaders_dict.keys())
    num_tasks = len(task_names)

    print(f"\n{'=' * 70}")
    print(f"  MAML Training — {num_tasks} tasks (hardware devices)")
    print(f"  Inner LR: {inner_lr}, Inner Steps: {inner_steps}")
    print(f"  Support Ratio: {support_ratio}")
    print(f"  Tasks: {task_names}")
    print(f"{'=' * 70}\n")

    for epoch in range(num_epochs):
        epoch_start = time.time()

        # ═══════════════════════════════════════════════════════════════
        # OUTER LOOP: Duyệt qua tất cả tasks, tích lũy meta-loss
        # ═══════════════════════════════════════════════════════════════
        meta_losses: List[torch.Tensor] = []
        task_losses_epoch: Dict[str, float] = {}
        num_valid_tasks = 0

        # Tạo iterators mới mỗi epoch (để shuffle lại dữ liệu)
        task_iterators = {
            name: iter(loader)
            for name, loader in dataloaders_dict.items()
        }

        for task_name in task_names:
            # ── Bước 1: Lấy batch dữ liệu cho task ──
            try:
                batch = next(task_iterators[task_name])
            except StopIteration:
                # Hết dữ liệu cho task này → tạo iterator mới
                task_iterators[task_name] = iter(dataloaders_dict[task_name])
                batch = next(task_iterators[task_name])

            # Kiểm tra batch đủ lớn để chia support/query
            batch_network_features, _, _ = _unpack_batch(batch)
            if _network_batch_size(batch_network_features) < 2:
                continue  # Bỏ qua batch quá nhỏ

            # ── Bước 2: Chia thành Support Set và Query Set ──
            support_batch, query_batch = split_support_query(
                batch, support_ratio=support_ratio
            )

            # Kiểm tra query set không rỗng
            query_network_features, _, _ = _unpack_batch(query_batch)
            if _network_batch_size(query_network_features) == 0:
                continue

            # ── Bước 3: INNER LOOP — Thích nghi cho task ──
            # Tính fast weights: θ' = θ - α·∇L_support
            fast_weights = inner_loop_update(
                model=meta_model,
                support_batch=support_batch,
                inner_lr=inner_lr,
                inner_steps=inner_steps,
                device=device,
            )

            # ── Bước 4: OUTER LOOP — Tính meta-loss trên Query Set ──
            # Sử dụng fast weights θ' để tính loss trên query set
            # Gradient sẽ flow: L_query(θ') → θ' = θ - α∇L_support(θ) → θ
            query_loss = compute_task_loss(
                model=meta_model,
                batch=query_batch,
                params=fast_weights,
                device=device,
            )

            # Cộng dồn meta-loss qua tất cả tasks
            meta_losses.append(query_loss)
            task_losses_epoch[task_name] = query_loss.item()
            num_valid_tasks += 1

        # ── Bước 5: Chia trung bình meta-loss cho số tasks ──
        meta_loss = None
        if num_valid_tasks > 0:
            meta_loss = torch.stack(meta_losses).mean()

        # ── Bước 6: Meta-update — Cập nhật tham số toàn cục θ ──
        meta_optimizer.zero_grad()

        if meta_loss is not None and meta_loss.requires_grad:
            meta_loss.backward()
            # Gradient clipping để ổn định training
            nn.utils.clip_grad_norm_(meta_model.parameters(), max_norm=5.0)
            meta_optimizer.step()

        # ═══════════════════════════════════════════════════════════════
        # LOGGING & VALIDATION
        # ═══════════════════════════════════════════════════════════════
        epoch_loss = meta_loss.item() if meta_loss is not None else 0.0
        history["meta_loss"].append(epoch_loss)
        history["task_losses"].append(task_losses_epoch)

        # Validation (nếu có)
        val_loss = None
        if val_dataloaders_dict is not None:
            val_loss = evaluate_meta(
                meta_model, val_dataloaders_dict,
                inner_lr=inner_lr, inner_steps=inner_steps,
                support_ratio=support_ratio, device=device,
            )
            history["val_meta_loss"].append(val_loss)

        # Print log
        if (epoch + 1) % log_interval == 0 or epoch == 0:
            elapsed = time.time() - epoch_start
            task_str = " | ".join(
                f"{name}: {loss:.4f}"
                for name, loss in task_losses_epoch.items()
            )
            log_msg = (
                f"  Epoch [{epoch+1:4d}/{num_epochs}] "
                f"Meta-Loss: {epoch_loss:.6f} | "
                f"Tasks: [{task_str}] | "
                f"Time: {elapsed:.2f}s"
            )
            if val_loss is not None:
                log_msg += f" | Val: {val_loss:.6f}"
            print(log_msg)

    print(f"\n{'=' * 70}")
    print(f"  MAML Training Complete!")
    print(f"  Final Meta-Loss: {history['meta_loss'][-1]:.6f}")
    print(f"{'=' * 70}")

    return history


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  4. ĐÁNH GIÁ META-LEARNING (Meta Evaluation)                          ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def evaluate_meta(
    meta_model: nn.Module,
    dataloaders_dict: Dict[str, DataLoader],
    inner_lr: float = 0.01,
    inner_steps: int = 1,
    support_ratio: float = 0.5,
    device: torch.device = torch.device("cpu"),
) -> float:
    """
    Đánh giá mô hình MAML: Thích nghi trên support rồi đo trên query.

    Lưu ý: Evaluation không cần gradient bậc hai, nên ta dùng
    detached inner-loop để tiết kiệm bộ nhớ.

    Args:
        meta_model:       MHLPPredictor
        dataloaders_dict: Dict[str, DataLoader] — validation dataloaders
        inner_lr:         Learning rate cho inner-loop
        inner_steps:      Số bước inner-loop
        support_ratio:    Tỷ lệ support set
        device:           Thiết bị

    Returns:
        avg_meta_loss: Meta-loss trung bình trên tất cả tasks
    """
    meta_model.eval()
    total_loss = 0.0
    num_tasks = 0

    for task_name, loader in dataloaders_dict.items():
        for batch in loader:
            batch_network_features, _, _ = _unpack_batch(batch)
            if _network_batch_size(batch_network_features) < 2:
                continue

            support_batch, query_batch = split_support_query(
                batch, support_ratio=support_ratio
            )
            query_network_features, _, _ = _unpack_batch(query_batch)
            if _network_batch_size(query_network_features) == 0:
                continue

            # Inner-loop adaptation (without higher-order gradient)
            with torch.enable_grad():
                fast_weights = inner_loop_update(
                    model=meta_model,
                    support_batch=support_batch,
                    inner_lr=inner_lr,
                    inner_steps=inner_steps,
                    device=device,
                )

            # Evaluate on query with adapted weights
            network_features, hw, latency = _move_batch_to_device(
                query_batch, device
            )
            with torch.no_grad():
                pred = functional_forward(
                    meta_model, network_features, hw, params=fast_weights
                )
                loss = F.mse_loss(pred, latency)

            total_loss += loss.item()
            num_tasks += 1

    meta_model.train()
    return total_loss / max(num_tasks, 1)


def fine_tune_on_device(
    meta_model: nn.Module,
    device_loader: DataLoader,
    inner_lr: float = 0.01,
    fine_tune_steps: int = 10,
    device: torch.device = torch.device("cpu"),
) -> nn.Module:
    """
    Fine-tune mô hình meta-learned cho một thiết bị cụ thể.

    Đây là ứng dụng thực tế của MAML: Sau khi meta-train, ta có thể
    nhanh chóng thích nghi mô hình cho thiết bị mới chỉ với vài bước
    gradient descent và ít dữ liệu (few-shot adaptation).

    Args:
        meta_model:       MHLPPredictor đã meta-train
        device_loader:    DataLoader cho thiết bị cần thích nghi
        inner_lr:         Learning rate cho fine-tuning
        fine_tune_steps:  Số bước fine-tuning
        device:           Thiết bị tính toán

    Returns:
        adapted_model: Model đã fine-tune cho thiết bị cụ thể
    """
    adapted_model = copy.deepcopy(meta_model)
    adapted_model.to(device)
    adapted_model.train()

    ft_optimizer = torch.optim.SGD(
        adapted_model.parameters(), lr=inner_lr
    )

    step = 0
    while step < fine_tune_steps:
        for batch in device_loader:
            if step >= fine_tune_steps:
                break

            X, A, hw, latency = batch
            X, A, hw, latency = (
                X.to(device), A.to(device), hw.to(device), latency.to(device)
            )

            pred = adapted_model(X, A, hw)
            loss = F.mse_loss(pred, latency)

            ft_optimizer.zero_grad()
            loss.backward()
            ft_optimizer.step()

            step += 1

    return adapted_model


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  5. MAIN: DEMO MAML TRAINING                                          ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def main():
    """
    Demo: MAML training loop với dummy data.

    Tạo dữ liệu giả lập cho 3 hardware tasks và chạy vài epoch
    MAML để kiểm tra pipeline hoạt động đúng.
    """
    from hytra_encoding import (
        encode_hytra_dag, encode_hardware,
        NUM_GRAPH_NODES, NODE_FEATURE_DIM, HW_ENCODING_DIM,
    )
    from mhlp_predictor import MHLPPredictor

    print("=" * 70)
    print("  MAML Training Loop — Demo with Dummy Data")
    print("=" * 70)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\nDevice: {device}")

    # ── 1. Tạo mô hình ──
    meta_model = MHLPPredictor(
        node_feat_dim=NODE_FEATURE_DIM,   # 14
        hw_input_dim=HW_ENCODING_DIM,     # 5 (MHLP paper 5D)
        gcn_hidden_dim=64,                # Nhỏ hơn cho demo
        mlp_hidden_dim=32,
        embed_dim=64,
        num_gcn_layers=2,
        num_attn_heads=2,
        ffn_dim=128,
        predictor_hidden=64,
        dropout=0.1,
    ).to(device)

    print(f"  Model params: {meta_model.count_parameters():,}")

    # ── 2. Tạo dummy dataloaders cho 3 hardware tasks ──
    print("\n  Creating dummy task dataloaders...")

    hardware_names = ["RTX4080", "ip15", "Macbook_M1"]
    dataloaders_dict: Dict[str, DataLoader] = {}

    for hw_name in hardware_names:
        # Tạo dummy data cho mỗi hardware
        hw_vec = encode_hardware(hw_name)
        num_samples = 48  # 48 samples per hardware

        X_list, A_list, hw_list, lat_list = [], [], [], []
        for _ in range(num_samples):
            # Dummy architecture (random valid DAG)
            X_dummy = torch.randn(NUM_GRAPH_NODES, NODE_FEATURE_DIM)
            A_dummy = torch.eye(NUM_GRAPH_NODES)
            for i in range(NUM_GRAPH_NODES - 1):
                A_dummy[i, i + 1] = 1.0
            hw_tensor = torch.as_tensor(hw_vec, dtype=torch.float32)
            lat = torch.tensor([np.random.uniform(1.0, 50.0)],
                               dtype=torch.float32)

            X_list.append(X_dummy)
            A_list.append(A_dummy)
            hw_list.append(hw_tensor)
            lat_list.append(lat)

        # Tạo TensorDataset
        from torch.utils.data import TensorDataset
        tensor_dataset = TensorDataset(
            torch.stack(X_list),
            torch.stack(A_list),
            torch.stack(hw_list),
            torch.stack(lat_list),
        )
        dataloaders_dict[hw_name] = DataLoader(
            tensor_dataset, batch_size=16, shuffle=True,
        )
        print(f"    {hw_name}: {num_samples} samples, "
              f"{len(dataloaders_dict[hw_name])} batches")

    # ── 3. Huấn luyện MAML ──
    meta_optimizer = torch.optim.Adam(
        meta_model.parameters(), lr=1e-3
    )

    print("\n  Starting MAML training...")
    history = train_meta_learning(
        meta_model=meta_model,
        meta_optimizer=meta_optimizer,
        dataloaders_dict=dataloaders_dict,
        num_epochs=20,        # Ít epoch cho demo
        inner_lr=0.01,
        inner_steps=1,
        support_ratio=0.5,
        device=device,
        log_interval=5,
    )

    # ── 4. Kiểm tra kết quả ──
    print(f"\n  Training History:")
    print(f"    Epochs: {len(history['meta_loss'])}")
    print(f"    First Meta-Loss:  {history['meta_loss'][0]:.6f}")
    print(f"    Final Meta-Loss:  {history['meta_loss'][-1]:.6f}")

    # ── 5. Demo fine-tune cho thiết bị cụ thể ──
    print(f"\n  Fine-tuning for RTX4080...")
    adapted_model = fine_tune_on_device(
        meta_model=meta_model,
        device_loader=dataloaders_dict["RTX4080"],
        inner_lr=0.01,
        fine_tune_steps=5,
        device=device,
    )
    print(f"    ✓ Adapted model created")

    print(f"\n{'=' * 70}")
    print(f"  MAML Demo Complete!")
    print(f"{'=' * 70}")


if __name__ == "__main__":
    main()
