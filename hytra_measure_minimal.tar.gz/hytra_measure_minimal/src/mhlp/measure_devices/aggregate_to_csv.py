#!/usr/bin/env python3
"""
==============================================================================
Tổng hợp Kết quả Latency từ 3 Thiết bị → CSV/JSON thống nhất
==============================================================================

Script tổng hợp kết quả đo thực tế từ:
  1. RTX 4080 SUPER (CUDA)   → results_rtx4080.json
  2. Macbook M1 (MPS)         → results_mac_m1.json
  3. iPhone 15 (CoreML/ANE)   → results_ip15.json

Output:
  - hytra_latency_dataset.csv  — Format chuẩn cho MHLP DataLoader
      Columns: architecture_string, hardware_type, latency_ms

  - hytra_latency_dataset.json — Full metadata + cross-device statistics

Cross-device statistics (quan trọng cho NAS research):
  - Pearson r  : Linear correlation
  - Spearman ρ : Rank correlation (monotonic relationship quality)
  - Kendall τ  : Pairwise ranking agreement
  → Metric chính trong NAS papers để đánh giá latency predictor.

Usage:
  python aggregate_to_csv.py \\
      --rtx4080  results_rtx4080.json \\
      --mac_m1   results_mac_m1.json \\
      --ip15     results_ip15.json \\
      --output   ../hytra_latency_dataset

  # Nếu chưa có kết quả iPhone:
  python aggregate_to_csv.py \\
      --rtx4080  results_rtx4080.json \\
      --mac_m1   results_mac_m1.json \\
      --output   ../hytra_latency_dataset
"""

import os
import sys
import json
import csv
import argparse
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

# Scipy cho ranking correlations (important for NAS evaluation)
try:
    from scipy import stats as scipy_stats
    SCIPY_AVAILABLE = True
except ImportError:
    SCIPY_AVAILABLE = False
    print("  WARNING: scipy not installed — Spearman/Kendall will be skipped")
    print("  Install: pip install scipy")

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))


# ============================================================================
#  1. LOAD DEVICE RESULTS
# ============================================================================

def load_device_results(
    filepath: str, hardware_label: str
) -> Tuple[List[Dict], Dict[str, Any]]:
    """
    Load kết quả đo từ một thiết bị.

    Đọc JSON output từ measure_rtx4080.py / measure_mac_m1.py / iPhone app.
    Chuẩn hóa thành format thống nhất: (arch_string, hardware_type, latency_ms).

    Hỗ trợ 2 format:
      a) Structured: {"results": [{"arch_string": ..., "latency_ms": {...}}, ...]}
         → Từ measure_rtx4080.py, measure_mac_m1.py
      b) Flat:       [{"arch_string": ..., "latency_ms": 12.3}, ...]
         → Từ iPhone LatencyBenchmarkApp

    Returns:
        (records, device_metadata)
        records: List[{"arch_string", "hardware_type", "latency_ms"}]
    """
    if not os.path.exists(filepath):
        print(f"  WARNING: File chưa tồn tại: {filepath}")
        print(f"  → Bỏ qua {hardware_label}")
        return [], {}

    with open(filepath, "r") as f:
        data = json.load(f)

    records = []

    # Format a) Structured (from Python measurement scripts)
    if isinstance(data, dict) and "results" in data:
        raw_results = data["results"]
        metadata = {
            k: v for k, v in data.items() if k not in ("results", "failed")
        }

        for r in raw_results:
            arch_str = r.get("arch_string", "")
            lat_data = r.get("latency_ms", {})

            # Sử dụng clean_median > median > clean_mean > mean
            if isinstance(lat_data, dict):
                latency = (
                    lat_data.get("clean_median")
                    or lat_data.get("median")
                    or lat_data.get("clean_mean")
                    or lat_data.get("mean")
                )
            else:
                latency = float(lat_data)

            if latency is not None and arch_str:
                records.append({
                    "architecture_string": arch_str,
                    "hardware_type": hardware_label,
                    "latency_ms": round(float(latency), 4),
                    # Extra metadata
                    "op_indices": r.get("op_indices", []),
                    "params": r.get("params", 0),
                    "complexity": r.get("complexity", 0),
                })

                # Nếu có full stats, lưu thêm
                if isinstance(lat_data, dict):
                    records[-1]["latency_stats"] = {
                        k: v for k, v in lat_data.items()
                        if k in ("mean", "std", "min", "max", "median",
                                 "p95", "p99", "iqr", "clean_mean", "num_outliers")
                    }

    # Format b) Flat (from iOS app hoặc simple format)
    elif isinstance(data, list):
        metadata = {}
        for r in data:
            arch_str = r.get("arch_string", r.get("arch_id", ""))
            latency = r.get("latency_ms", r.get("latency", None))
            if latency is not None and arch_str:
                records.append({
                    "architecture_string": arch_str,
                    "hardware_type": hardware_label,
                    "latency_ms": round(float(latency), 4),
                })

    else:
        print(f"  WARNING: Unrecognized format in {filepath}")
        return [], {}

    print(f"  [{hardware_label}] Loaded {len(records)} records from {os.path.basename(filepath)}")
    return records, metadata


# ============================================================================
#  2. CROSS-DEVICE STATISTICS
# ============================================================================

def compute_cross_device_stats(
    all_records: List[Dict],
) -> Dict[str, Any]:
    """
    Tính thống kê cross-device cho NAS research.

    Includes:
      - Per-device summary (count, mean, std, min, max, median)
      - Cross-device correlation matrix:
        * Pearson r  — linear correlation
        * Spearman ρ — rank correlation (monotonic relationship)
        * Kendall τ  — pairwise ranking agreement
      - Latency ratio matrix (e.g., Mac M1 / RTX4080 ≈ 1.8x)
    """
    # Group by hardware
    by_hw: Dict[str, List[float]] = {}
    for r in all_records:
        hw = r["hardware_type"]
        if hw not in by_hw:
            by_hw[hw] = []
        by_hw[hw].append(r["latency_ms"])

    # Per-device summary
    per_device = {}
    for hw, lats in by_hw.items():
        arr = np.array(lats)
        per_device[hw] = {
            "count": len(arr),
            "mean_ms": round(float(np.mean(arr)), 4),
            "std_ms": round(float(np.std(arr)), 4),
            "min_ms": round(float(np.min(arr)), 4),
            "max_ms": round(float(np.max(arr)), 4),
            "median_ms": round(float(np.median(arr)), 4),
            "p5_ms": round(float(np.percentile(arr, 5)), 4),
            "p95_ms": round(float(np.percentile(arr, 95)), 4),
        }

    # Build arch → {hw: latency} lookup
    by_arch: Dict[str, Dict[str, float]] = {}
    for r in all_records:
        arch = r["architecture_string"]
        if arch not in by_arch:
            by_arch[arch] = {}
        by_arch[arch][r["hardware_type"]] = r["latency_ms"]

    # Cross-device correlations
    hw_list = sorted(by_hw.keys())
    correlations = {}
    latency_ratios = {}

    for i in range(len(hw_list)):
        for j in range(i + 1, len(hw_list)):
            hw_a, hw_b = hw_list[i], hw_list[j]

            # Tìm architectures xuất hiện ở cả 2 devices
            common_pairs = []
            for arch, hws in by_arch.items():
                if hw_a in hws and hw_b in hws:
                    common_pairs.append((hws[hw_a], hws[hw_b]))

            pair_key = f"{hw_a}_vs_{hw_b}"

            if len(common_pairs) >= 3:
                a_vals, b_vals = zip(*common_pairs)
                a_arr, b_arr = np.array(a_vals), np.array(b_vals)

                corr_data = {
                    "num_common": len(common_pairs),
                    "pearson_r": round(float(np.corrcoef(a_arr, b_arr)[0, 1]), 4),
                }

                if SCIPY_AVAILABLE:
                    sp_rho, sp_pval = scipy_stats.spearmanr(a_arr, b_arr)
                    kt_tau, kt_pval = scipy_stats.kendalltau(a_arr, b_arr)
                    corr_data.update({
                        "spearman_rho": round(float(sp_rho), 4),
                        "spearman_pvalue": float(f"{sp_pval:.2e}"),
                        "kendall_tau": round(float(kt_tau), 4),
                        "kendall_pvalue": float(f"{kt_pval:.2e}"),
                    })

                correlations[pair_key] = corr_data

                # Latency ratio
                ratio = float(np.median(b_arr) / np.median(a_arr))
                latency_ratios[pair_key] = {
                    "median_ratio": round(ratio, 3),
                    "description": f"{hw_b} is {ratio:.2f}x vs {hw_a}",
                }
            else:
                correlations[pair_key] = {
                    "num_common": len(common_pairs),
                    "note": "Insufficient common architectures (<3)"
                }

    return {
        "per_device": per_device,
        "cross_device_correlation": correlations,
        "latency_ratios": latency_ratios,
        "total_records": len(all_records),
        "total_unique_architectures": len(by_arch),
        "devices": hw_list,
    }


# ============================================================================
#  3. EXPORT CSV & JSON
# ============================================================================

def export_csv(
    records: List[Dict],
    output_path: str,
):
    """
    Export sang CSV chuẩn cho MHLP DataLoader.

    Format: architecture_string, hardware_type, latency_ms
    Đây là format đầu vào trực tiếp cho:
      - hytra_encoding.py → HyTraMHLPDataset
      - mhlp_predictor.py → train/evaluate
    """
    csv_path = output_path if output_path.endswith(".csv") else output_path + ".csv"

    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["architecture_string", "hardware_type", "latency_ms"])
        for r in records:
            writer.writerow([
                r["architecture_string"],
                r["hardware_type"],
                r["latency_ms"],
            ])

    print(f"  CSV → {csv_path}")
    print(f"  Rows: {len(records)} (= {len(records) // max(1, len(set(r['hardware_type'] for r in records)))} archs × {len(set(r['hardware_type'] for r in records))} devices)")
    return csv_path


def export_json(
    records: List[Dict],
    stats: Dict[str, Any],
    device_metadata: Dict[str, Dict],
    output_path: str,
):
    """
    Export JSON đầy đủ (metadata + statistics + records).

    Bao gồm cross-device correlations — quan trọng cho thesis report.
    """
    json_path = output_path if output_path.endswith(".json") else output_path + ".json"

    output_data = {
        "timestamp": datetime.now().isoformat(),
        "description": (
            "MHLP Real-Device Latency Dataset — "
            "HyTra architectures measured on 3 hardware targets"
        ),
        "statistics": stats,
        "device_metadata": device_metadata,
        "num_records": len(records),
        "records": records,
    }

    with open(json_path, "w") as f:
        json.dump(output_data, f, indent=2)
    print(f"  JSON → {json_path}")
    return json_path


# ============================================================================
#  4. MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Tổng hợp kết quả latency từ 3 thiết bị thực tế",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--rtx4080", type=str, default="results_rtx4080.json",
        help="RTX 4080 (CUDA) results JSON",
    )
    parser.add_argument(
        "--mac_m1", type=str, default="results_mac_m1.json",
        help="Macbook M1 (MPS) results JSON",
    )
    parser.add_argument(
        "--ip15", type=str, default="results_ip15.json",
        help="iPhone 15 (CoreML) results JSON",
    )
    parser.add_argument(
        "--output", type=str, default="../hytra_latency_dataset",
        help="Output base path (sẽ sinh .csv + .json)",
    )
    parser.add_argument(
        "--skip_missing", action="store_true", default=True,
        help="Bỏ qua thiết bị chưa có kết quả (default: True)",
    )
    args = parser.parse_args()

    # ── Banner ───────────────────────────────────────────────────────
    print("\n" + "=" * 72)
    print("  MHLP — Aggregate Real-Device Latency Results")
    print("  Devices: RTX 4080 · Macbook M1 · iPhone 15")
    print("=" * 72)

    # ── Resolve paths ────────────────────────────────────────────────
    device_files = {
        "RTX4080": os.path.join(SCRIPT_DIR, args.rtx4080),
        "Macbook_M1": os.path.join(SCRIPT_DIR, args.mac_m1),
        "ip15": os.path.join(SCRIPT_DIR, args.ip15),
    }

    # ── Load results ─────────────────────────────────────────────────
    all_records: List[Dict] = []
    device_metadata: Dict[str, Dict] = {}

    for hw_label, filepath in device_files.items():
        records, metadata = load_device_results(filepath, hw_label)
        all_records.extend(records)
        if metadata:
            device_metadata[hw_label] = metadata

    if not all_records:
        print("\n  ERROR: Không tìm thấy kết quả nào!")
        print("  Đảm bảo đã chạy measure_rtx4080.py / measure_mac_m1.py / export_coreml.py")
        sys.exit(1)

    # ── Cross-device statistics ──────────────────────────────────────
    stats = compute_cross_device_stats(all_records)

    print(f"\n  --- Per-Device Summary ---")
    for hw, s in stats["per_device"].items():
        print(f"    {hw:12s}: {s['count']:4d} samples, "
              f"median={s['median_ms']:7.2f}, "
              f"range=[{s['min_ms']:.2f}, {s['max_ms']:.2f}] ms")

    if stats["cross_device_correlation"]:
        print(f"\n  --- Cross-Device Correlation ---")
        for pair, info in stats["cross_device_correlation"].items():
            n = info.get("num_common", 0)
            if n < 3:
                print(f"    {pair}: insufficient data ({n} common)")
                continue
            print(f"    {pair} ({n} common archs):")
            print(f"      Pearson  r = {info['pearson_r']:.4f}")
            if "spearman_rho" in info:
                print(f"      Spearman ρ = {info['spearman_rho']:.4f} "
                      f"(p={info['spearman_pvalue']:.2e})")
                print(f"      Kendall  τ = {info['kendall_tau']:.4f} "
                      f"(p={info['kendall_pvalue']:.2e})")

    if stats["latency_ratios"]:
        print(f"\n  --- Latency Ratios ---")
        for pair, info in stats["latency_ratios"].items():
            print(f"    {info['description']}")

    # ── Export CSV (chuẩn cho MHLP DataLoader) ───────────────────────
    output_base = args.output
    if not os.path.isabs(output_base):
        output_base = os.path.join(SCRIPT_DIR, output_base)

    os.makedirs(os.path.dirname(output_base), exist_ok=True)

    # CSV: architecture_string, hardware_type, latency_ms
    # (chỉ giữ 3 cột chính cho compatibility với MHLP)
    csv_records = [
        {
            "architecture_string": r["architecture_string"],
            "hardware_type": r["hardware_type"],
            "latency_ms": r["latency_ms"],
        }
        for r in all_records
    ]
    csv_path = export_csv(csv_records, output_base)

    # JSON: full metadata + statistics
    json_path = export_json(all_records, stats, device_metadata, output_base)

    # ── Final Summary ────────────────────────────────────────────────
    devices = stats.get("devices", [])
    n_archs = stats.get("total_unique_architectures", 0)
    n_records = stats.get("total_records", 0)

    print(f"\n  ╔{'═' * 58}╗")
    print(f"  ║  AGGREGATION COMPLETE                                      ║")
    print(f"  ╠{'═' * 58}╣")
    print(f"  ║  Devices    : {', '.join(devices):<42s} ║")
    print(f"  ║  Unique archs: {n_archs:<41d} ║")
    print(f"  ║  Total rows  : {n_records:<41d} ║")
    print(f"  ║  CSV → {os.path.basename(csv_path):<50s} ║")
    print(f"  ║  JSON → {os.path.basename(json_path):<49s} ║")
    print(f"  ╚{'═' * 58}╝")

    print(f"\n  NEXT: Dùng CSV này cho MHLP predictor training:")
    print(f"    python ../mhlp_predictor.py --data {csv_path}")
    print("=" * 72)


if __name__ == "__main__":
    main()
