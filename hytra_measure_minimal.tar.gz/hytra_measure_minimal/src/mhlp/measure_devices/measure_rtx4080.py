#!/usr/bin/env python3
"""
==============================================================================
Đo Latency Thực Tế trên NVIDIA RTX 4080 (CUDA)
==============================================================================

Script đo inference latency của 500 kiến trúc HyTra PDWRS-selected
trên NVIDIA RTX 4080 SUPER với CUDA synchronization đúng chuẩn.

Measurement Protocol (chống nhiễu OS):
  1. Warm-up:  50 forward passes → KHÔNG ghi nhận
     (GPU frequency ramp-up, CUDA kernel JIT, memory pool allocation)
  2. Đo đạc:  100 forward passes → ghi nhận từng latency
     - torch.cuda.synchronize() TRƯỚC khi bấm giờ
     - Forward pass
     - torch.cuda.synchronize() SAU forward
     - time.perf_counter() cho high-resolution timing
  3. Thống kê: mean, std, min, max, median, p95, p99
  4. Kết quả chính: **median** (robust với OS scheduler outliers)

Prerequisites:
  - NVIDIA GPU (RTX 4080 SUPER hoặc tương đương)
  - CUDA toolkit & PyTorch with CUDA support
  - File hytra_latency_dataset.json (output từ hytra_latency_pipeline.py)

Usage:
  python measure_rtx4080.py --input ../hytra_latency_dataset.json
  python measure_rtx4080.py --input ../hytra_latency_dataset.json --limit 20   # test nhanh
  python measure_rtx4080.py --input ../hytra_latency_dataset.json --warmup 100 --runs 200

Output:
  results_rtx4080.json — Full measurement results + device info
"""

import os
import sys
import gc
import json
import time
import argparse
import platform
from datetime import datetime
from typing import Any, Dict, List, Tuple

import numpy as np

# ── Project paths ────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MHLP_DIR = os.path.join(SCRIPT_DIR, "..")
sys.path.insert(0, MHLP_DIR)
sys.path.insert(0, os.path.join(MHLP_DIR, "..", "searching"))
sys.path.insert(0, os.path.join(MHLP_DIR, "..", "OpenSelfSup"))

import torch
import torch.nn as nn

# Import proxy model và utils từ pipeline
from hytra_latency_pipeline import (
    HyTraProxyModel,
    _arch_string_to_tuples,
    OP_INDEX_TO_TUPLE,
    NUM_STAGES,
    LAYERS_PER_STAGE,
)


# ============================================================================
#  1. DEVICE SETUP
# ============================================================================

def check_cuda_device() -> Dict[str, Any]:
    """
    Kiểm tra và thu thập thông tin CUDA device.

    Returns:
        Dict with device info. Raises RuntimeError nếu không có CUDA.
    """
    if not torch.cuda.is_available():
        raise RuntimeError(
            "CUDA không khả dụng! Script này yêu cầu NVIDIA GPU.\n"
            "Kiểm tra: nvidia-smi, hoặc cài đặt lại PyTorch with CUDA."
        )

    info = {
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "pytorch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "cudnn_version": str(torch.backends.cudnn.version()),
        "gpu_name": torch.cuda.get_device_name(0),
        "gpu_count": torch.cuda.device_count(),
        "gpu_memory_total_gb": round(
            torch.cuda.get_device_properties(0).total_memory / 1e9, 2
        ),
        "gpu_compute_capability": (
            f"{torch.cuda.get_device_properties(0).major}."
            f"{torch.cuda.get_device_properties(0).minor}"
        ),
        "hardware_label": "RTX4080",
    }
    return info


# ============================================================================
#  2. LATENCY MEASUREMENT — CUDA-synchronized
# ============================================================================

def measure_single_architecture(
    arch_tuples: List[Tuple[str, float]],
    device: str = "cuda",
    batch_size: int = 1,
    input_size: int = 224,
    warmup_runs: int = 50,
    measure_runs: int = 100,
) -> Dict[str, Any]:
    """
    Đo latency cho MỘT kiến trúc với CUDA synchronization chính xác.

    Protocol:
      1. Build model → .to(cuda) → .eval()
      2. Tạo dummy input trên GPU
      3. Warm-up: ``warmup_runs`` lần inference (không bấm giờ)
         - Mục đích: GPU freq ramp-up, CUDA malloc, kernel cache
      4. Measure: ``measure_runs`` lần inference
         - torch.cuda.synchronize() TRƯỚC perf_counter
         - forward(input)
         - torch.cuda.synchronize() SAU forward
         - Ghi nhận (end - start) * 1000 ms
      5. Tính thống kê + đếm params
      6. Cleanup GPU memory

    Returns:
        Dict chứa latency stats + params.
    """
    # ── Build model ──────────────────────────────────────────────────
    model = HyTraProxyModel(arch_tuples, input_size=input_size)
    model = model.to(device).eval()
    params = sum(p.numel() for p in model.parameters())

    dummy_input = torch.randn(
        batch_size, 3, input_size, input_size, device=device
    )

    # ── Warm-up ──────────────────────────────────────────────────────
    with torch.no_grad():
        for _ in range(warmup_runs):
            _ = model(dummy_input)
            torch.cuda.synchronize()

    # ── Measure ──────────────────────────────────────────────────────
    latencies: List[float] = []
    with torch.no_grad():
        for _ in range(measure_runs):
            torch.cuda.synchronize()           # SYNC trước bấm giờ
            t0 = time.perf_counter()
            _ = model(dummy_input)
            torch.cuda.synchronize()           # SYNC sau forward
            t1 = time.perf_counter()
            latencies.append((t1 - t0) * 1000.0)

    arr = np.array(latencies)

    # ── IQR outlier detection ────────────────────────────────────────
    q25, q75 = np.percentile(arr, 25), np.percentile(arr, 75)
    iqr = q75 - q25
    mask = (arr >= q25 - 3 * iqr) & (arr <= q75 + 3 * iqr)
    clean = arr[mask]

    stats = {
        "mean":   round(float(np.mean(arr)), 4),
        "std":    round(float(np.std(arr)), 4),
        "min":    round(float(np.min(arr)), 4),
        "max":    round(float(np.max(arr)), 4),
        "median": round(float(np.median(arr)), 4),
        "p95":    round(float(np.percentile(arr, 95)), 4),
        "p99":    round(float(np.percentile(arr, 99)), 4),
        "iqr":    round(float(iqr), 4),
        "clean_mean":   round(float(np.mean(clean)), 4) if len(clean) > 0 else None,
        "num_outliers": int(len(arr) - len(clean)),
    }

    # ── Cleanup ──────────────────────────────────────────────────────
    del model, dummy_input
    gc.collect()
    torch.cuda.empty_cache()

    return {"latency_ms": stats, "params": params}


# ============================================================================
#  3. BATCH MEASUREMENT PIPELINE
# ============================================================================

def measure_all(
    architectures: List[Dict[str, Any]],
    batch_size: int = 1,
    input_size: int = 224,
    warmup_runs: int = 50,
    measure_runs: int = 100,
) -> Tuple[List[Dict], List[Dict]]:
    """
    Đo latency cho toàn bộ danh sách kiến trúc.

    Args:
        architectures: List of dicts from hytra_latency_dataset.json
                       (mỗi phần tử chứa arch_string, op_indices, ...)
    Returns:
        (successes, failures)
    """
    try:
        from tqdm import tqdm
        iterator = tqdm(enumerate(architectures), total=len(architectures),
                        desc="RTX 4080 Profiling")
    except ImportError:
        def _iter():
            for i, a in enumerate(architectures):
                if i % 50 == 0:
                    print(f"  [{i}/{len(architectures)}]...")
                yield i, a
        iterator = _iter()

    successes, failures = [], []

    for i, arch_info in iterator:
        arch_str = arch_info["arch_string"]
        try:
            arch_tuples = _arch_string_to_tuples(arch_str)
            result = measure_single_architecture(
                arch_tuples,
                device="cuda",
                batch_size=batch_size,
                input_size=input_size,
                warmup_runs=warmup_runs,
                measure_runs=measure_runs,
            )
            successes.append({
                "arch_idx": i,
                "arch_string": arch_str,
                "op_indices": arch_info.get("op_indices", []),
                "complexity": arch_info.get("complexity", 0),
                **result,
            })
        except Exception as exc:
            failures.append({"arch_idx": i, "arch_string": arch_str, "error": str(exc)})
            print(f"\n  [FAIL] #{i}: {exc}")

    return successes, failures


# ============================================================================
#  4. MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Đo latency thực tế trên RTX 4080 (CUDA)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--input", type=str, default="../hytra_latency_dataset.json",
        help="JSON file chứa kiến trúc PDWRS-selected (từ pipeline)",
    )
    parser.add_argument("--output", type=str, default="results_rtx4080.json")
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--input_size", type=int, default=224)
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--runs", type=int, default=100)
    parser.add_argument("--limit", type=int, default=None,
                        help="Giới hạn số kiến trúc (test nhanh)")
    args = parser.parse_args()

    # ── Banner ───────────────────────────────────────────────────────
    print("\n" + "=" * 72)
    print("  MHLP — Real-Device Latency Measurement")
    print("  Target : NVIDIA RTX 4080 SUPER (CUDA)")
    print("  Protocol: warmup={}, measure={}, BS={}".format(
        args.warmup, args.runs, args.batch_size))
    print("=" * 72)

    # ── Device check ─────────────────────────────────────────────────
    device_info = check_cuda_device()
    print("\n  --- Device Info ---")
    for k, v in device_info.items():
        print(f"    {k}: {v}")

    # ── Load kiến trúc PDWRS ─────────────────────────────────────────
    input_path = args.input
    if not os.path.isabs(input_path):
        input_path = os.path.join(SCRIPT_DIR, input_path)
    print(f"\n  Loading: {input_path}")

    with open(input_path, "r") as f:
        data = json.load(f)

    archs = data["selected_architectures"]
    if args.limit:
        archs = archs[:args.limit]
    print(f"  Architectures: {len(archs)}")

    # ── Measure ──────────────────────────────────────────────────────
    successes, failures = measure_all(
        archs,
        batch_size=args.batch_size,
        input_size=args.input_size,
        warmup_runs=args.warmup,
        measure_runs=args.runs,
    )

    # ── Save ─────────────────────────────────────────────────────────
    output_data = {
        "timestamp": datetime.now().isoformat(),
        "device_info": device_info,
        "hardware_label": "RTX4080",
        "measurement_config": {
            "batch_size": args.batch_size,
            "input_size": [3, args.input_size, args.input_size],
            "warmup_runs": args.warmup,
            "measure_runs": args.runs,
        },
        "num_measured": len(successes),
        "num_failed": len(failures),
        "results": successes,
        "failed": failures,
    }

    output_path = os.path.join(SCRIPT_DIR, args.output)
    with open(output_path, "w") as f:
        json.dump(output_data, f, indent=2)
    print(f"\n  Results → {output_path}")

    # ── Summary ──────────────────────────────────────────────────────
    if successes:
        meds = [s["latency_ms"]["median"] for s in successes]
        print(f"\n  ╔{'═'*50}╗")
        print(f"  ║  RTX 4080 — FINAL SUMMARY                      ║")
        print(f"  ╠{'═'*50}╣")
        print(f"  ║  Measured : {len(successes):4d} architectures                ║")
        print(f"  ║  Failed   : {len(failures):4d}                               ║")
        print(f"  ║  Median lat range: {min(meds):7.2f} — {max(meds):7.2f} ms   ║")
        print(f"  ║  Mean of medians : {np.mean(meds):7.2f} ms                  ║")
        print(f"  ╚{'═'*50}╝")

    print(f"\n  NEXT: Chạy measure_mac_m1.py và export_coreml.py")
    print("=" * 72)


if __name__ == "__main__":
    main()
