#!/usr/bin/env python3
"""
==============================================================================
Export HyTra Models → CoreML (.mlpackage) cho iPhone 15 Benchmarking
==============================================================================

Script chuyển đổi 500 kiến trúc HyTra PDWRS-selected từ PyTorch → CoreML:

    PyTorch (HyTraProxyModel)
        → HyTraProxyTraceable      (trace-friendly version)
        → torch.jit.trace()        (TorchScript IR)
        → coremltools.convert()    (CoreML ML Program)
        → .mlpackage               (iOS-ready model)
        + Optional FP16 quantization

Tại sao CoreML?
  - Native Apple framework, tối ưu cho Apple Neural Engine (ANE)
  - iPhone 15 có 16-core Neural Engine, CoreML auto-route ops → ANE/GPU/CPU
  - Hỗ trợ Transformer ops (Multi-Head Attention) từ iOS 16+
  - Xcode Instruments cho per-layer profiling

Cách đo trên iPhone 15:
  a) Python-based: coremltools predict (chạy trên Mac, không phải iPhone thật)
  b) Xcode:        Deploy .mlpackage → iPhone 15, dùng ML Performance Report
  c) Swift app:    LatencyBenchmarkApp (có sẵn trong ios_benchmark_app/)

Prerequisites:
  pip install coremltools>=7.0 torch>=2.0
  (Chỉ chạy được trên macOS)

Usage:
  python export_coreml.py --input ../hytra_latency_dataset.json --limit 20
  python export_coreml.py --input ../hytra_latency_dataset.json --quantize fp16
  python export_coreml.py --input ../hytra_latency_dataset.json --benchmark
  python export_coreml.py --input ../hytra_latency_dataset.json --format executorch

Output:
  ./coreml_models/hytra_XXXX.mlpackage  — CoreML models
  export_manifest.json                   — Export metadata
  results_ip15.json                      — Python-based benchmark results (--benchmark)
"""

import os
import sys
import gc
import json
import time
import argparse
import traceback
from datetime import datetime
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

# ── Project paths ────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MHLP_DIR = os.path.join(SCRIPT_DIR, "..")
sys.path.insert(0, MHLP_DIR)
sys.path.insert(0, os.path.join(MHLP_DIR, "..", "searching"))
sys.path.insert(0, os.path.join(MHLP_DIR, "..", "OpenSelfSup"))

import torch
import torch.nn as nn

# Import constants và utils từ pipeline
from hytra_latency_pipeline import (
    _arch_string_to_tuples,
    TUPLE_TO_OP_INDEX,
    OP_INDEX_TO_TUPLE,
    NUM_STAGES,
    LAYERS_PER_STAGE,
)

# CoreML tools — cần cài: pip install coremltools>=7.0
try:
    import coremltools as ct
    COREML_AVAILABLE = True
    print(f"  coremltools {ct.__version__} available")
except ImportError:
    COREML_AVAILABLE = False
    print("  WARNING: coremltools not installed. Run: pip install coremltools>=7.0")


# ============================================================================
#  1. TRACE-FRIENDLY MODEL FOR COREML EXPORT
# ============================================================================

class _SelfAttentionBlockTraceable(nn.Module):
    """
    Phiên bản trace-friendly của SelfAttentionBlock cho CoreML export.

    Thay đổi so với HyTraProxyModel gốc:
      - Hardcode head_dim → tránh dynamic shapes khi trace
      - Dùng reshape thay vì view (CoreML-safe)
      - torch.matmul thay vì @ operator
      - Pre-compute scale factor

    CoreML yêu cầu model hoàn toàn traceable:
      - Không control flow phụ thuộc data
      - Không dynamic shapes (trừ batch dim)
    """

    def __init__(self, in_channels: int, out_channels: int, num_heads: int = 8):
        super().__init__()
        self.out_channels = out_channels
        self.num_heads = num_heads
        self.head_dim = out_channels // num_heads

        self.proj_in = (
            nn.Conv2d(in_channels, out_channels, 1)
            if in_channels != out_channels
            else nn.Identity()
        )
        self.qkv = nn.Conv2d(out_channels, out_channels * 3, 1)
        self.proj_out = nn.Conv2d(out_channels, out_channels, 1)
        self.norm = nn.BatchNorm2d(out_channels)
        self.scale = self.head_dim ** -0.5

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, H, W = x.shape
        x = self.proj_in(x)

        qkv = self.qkv(x)                                      # (B, 3C, H, W)
        qkv = qkv.reshape(B, 3, self.num_heads, self.head_dim, H * W)
        q = qkv[:, 0]                                          # (B, heads, dim, HW)
        k = qkv[:, 1]
        v = qkv[:, 2]

        # Attention: (B, heads, HW, HW) — matmul for trace compatibility
        attn = torch.matmul(q.transpose(-2, -1), k) * self.scale
        attn = torch.softmax(attn, dim=-1)

        # (B, heads, dim, HW)
        out = torch.matmul(v, attn.transpose(-2, -1))
        out = out.reshape(B, self.out_channels, H, W)

        out = self.proj_out(out)
        out = self.norm(out)
        return out


class HyTraProxyTraceable(nn.Module):
    """
    Phiên bản traceable của HyTraProxyModel cho CoreML export.

    Kiến trúc giống HyTraProxyModel nhưng:
      - Dùng _SelfAttentionBlockTraceable (trace-safe attention)
      - Build trên CPU (CoreML export không cần GPU)
      - Forward path đơn giản, không branching

    Nhận input ở 2 dạng:
      - arch_tuples: List[(block_type, scale)] — new pipeline format
      - op_indices:  List[List[int]]           — BossNAS format (fallback)
    """

    STAGE_CHANNELS: List[Tuple[int, int]] = [
        (64, 256), (256, 512), (512, 1024), (1024, 2048),
    ]

    def __init__(
        self,
        arch_tuples: List[Tuple[str, float]],
        input_size: int = 224,
    ):
        super().__init__()
        self.arch = arch_tuples

        # Stem (ResNet-50 style)
        self.stem = nn.Sequential(
            nn.Conv2d(3, 64, 7, stride=2, padding=3, bias=False),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(3, stride=2, padding=1),
        )

        # 4 Stages
        self.stages = nn.ModuleList()
        for stage_idx in range(NUM_STAGES):
            in_c, out_c = self.STAGE_CHANNELS[stage_idx]
            layers: List[nn.Module] = []

            if stage_idx > 0:
                layers.append(nn.Sequential(
                    nn.Conv2d(in_c, out_c, 1, stride=2, bias=False),
                    nn.BatchNorm2d(out_c),
                ))
                current_c = out_c
            else:
                current_c = in_c

            for pos in range(LAYERS_PER_STAGE):
                block_type, _scale = arch_tuples[stage_idx * LAYERS_PER_STAGE + pos]
                layers.append(self._make_block(block_type, current_c, out_c))
                current_c = out_c

            self.stages.append(nn.Sequential(*layers))

        # Head
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(2048, 1000)

    @staticmethod
    def _make_block(block_type: str, in_c: int, out_c: int) -> nn.Module:
        if block_type == "ResConv":
            mid_c = max(out_c // 4, 1)
            return nn.Sequential(
                nn.Conv2d(in_c, mid_c, 1, bias=False),
                nn.BatchNorm2d(mid_c),
                nn.ReLU(inplace=True),
                nn.Conv2d(mid_c, mid_c, 3, padding=1, bias=False),
                nn.BatchNorm2d(mid_c),
                nn.ReLU(inplace=True),
                nn.Conv2d(mid_c, out_c, 1, bias=False),
                nn.BatchNorm2d(out_c),
                nn.ReLU(inplace=True),
            )
        elif block_type == "ResAtt":
            return _SelfAttentionBlockTraceable(in_c, out_c)
        else:
            raise ValueError(f"Unknown block_type: {block_type}")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.stem(x)
        for stage in self.stages:
            x = stage(x)
        x = self.avgpool(x)
        x = torch.flatten(x, 1)
        return self.fc(x)


# ============================================================================
#  2. COREML EXPORT PIPELINE
# ============================================================================

def export_single_model(
    arch_tuples: List[Tuple[str, float]],
    arch_idx: int,
    arch_string: str,
    output_dir: str,
    input_shape: Tuple[int, ...] = (1, 3, 224, 224),
    quantize_fp16: bool = False,
) -> Dict[str, Any]:
    """
    Export MỘT HyTra architecture sang CoreML .mlpackage.

    Pipeline:
      1. Build HyTraProxyTraceable (CPU, eval mode)
      2. torch.jit.trace() với dummy input
      3. coremltools.convert() — compute_units=ALL, iOS16+ target
      4. (Optional) FP16 quantization — giảm ~50% model size
      5. Lưu .mlpackage + post-export validation

    Args:
        arch_tuples:    16 (block_type, scale) tuples
        arch_idx:       Index trong danh sách
        arch_string:    String representation (for metadata)
        output_dir:     Thư mục output
        input_shape:    (1, 3, 224, 224)
        quantize_fp16:  True → quantize weights sang FP16

    Returns:
        Dict với export info (path, size, validation status, ...).
    """
    model_name = f"hytra_{arch_idx:04d}"
    model_path = os.path.join(output_dir, f"{model_name}.mlpackage")

    # Step 1: Build traceable model
    model = HyTraProxyTraceable(arch_tuples, input_size=input_shape[2])
    model.eval()
    params = sum(p.numel() for p in model.parameters())

    # Step 2: Trace
    dummy_input = torch.randn(*input_shape)
    with torch.no_grad():
        traced_model = torch.jit.trace(model, dummy_input)

    # Step 3: Convert to CoreML
    coreml_model = ct.convert(
        traced_model,
        inputs=[
            ct.ImageType(
                name="input_image",
                shape=input_shape,
                scale=1.0 / 255.0,
                color_layout=ct.colorlayout.RGB,
            )
        ],
        compute_units=ct.ComputeUnit.ALL,            # ANE + GPU + CPU
        minimum_deployment_target=ct.target.iOS16,    # For Transformer ops
        convert_to="mlprogram",
    )

    # Metadata (hiển thị trong Xcode)
    coreml_model.author = "MHLP-NAS Pipeline"
    coreml_model.short_description = (
        f"HyTra #{arch_idx} | {params / 1e6:.1f}M params"
        f"{' | FP16' if quantize_fp16 else ''}"
    )
    coreml_model.version = "1.0"

    # Step 4: FP16 Quantization (optional)
    if quantize_fp16:
        try:
            from coremltools.optimize.coreml import (
                OpLinearQuantizerConfig,
                OptimizationConfig,
                linear_quantize_weights,
            )
            op_config = OpLinearQuantizerConfig(
                mode="linear_symmetric", dtype="float16"
            )
            config = OptimizationConfig(global_config=op_config)
            coreml_model = linear_quantize_weights(coreml_model, config=config)
        except Exception as eq:
            # Fallback cho coremltools versions cũ
            try:
                coreml_model = ct.models.neural_network.quantization_utils.quantize_weights(
                    coreml_model, nbits=16
                )
            except Exception:
                print(f"      WARNING: FP16 quantization failed (non-critical): {eq}")

    # Step 5: Save .mlpackage
    coreml_model.save(model_path)

    file_size_mb = sum(
        os.path.getsize(os.path.join(dp, f))
        for dp, _, fns in os.walk(model_path)
        for f in fns
    ) / (1024 * 1024)

    pytorch_size_mb = sum(
        p.numel() * p.element_size() for p in model.parameters()
    ) / (1024 * 1024)

    # Step 6: Post-export Validation
    validation_status = "skipped"
    try:
        loaded = ct.models.MLModel(model_path)
        test_input = np.random.rand(*input_shape).astype(np.float32) * 255
        test_result = loaded.predict({"input_image": test_input})
        if test_result is not None:
            validation_status = "passed"
        del loaded
    except Exception as ve:
        validation_status = f"failed: {ve}"

    # Cleanup
    del model, traced_model, coreml_model
    gc.collect()

    return {
        "arch_idx": arch_idx,
        "arch_string": arch_string,
        "model_name": model_name,
        "model_path": model_path,
        "params": params,
        "file_size_mb": round(file_size_mb, 2),
        "pytorch_size_mb": round(pytorch_size_mb, 2),
        "compression_ratio": round(
            pytorch_size_mb / file_size_mb, 2
        ) if file_size_mb > 0 else 0,
        "quantized_fp16": quantize_fp16,
        "format": "mlpackage",
        "compute_units": "ALL",
        "min_ios": "16.0",
        "validation": validation_status,
    }


def export_all(
    architectures: List[Dict[str, Any]],
    output_dir: str,
    input_shape: Tuple[int, ...] = (1, 3, 224, 224),
    quantize_fp16: bool = False,
) -> Tuple[List[Dict], List[Dict]]:
    """
    Export tất cả architectures sang CoreML.

    Returns:
        (exported, failed)
    """
    os.makedirs(output_dir, exist_ok=True)
    exported, failed = [], []
    total = len(architectures)

    print(f"\n{'=' * 70}")
    print(f"  COREML EXPORT — {total} architectures")
    print(f"  Output dir: {output_dir}")
    print(f"  Input shape: {input_shape}")
    print(f"  FP16 Quantization: {'ON' if quantize_fp16 else 'OFF'}")
    print(f"{'=' * 70}\n")

    for i, arch_info in enumerate(architectures):
        arch_str = arch_info["arch_string"]
        progress = f"[{i + 1:3d}/{total}]"

        try:
            arch_tuples = _arch_string_to_tuples(arch_str)
            result = export_single_model(
                arch_tuples=arch_tuples,
                arch_idx=i,
                arch_string=arch_str,
                output_dir=output_dir,
                input_shape=input_shape,
                quantize_fp16=quantize_fp16,
            )
            exported.append(result)
            val_icon = "OK" if result["validation"] == "passed" else "??"
            print(
                f"  {progress} [{val_icon}] {result['model_name']} — "
                f"{result['params'] / 1e6:.1f}M params, "
                f"{result['file_size_mb']:.1f} MB CoreML"
            )
        except Exception as e:
            failed.append({
                "arch_idx": i,
                "arch_string": arch_str,
                "error": str(e),
                "traceback": traceback.format_exc(),
            })
            print(f"  {progress} [FAIL] {e}")

    print(f"\n  Summary: {len(exported)} exported, {len(failed)} failed")
    return exported, failed


# ============================================================================
#  3. PYTHON-BASED COREML BENCHMARK (trên Mac, không cần iPhone)
# ============================================================================

def benchmark_coreml_on_mac(
    export_results: List[Dict],
    warmup_runs: int = 20,
    measure_runs: int = 50,
    input_shape: Tuple[int, ...] = (1, 3, 224, 224),
) -> List[Dict]:
    """
    Benchmark CoreML models trên Mac (Python API).

    NOTE: Đây KHÔNG phải benchmark trên iPhone thật.
    CoreML trên Mac sẽ dùng GPU (Metal) hoặc CPU — KHÔNG có ANE.
    Kết quả chỉ dùng làm proxy/sanity check.

    Để đo trên iPhone 15 thật, cần:
      - Deploy .mlpackage qua Xcode → iPhone 15
      - Chạy LatencyBenchmarkApp (có sẵn trong ios_benchmark_app/)
      - Hoặc dùng Xcode ML Performance Report

    Args:
        export_results: List of dicts from export_all()
        warmup_runs:    Warm-up iterations
        measure_runs:   Measurement iterations

    Returns:
        List of benchmark results per model.
    """
    print(f"\n{'=' * 70}")
    print(f"  COREML BENCHMARK (Mac Python API)")
    print(f"  NOTE: Proxy measurement — NOT iPhone ANE latency")
    print(f"  warmup={warmup_runs}, measure={measure_runs}")
    print(f"{'=' * 70}\n")

    results = []

    for idx, info in enumerate(export_results):
        model_path = info["model_path"]
        if not os.path.exists(model_path):
            print(f"  [{idx+1}] SKIP: {model_path} not found")
            continue

        try:
            # Load CoreML model
            coreml_model = ct.models.MLModel(model_path)
            dummy_input = {
                "input_image": np.random.rand(*input_shape).astype(np.float32) * 255
            }

            # Warm-up
            for _ in range(warmup_runs):
                _ = coreml_model.predict(dummy_input)

            # Measure
            latencies = []
            for _ in range(measure_runs):
                t0 = time.perf_counter()
                _ = coreml_model.predict(dummy_input)
                t1 = time.perf_counter()
                latencies.append((t1 - t0) * 1000.0)

            arr = np.array(latencies)
            q25, q75 = np.percentile(arr, 25), np.percentile(arr, 75)
            iqr = q75 - q25
            mask = (arr >= q25 - 3 * iqr) & (arr <= q75 + 3 * iqr)
            clean = arr[mask]

            bench = {
                "arch_idx": info["arch_idx"],
                "arch_string": info["arch_string"],
                "model_name": info["model_name"],
                "params": info["params"],
                "latency_ms": {
                    "mean":   round(float(np.mean(arr)), 4),
                    "std":    round(float(np.std(arr)), 4),
                    "min":    round(float(np.min(arr)), 4),
                    "max":    round(float(np.max(arr)), 4),
                    "median": round(float(np.median(arr)), 4),
                    "p95":    round(float(np.percentile(arr, 95)), 4),
                    "p99":    round(float(np.percentile(arr, 99)), 4),
                    "iqr":    round(float(iqr), 4),
                    "clean_mean": round(float(np.mean(clean)), 4) if len(clean) > 0 else None,
                    "num_outliers": int(len(arr) - len(clean)),
                },
                "note": "Python CoreML benchmark on Mac (NOT iPhone ANE)"
            }
            results.append(bench)
            print(
                f"  [{idx+1:3d}] {info['model_name']} — "
                f"median {bench['latency_ms']['median']:.2f} ms (Mac proxy)"
            )

            del coreml_model
            gc.collect()

        except Exception as e:
            print(f"  [{idx+1:3d}] FAIL: {e}")

    return results


# ============================================================================
#  4. ALTERNATIVE — ExecuTorch (PyTorch native on-device inference)
# ============================================================================

def export_single_executorch(
    arch_tuples: List[Tuple[str, float]],
    arch_idx: int,
    arch_string: str,
    output_dir: str,
    input_shape: Tuple[int, ...] = (1, 3, 224, 224),
) -> Dict[str, Any]:
    """
    [ALTERNATIVE] Export sang ExecuTorch .pte format.

    ExecuTorch = Meta's on-device inference framework cho PyTorch.
    Phù hợp nếu CoreML gặp lỗi với attention ops.

    Requires: pip install executorch
    """
    try:
        from executorch.exir import to_edge
        from torch.export import export
    except ImportError:
        raise ImportError(
            "ExecuTorch not installed. "
            "See: https://pytorch.org/executorch/stable/getting-started-setup.html"
        )

    model_name = f"hytra_{arch_idx:04d}"
    model_path = os.path.join(output_dir, f"{model_name}.pte")

    model = HyTraProxyTraceable(arch_tuples, input_size=input_shape[2])
    model.eval()
    params = sum(p.numel() for p in model.parameters())

    dummy_input = (torch.randn(*input_shape),)
    exported_program = export(model, dummy_input)
    edge_program = to_edge(exported_program)

    with open(model_path, "wb") as f:
        edge_program.to_executorch().write_to_file(f)

    file_size_mb = os.path.getsize(model_path) / (1024 * 1024)

    del model
    gc.collect()

    return {
        "arch_idx": arch_idx,
        "arch_string": arch_string,
        "model_name": model_name,
        "model_path": model_path,
        "params": params,
        "file_size_mb": round(file_size_mb, 2),
        "format": "executorch_pte",
    }


# ============================================================================
#  5. GENERATE SWIFT BENCHMARK CONFIG
# ============================================================================

def generate_swift_config(
    export_results: List[Dict],
    output_path: str,
):
    """
    Sinh file JSON config cho LatencyBenchmarkApp (iOS Swift).

    File này sẽ được nhúng vào Xcode project, app đọc để biết
    model nào cần benchmark và metadata tương ứng.

    Output format (cho Swift JSONDecoder):
    {
        "models": [
            {
                "name": "hytra_0000",
                "arch_string": "ResConv@0.125|...",
                "params": 12345678,
                "file": "hytra_0000.mlpackage"
            }, ...
        ],
        "config": {
            "warmup_runs": 50,
            "measure_runs": 100,
            "input_size": [1, 3, 224, 224]
        }
    }
    """
    config = {
        "models": [
            {
                "name": r["model_name"],
                "arch_string": r["arch_string"],
                "params": r["params"],
                "file": f"{r['model_name']}.mlpackage",
            }
            for r in export_results
        ],
        "config": {
            "warmup_runs": 50,
            "measure_runs": 100,
            "input_size": [1, 3, 224, 224],
        },
    }

    with open(output_path, "w") as f:
        json.dump(config, f, indent=2)
    print(f"\n  Swift config → {output_path}")
    print(f"  Copy file này vào Xcode project cùng với .mlpackage files")


# ============================================================================
#  6. MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Export HyTra architectures → CoreML cho iPhone 15",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Workflow cho iPhone 15 Deployment:

  1. Export CoreML trên Mac:
     python export_coreml.py --input ../hytra_latency_dataset.json

  2. (Optional) Benchmark proxy trên Mac:
     python export_coreml.py --input ../hytra_latency_dataset.json --benchmark

  3. Deploy lên iPhone 15 qua Xcode:
     a) Mở Xcode project ios_benchmark_app/
     b) Drag .mlpackage files + benchmark_config.json vào project
     c) Build & Run trên iPhone 15 (USB connected)

  4. Export kết quả từ iPhone:
     - App export results_ip15.json qua Files/AirDrop
     - Copy về thư mục measure_real_devices/

  5. Aggregate:
     python aggregate_to_csv.py --ip15 results_ip15.json
        """,
    )
    parser.add_argument(
        "--input", type=str, default="../hytra_latency_dataset.json",
        help="JSON file chứa kiến trúc PDWRS-selected (từ pipeline)",
    )
    parser.add_argument(
        "--output_dir", type=str, default="./coreml_models",
        help="Output directory cho CoreML models",
    )
    parser.add_argument(
        "--format", choices=["coreml", "executorch", "both"],
        default="coreml", help="Export format",
    )
    parser.add_argument(
        "--quantize", choices=["none", "fp16"], default="none",
        help="Weight quantization (fp16 = half size, minimal accuracy loss)",
    )
    parser.add_argument(
        "--limit", type=int, default=None,
        help="Giới hạn số kiến trúc (test nhanh)",
    )
    parser.add_argument(
        "--benchmark", action="store_true",
        help="Benchmark CoreML models trên Mac (proxy, không phải iPhone)",
    )
    parser.add_argument(
        "--benchmark_warmup", type=int, default=20,
        help="Benchmark warm-up iters",
    )
    parser.add_argument(
        "--benchmark_runs", type=int, default=50,
        help="Benchmark measurement iters",
    )
    args = parser.parse_args()

    # ── Banner ───────────────────────────────────────────────────────
    print("\n" + "=" * 72)
    print("  MHLP — Export HyTra → CoreML for iPhone 15")
    print("  Format     : {}".format(args.format))
    print("  Quantize   : {}".format(args.quantize))
    print("  Benchmark  : {}".format("Yes (Mac proxy)" if args.benchmark else "No"))
    print("=" * 72)

    # ── Load kiến trúc PDWRS ─────────────────────────────────────────
    input_path = args.input
    if not os.path.isabs(input_path):
        input_path = os.path.join(SCRIPT_DIR, input_path)
    print(f"\n  Loading: {input_path}")

    with open(input_path, "r") as f:
        data = json.load(f)

    archs = data["selected_architectures"]
    if args.limit:
        archs = archs[:args.limit]
    print(f"  Architectures to export: {len(archs)}")

    output_dir = os.path.join(SCRIPT_DIR, args.output_dir)
    all_results: Dict[str, List] = {"coreml": [], "executorch": []}

    # ── CoreML Export ────────────────────────────────────────────────
    if args.format in ("coreml", "both"):
        if not COREML_AVAILABLE:
            print("\n  ERROR: coremltools required. Install: pip install coremltools>=7.0")
            sys.exit(1)

        coreml_dir = os.path.join(output_dir, "coreml")
        exported, failed = export_all(
            archs, coreml_dir,
            quantize_fp16=(args.quantize == "fp16"),
        )
        all_results["coreml"] = exported

        # Generate Swift benchmark config
        if exported:
            generate_swift_config(
                exported,
                os.path.join(coreml_dir, "benchmark_config.json"),
            )

    # ── ExecuTorch Export (alternative) ──────────────────────────────
    if args.format in ("executorch", "both"):
        et_dir = os.path.join(output_dir, "executorch")
        os.makedirs(et_dir, exist_ok=True)
        print(f"\n  ExecuTorch export → {et_dir}")

        for i, arch_info in enumerate(archs):
            arch_str = arch_info["arch_string"]
            try:
                arch_tuples = _arch_string_to_tuples(arch_str)
                result = export_single_executorch(
                    arch_tuples, i, arch_str, et_dir,
                )
                all_results["executorch"].append(result)
                print(f"  [{i + 1}/{len(archs)}] OK {result['model_name']}")
            except Exception as e:
                print(f"  [{i + 1}/{len(archs)}] FAIL: {e}")

    # ── Save Manifest ────────────────────────────────────────────────
    manifest = {
        "timestamp": datetime.now().isoformat(),
        "hardware_label": "ip15",
        "num_models": sum(len(v) for v in all_results.values()),
        "export_format": args.format,
        "quantize": args.quantize,
        "models": all_results,
    }
    os.makedirs(output_dir, exist_ok=True)
    manifest_path = os.path.join(output_dir, "export_manifest.json")
    with open(manifest_path, "w") as f:
        json.dump(manifest, f, indent=2)
    print(f"\n  Manifest → {manifest_path}")

    # ── Optional Mac Benchmark ───────────────────────────────────────
    if args.benchmark and all_results["coreml"]:
        bench_results = benchmark_coreml_on_mac(
            all_results["coreml"],
            warmup_runs=args.benchmark_warmup,
            measure_runs=args.benchmark_runs,
        )

        # Save benchmark results (dùng tạm nếu chưa có iPhone)
        bench_output = {
            "timestamp": datetime.now().isoformat(),
            "hardware_label": "ip15",
            "note": "Mac CoreML proxy benchmark — NOT actual iPhone 15 measurements",
            "measurement_config": {
                "warmup_runs": args.benchmark_warmup,
                "measure_runs": args.benchmark_runs,
                "input_size": [3, 224, 224],
            },
            "num_measured": len(bench_results),
            "results": bench_results,
        }
        bench_path = os.path.join(SCRIPT_DIR, "results_ip15.json")
        with open(bench_path, "w") as f:
            json.dump(bench_output, f, indent=2)
        print(f"\n  Benchmark results → {bench_path}")
        print(f"  NOTE: Thay bằng kết quả iPhone 15 thật khi có.")

    # ── Hướng dẫn  ───────────────────────────────────────────────────
    print(f"\n  {'=' * 60}")
    print(f"  NEXT STEPS:")
    print(f"  {'=' * 60}")
    if all_results["coreml"]:
        coreml_dir = os.path.join(output_dir, "coreml")
        print(f"  1. Copy thư mục {coreml_dir}/ sang Mac")
        print(f"  2. Mở ios_benchmark_app/ trong Xcode")
        print(f"  3. Kéo .mlpackage + benchmark_config.json vào project")
        print(f"  4. Connect iPhone 15 via USB → Build & Run")
        print(f"  5. Lấy results_ip15.json từ iPhone")
        print(f"  6. Copy results_ip15.json về thư mục measure_real_devices/")
    print(f"  7. Chạy: python aggregate_to_csv.py --ip15 results_ip15.json")
    print("=" * 72)


if __name__ == "__main__":
    main()
