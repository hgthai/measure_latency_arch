# Real-Device Latency Measurement Scripts

Bộ 4 scripts đo latency thực tế trên 3 thiết bị, sử dụng 500 kiến trúc
PDWRS đã chọn từ `hytra_latency_pipeline.py`.

## Quy trình

```
hytra_latency_pipeline.py
        │
        ▼  (xuất hytra_latency_dataset.json)
        │
   ┌────┴────────────────────────────┐
   │                                 │
   ▼                                 ▼
measure_rtx4080.py          measure_mac_m1.py
(Chạy trên server CUDA)     (Chạy trên Macbook M1)
   │                                 │
   ▼                                 ▼
results_rtx4080.json        results_mac_m1.json
   │                                 │
   │    ┌────────────────────────┐   │
   │    │  export_coreml.py      │   │
   │    │  (Chạy trên Mac)       │   │
   │    │   → .mlpackage files   │   │
   │    │   → Xcode → iPhone 15  │   │
   │    │   → results_ip15.json  │   │
   │    └────────────────────────┘   │
   │                 │               │
   └─────────┬───────┘───────────────┘
             ▼
    aggregate_to_csv.py
             │
             ▼
    hytra_latency_dataset.csv
    [architecture_string, hardware_type, latency_ms]
```

## Cách chạy

### Bước 1: Sinh & chọn 500 kiến trúc (trên server)
```bash
cd src/mhlp
python hytra_latency_pipeline.py --device cpu --warmup 5 --runs 10  # test nhanh
# Hoặc chạy đầy đủ (cần GPU):
python hytra_latency_pipeline.py --device cuda
```

### Bước 2: Đo RTX 4080 (trên server có GPU)
```bash
cd src/mhlp/measure_real_devices
python measure_rtx4080.py --input ../hytra_latency_dataset.json
```

### Bước 3: Đo Macbook M1 (copy sang Mac, chạy)
```bash
python measure_mac_m1.py --input hytra_latency_dataset.json
```

### Bước 4: iPhone 15
```bash
# a) Export CoreML trên Mac:
python export_coreml.py --input hytra_latency_dataset.json --output_dir ./coreml_models
# b) Mở Xcode project, kéo .mlpackage vào, build & run trên iPhone 15
# c) Lấy results_ip15.json từ iPhone
```

### Bước 5: Tổng hợp
```bash
python aggregate_to_csv.py \
    --rtx4080  results_rtx4080.json \
    --mac_m1   results_mac_m1.json \
    --ip15     results_ip15.json \
    --output   ../hytra_latency_dataset.csv
```
