#!/usr/bin/env python3
"""
==============================================================================
Đo Latency Thực Tế trên Macbook M1 (Apple MPS Backend)
==============================================================================

Script đo inference latency của 500 kiến trúc HyTra PDWRS-selected
trên Apple Silicon M1 thông qua PyTorch MPS backend.

Measurement Protocol (chống nhiễu OS):
  1. Thermal check: Giám sát nhiệt độ qua pmset/powermetrics
  2. Warm-up:  50 forward passes → KHÔNG ghi nhận
     (MPS shader compilation, memory pool allocation, freq ramp-up)
  3. Đo đạc:  100 forward passes → ghi nhận từng latency
     - torch.mps.synchronize() TRƯỚC khi bấm giờ
     - Forward pass
     - torch.mps.synchronize() SAU forward
     - time.perf_counter() cho high-resolution timing
  4. Thống kê: mean, std, min, max, median, p95, p99
  5. IQR outlier detection (3× IQR rule)
  6. Kết quả chính: **median** (robust với OS scheduler outliers)

Prerequisites:
  - macOS 12.3+ trên Apple Silicon (M1/M2/M3)
  - PyTorch >= 2.0 (có MPS backend)
  - File hytra_latency_dataset.json (output từ hytra_latency_pipeline.py)

Usage:
  python measure_mac_m1.py --input ../hytra_latency_dataset.json
  python measure_mac_m1.py --input ../hytra_latency_dataset.json --limit 20
  python measure_mac_m1.py --input ../hytra_latency_dataset.json --warmup 100 --runs 200

Output:
  results_mac_m1.json — Full measurement results + device info
"""

import os
import sys
import gc
import json
import time
import argparse
import platform
import subprocess
from datetime import datetime
from typing import Any, Dict, List, Tuple

import numpy as np

# ── Project paths ────────────────────────────────────────────────────────
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
MHLP_DIR = os.path.join(SCRIPT_DIR, "..")
sys.path.insert(0, MHLP_DIR)
sys.path.insert(0, os.path.join(MHLP_DIR, "..", "searching"))
sys.path.insert(0, os.path.join(MHLP_DIR, "..", "OpenSelfSup"))

import torch
import torch.nn as nn

# Import proxy model và utils từ pipeline
from hytra_latency_pipeline import (
    HyTraProxyModel,
    _arch_string_to_tuples,
    OP_INDEX_TO_TUPLE,
    NUM_STAGES,
    LAYERS_PER_STAGE,
)


# ============================================================================
#  1. DEVICE SETUP — Apple MPS Backend
# ============================================================================

def check_mps_device() -> Dict[str, Any]:
    """
    Kiểm tra và thu thập thông tin Apple MPS device.

    MPS (Metal Performance Shaders) là GPU backend của Apple Silicon,
    tương đương với CUDA trên NVIDIA. Cần:
        - macOS 12.3+
        - Apple Silicon (M1/M2/M3) hoặc AMD GPU trên Intel Mac
        - PyTorch >= 2.0

    Returns:
        Dict with device info. Raises RuntimeError nếu không có MPS.
    """
    if not (hasattr(torch.backends, "mps") and torch.backends.mps.is_available()):
        raise RuntimeError(
            "MPS không khả dụng! Script này yêu cầu Apple Silicon.\n"
            "Yêu cầu: macOS 12.3+ với Apple M1/M2/M3 & PyTorch >= 2.0."
        )

    # Kiểm tra bằng cách tạo tensor thử
    try:
        test_tensor = torch.zeros(1, device="mps")
        del test_tensor
    except Exception as e:
        raise RuntimeError(f"MPS khả dụng nhưng không hoạt động: {e}")

    # Thu thập thông tin hệ thống
    info = {
        "platform": platform.platform(),
        "python_version": platform.python_version(),
        "pytorch_version": torch.__version__,
        "processor": platform.processor(),
        "machine": platform.machine(),
        "macos_version": platform.mac_ver()[0],
        "hardware_label": "Macbook_M1",
    }

    # Cố gắng lấy thông tin chip cụ thể từ sysctl
    try:
        chip_info = subprocess.check_output(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            stderr=subprocess.DEVNULL,
        ).decode().strip()
        info["chip_info"] = chip_info
    except Exception:
        info["chip_info"] = "Apple Silicon (unknown)"

    # Lấy RAM tổng cộng
    try:
        mem_bytes = subprocess.check_output(
            ["sysctl", "-n", "hw.memsize"],
            stderr=subprocess.DEVNULL,
        ).decode().strip()
        info["ram_gb"] = round(int(mem_bytes) / 1e9, 1)
    except Exception:
        info["ram_gb"] = "unknown"

    return info


def get_thermal_state() -> Dict[str, Any]:
    """
    Lấy trạng thái nhiệt của Mac (quantitative khi có thể).

    Quan trọng vì Mac M1 thermal throttle rất sớm (passive cooling),
    ảnh hưởng trực tiếp đến latency measurement.

    Returns:
        Dict với thermal info (cpu_die_temp, thermal_level, ...).
    """
    state = {"thermal_check_time": datetime.now().isoformat()}

    # Thử dùng powermetrics (cần sudo) → nhiều chi tiết
    try:
        output = subprocess.check_output(
            ["sudo", "-n", "powermetrics", "--samplers", "smc",
             "-n", "1", "-i", "100"],
            stderr=subprocess.DEVNULL,
            timeout=5,
        ).decode()
        for line in output.split("\n"):
            if "CPU die temperature" in line:
                temp = float(line.split(":")[-1].strip().rstrip(" C°"))
                state["cpu_die_temp_c"] = temp
            elif "GPU die temperature" in line:
                temp = float(line.split(":")[-1].strip().rstrip(" C°"))
                state["gpu_die_temp_c"] = temp
    except Exception:
        pass

    # Fallback: pmset -g therm (không cần sudo)
    try:
        output = subprocess.check_output(
            ["pmset", "-g", "therm"],
            stderr=subprocess.DEVNULL,
            timeout=3,
        ).decode()
        if "CPU_Speed_Limit" in output:
            for line in output.split("\n"):
                if "CPU_Speed_Limit" in line:
                    speed = int(line.split("=")[-1].strip())
                    state["cpu_speed_limit_pct"] = speed
                    if speed < 100:
                        state["warning"] = (
                            f"THERMAL THROTTLING! CPU at {speed}% speed."
                        )
    except Exception:
        state["pmset_available"] = False

    return state


# ============================================================================
#  2. LATENCY MEASUREMENT — MPS-synchronized
# ============================================================================

def measure_single_architecture(
    arch_tuples: List[Tuple[str, float]],
    device: str = "mps",
    batch_size: int = 1,
    input_size: int = 224,
    warmup_runs: int = 50,
    measure_runs: int = 100,
) -> Dict[str, Any]:
    """
    Đo latency cho MỘT kiến trúc với MPS synchronization chính xác.

    Protocol:
      1. Build model → .to(mps) → .eval()
      2. Tạo dummy input trên MPS
      3. Warm-up: ``warmup_runs`` lần inference (không bấm giờ)
         - Metal shader compilation, memory pool, freq ramp-up
      4. Measure: ``measure_runs`` lần inference
         - torch.mps.synchronize() TRƯỚC perf_counter
         - forward(input)
         - torch.mps.synchronize() SAU forward
         - Ghi nhận (end - start) * 1000 ms
      5. Tính thống kê + IQR outlier detection
      6. Cleanup MPS memory

    NOTE: Dùng torch.inference_mode() thay vì no_grad()
          (hiệu quả hơn ~5-10% trên MPS vì không cần version tracking).

    Returns:
        Dict chứa latency stats + params.
    """
    # ── Build model ──────────────────────────────────────────────────
    model = HyTraProxyModel(arch_tuples, input_size=input_size)
    model = model.to(device).eval()
    params = sum(p.numel() for p in model.parameters())

    dummy_input = torch.randn(
        batch_size, 3, input_size, input_size, device=device
    )

    # ── Warm-up (with inference_mode for efficiency) ─────────────────
    with torch.inference_mode():
        for _ in range(warmup_runs):
            _ = model(dummy_input)
            torch.mps.synchronize()

    # ── Measure ──────────────────────────────────────────────────────
    latencies: List[float] = []
    with torch.inference_mode():
        for _ in range(measure_runs):
            torch.mps.synchronize()           # SYNC trước bấm giờ
            t0 = time.perf_counter()
            _ = model(dummy_input)
            torch.mps.synchronize()           # SYNC sau forward
            t1 = time.perf_counter()
            latencies.append((t1 - t0) * 1000.0)

    arr = np.array(latencies)

    # ── IQR outlier detection (3× IQR rule) ──────────────────────────
    q25, q75 = np.percentile(arr, 25), np.percentile(arr, 75)
    iqr = q75 - q25
    mask = (arr >= q25 - 3 * iqr) & (arr <= q75 + 3 * iqr)
    clean = arr[mask]

    stats = {
        "mean":   round(float(np.mean(arr)), 4),
        "std":    round(float(np.std(arr)), 4),
        "min":    round(float(np.min(arr)), 4),
        "max":    round(float(np.max(arr)), 4),
        "median": round(float(np.median(arr)), 4),
        "p95":    round(float(np.percentile(arr, 95)), 4),
        "p99":    round(float(np.percentile(arr, 99)), 4),
        "iqr":    round(float(iqr), 4),
        "clean_mean":   round(float(np.mean(clean)), 4) if len(clean) > 0 else None,
        "clean_median": round(float(np.median(clean)), 4) if len(clean) > 0 else None,
        "num_outliers": int(len(arr) - len(clean)),
        "all_latencies": [round(float(l), 4) for l in arr],
    }

    # ── Cleanup MPS memory ───────────────────────────────────────────
    del model, dummy_input
    gc.collect()
    # MPS memory pool cleanup
    if hasattr(torch.mps, "empty_cache"):
        torch.mps.empty_cache()

    return {"latency_ms": stats, "params": params}


# ============================================================================
#  3. BATCH MEASUREMENT PIPELINE
# ============================================================================

def measure_all(
    architectures: List[Dict[str, Any]],
    batch_size: int = 1,
    input_size: int = 224,
    warmup_runs: int = 50,
    measure_runs: int = 100,
    thermal_interval: int = 50,
) -> Tuple[List[Dict], List[Dict], List[Dict]]:
    """
    Đo latency cho toàn bộ danh sách kiến trúc trên MPS.

    Args:
        architectures: List of dicts from hytra_latency_dataset.json
        thermal_interval: Check thermal mỗi N architectures

    Returns:
        (successes, failures, thermal_logs)
    """
    try:
        from tqdm import tqdm
        iterator = tqdm(enumerate(architectures), total=len(architectures),
                        desc="Mac M1 Profiling")
    except ImportError:
        def _iter():
            for i, a in enumerate(architectures):
                if i % 50 == 0:
                    print(f"  [{i}/{len(architectures)}]...")
                yield i, a
        iterator = _iter()

    successes, failures = [], []
    thermal_logs: List[Dict] = []

    for i, arch_info in iterator:
        # Thermal monitoring (quan trọng cho Mac — passive cooling)
        if i % thermal_interval == 0:
            thermal = get_thermal_state()
            thermal["at_arch_idx"] = i
            thermal_logs.append(thermal)
            if "warning" in thermal:
                print(f"\n  ⚠️  {thermal['warning']} — Đợi 30s để giảm nhiệt...")
                time.sleep(30)
                # Check lại
                thermal2 = get_thermal_state()
                if "warning" in thermal2:
                    print(f"  ⚠️  Vẫn throttling, tiếp tục đo (kết quả có thể bị ảnh hưởng)")

        arch_str = arch_info["arch_string"]
        try:
            arch_tuples = _arch_string_to_tuples(arch_str)
            result = measure_single_architecture(
                arch_tuples,
                device="mps",
                batch_size=batch_size,
                input_size=input_size,
                warmup_runs=warmup_runs,
                measure_runs=measure_runs,
            )
            successes.append({
                "arch_idx": i,
                "arch_string": arch_str,
                "op_indices": arch_info.get("op_indices", []),
                "complexity": arch_info.get("complexity", 0),
                **result,
            })
        except Exception as exc:
            failures.append({
                "arch_idx": i,
                "arch_string": arch_str,
                "error": str(exc),
            })
            print(f"\n  [FAIL] #{i}: {exc}")
            # MPS cleanup after failure
            gc.collect()
            if hasattr(torch.mps, "empty_cache"):
                torch.mps.empty_cache()

    return successes, failures, thermal_logs


# ============================================================================
#  4. MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(
        description="Đo latency thực tế trên Macbook M1 (MPS)",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    parser.add_argument(
        "--input", type=str, default="../hytra_latency_dataset.json",
        help="JSON file chứa kiến trúc PDWRS-selected (từ pipeline)",
    )
    parser.add_argument("--output", type=str, default="results_mac_m1.json")
    parser.add_argument("--batch_size", type=int, default=1)
    parser.add_argument("--input_size", type=int, default=224)
    parser.add_argument("--warmup", type=int, default=50)
    parser.add_argument("--runs", type=int, default=100)
    parser.add_argument("--limit", type=int, default=None,
                        help="Giới hạn số kiến trúc (test nhanh)")
    parser.add_argument("--thermal_interval", type=int, default=50,
                        help="Check nhiệt độ mỗi N architectures")
    args = parser.parse_args()

    # ── Banner ───────────────────────────────────────────────────────
    print("\n" + "=" * 72)
    print("  MHLP — Real-Device Latency Measurement")
    print("  Target : Apple Macbook M1 (MPS Backend)")
    print("  Protocol: warmup={}, measure={}, BS={}".format(
        args.warmup, args.runs, args.batch_size))
    print("=" * 72)

    # ── Device check ─────────────────────────────────────────────────
    device_info = check_mps_device()
    print("\n  --- Device Info ---")
    for k, v in device_info.items():
        print(f"    {k}: {v}")

    # ── Initial thermal check ────────────────────────────────────────
    thermal_before = get_thermal_state()
    print("\n  --- Thermal State (before) ---")
    for k, v in thermal_before.items():
        print(f"    {k}: {v}")
    if "warning" in thermal_before:
        print(f"\n  ⚠️  {thermal_before['warning']}")
        print("  Gợi ý: Đặt Mac trên bề mặt thoáng, bật quạt tản nhiệt ngoài.")

    # ── Load kiến trúc PDWRS ─────────────────────────────────────────
    input_path = args.input
    if not os.path.isabs(input_path):
        input_path = os.path.join(SCRIPT_DIR, input_path)
    print(f"\n  Loading: {input_path}")

    with open(input_path, "r") as f:
        data = json.load(f)

    archs = data["selected_architectures"]
    if args.limit:
        archs = archs[:args.limit]
    print(f"  Architectures: {len(archs)}")

    # ── Measure ──────────────────────────────────────────────────────
    t_start = time.time()
    successes, failures, thermal_logs = measure_all(
        archs,
        batch_size=args.batch_size,
        input_size=args.input_size,
        warmup_runs=args.warmup,
        measure_runs=args.runs,
        thermal_interval=args.thermal_interval,
    )
    elapsed = time.time() - t_start

    # ── Final thermal check ──────────────────────────────────────────
    thermal_after = get_thermal_state()

    # ── Save ─────────────────────────────────────────────────────────
    output_data = {
        "timestamp": datetime.now().isoformat(),
        "device_info": device_info,
        "hardware_label": "Macbook_M1",
        "measurement_config": {
            "batch_size": args.batch_size,
            "input_size": [3, args.input_size, args.input_size],
            "warmup_runs": args.warmup,
            "measure_runs": args.runs,
        },
        "timing": {
            "total_seconds": round(elapsed, 1),
            "avg_per_arch_seconds": round(elapsed / max(len(successes), 1), 2),
        },
        "thermal": {
            "before": thermal_before,
            "after": thermal_after,
            "logs": thermal_logs,
        },
        "num_measured": len(successes),
        "num_failed": len(failures),
        "results": successes,
        "failed": failures,
    }

    output_path = os.path.join(SCRIPT_DIR, args.output)
    with open(output_path, "w") as f:
        json.dump(output_data, f, indent=2)
    print(f"\n  Results → {output_path}")

    # ── Summary ──────────────────────────────────────────────────────
    if successes:
        meds = [s["latency_ms"]["median"] for s in successes]
        print(f"\n  ╔{'═' * 54}╗")
        print(f"  ║  Macbook M1 (MPS) — FINAL SUMMARY                    ║")
        print(f"  ╠{'═' * 54}╣")
        print(f"  ║  Measured : {len(successes):4d} architectures                    ║")
        print(f"  ║  Failed   : {len(failures):4d}                                   ║")
        print(f"  ║  Total time: {elapsed:7.1f} s                              ║")
        print(f"  ║  Median lat range: {min(meds):7.2f} — {max(meds):7.2f} ms       ║")
        print(f"  ║  Mean of medians : {np.mean(meds):7.2f} ms                      ║")
        print(f"  ╚{'═' * 54}╝")

    if thermal_logs and any("warning" in t for t in thermal_logs):
        print("\n  ⚠️  THERMAL THROTTLING detected during measurement!")
        print("  Gợi ý: Xem xét chạy lại với khoảng nghỉ dài hơn.")

    print(f"\n  NEXT: Chạy export_coreml.py để export cho iPhone 15")
    print("=" * 72)


if __name__ == "__main__":
    main()
