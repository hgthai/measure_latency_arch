"""
HyTra Architecture Encoding v2 — Fabric-like DAG + 16D Hardware
================================================================

Cải tiến so với v1:
  1. DAG encoding đúng fabric-like topology từ BossNAS hytra_paths.py
     - Capture same-depth skip connections
     - Capture scale-transition edges
     - Node features phân biệt depth/stage rõ ràng hơn
  2. Hardware encoding 16D (categorical 8D + performance 8D)
     - Phân biệt được GPU cùng family (RTX3080 vs RTX4080)
     - Generalize tốt hơn sang unseen devices

Graph structure:
  Node 0:      Input virtual node
  Nodes 1-16:  16 choice blocks (4 stages × 4 layers)
  Node 17:     Output virtual node
  Total: 18 nodes (bỏ global node — dùng attention trong GCN thay thế)

Node features (17D):
  [0-1]   block_type one-hot: [is_ResConv, is_ResAtt]
  [2]     scale_ratio: float in {0.25, 0.125, 0.0625, 0.03125}
  [3-6]   scale one-hot: [1/4, 1/8, 1/16, 1/32]
  [7-10]  depth one-hot: [depth0, depth1, depth2, depth3]
  [11-14] stage one-hot: [stage0, stage1, stage2, stage3]
  [15]    position_in_stage normalized: {0, 1/3, 2/3, 1}
  [16]    is_resatt_eligible: 1 if scale in {1/16, 1/32}

Edges (adjacency matrix 18×18):
  Sequential:       block_i → block_{i+1} trong cùng stage
  Cross-stage:      last block stage k → first block stage k+1
  Same-depth skip:  block_i → block_j nếu cùng depth, j > i, cùng stage
  Input → B0, B16 → Output
  Self-loops trên tất cả nodes

Hardware encoding (16D):
  [0-7]   categorical: [is_mobile_soc, is_edge_device, is_desktop_gpu,
                         is_integrated_gpu, is_laptop_arm, is_laptop_x86,
                         is_raspberry, is_npu_dominant]
  [8-15]  performance (normalized [0,1]):
          [memory_norm, bandwidth_norm, tflops_norm, tdp_norm,
           cuda_cores_norm, arch_gen_norm, is_mobile_flag, is_npu_flag]
"""

from __future__ import annotations

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader
from typing import Dict, List, Optional, Tuple

# ── Re-export constants từ v1 để backward compat ──────────────────────────
from hytra_encoding import (
    BLOCK_TYPES, NUM_BLOCK_TYPES, SCALE_VALUES, NUM_SCALE_CLASSES,
    SCALE_INFO, RESATT_ALLOWED_SCALES, NUM_STAGES, LAYERS_PER_STAGE,
    NUM_CHOICE_BLOCKS, STAGE_DEPTHS, S_RANK, OP_INDEX_TO_TUPLE,
    validate_hytra_architecture, bossnas_to_tuples, tuples_to_bossnas,
    _find_scale_index,
)
from hytra_latency_pipeline import _arch_string_to_tuples
from hytra_cifar_paths import (
    RESATT_ALLOWED_SCALES_CIFAR,
    STAGE_DEPTHS_CIFAR,
    VALID_BLOCK_SCALES_CIFAR,
    normalize_hytra_cifar_arch,
    parse_hytra_cifar_arch_string,
)

# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  1. CONSTANTS V2                                                         ║
# ╚══════════════════════════════════════════════════════════════════════════╝

# Graph nodes: Input(0) + 16 blocks(1-16) + Output(17) = 18
# Bỏ Global node — dùng attention mechanism trong GCN thay thế
NUM_GRAPH_NODES_V2: int = NUM_CHOICE_BLOCKS + 2   # 18
INPUT_NODE_IDX_V2:  int = 0
BLOCK_START_IDX_V2: int = 1
BLOCK_END_IDX_V2:   int = 16
OUTPUT_NODE_IDX_V2: int = 17

# Node feature dimensions v2 (17D)
# [is_ResConv, is_ResAtt] + [scale_num] + [scale_1hot×4] +
# [depth_1hot×4] + [stage_1hot×4] + [pos_norm] + [resatt_eligible]
_BLOCK_TYPE_DIM = 2   # chỉ ResConv / ResAtt, bỏ Input/Output/Global
_SCALE_NUM_DIM  = 1
_SCALE_ONEHOT   = 4   # 4 scales: 1/4, 1/8, 1/16, 1/32
_DEPTH_ONEHOT   = 4   # 4 depth levels: 0,1,2,3
_STAGE_ONEHOT   = 4   # 4 stages
_POS_NORM_DIM   = 1
_RESATT_FLAG    = 1
NODE_FEATURE_DIM_V2: int = (
    _BLOCK_TYPE_DIM + _SCALE_NUM_DIM + _SCALE_ONEHOT +
    _DEPTH_ONEHOT + _STAGE_ONEHOT + _POS_NORM_DIM + _RESATT_FLAG
)  # = 17

# Hardware encoding dimensions v2 (16D)
HW_CATEGORICAL_DIM: int = 8
HW_PERFORMANCE_DIM: int = 8
HW_ENCODING_DIM_V2: int = HW_CATEGORICAL_DIM + HW_PERFORMANCE_DIM  # 16

# Scale → depth mapping (inverse của S_RANK)
SCALE_TO_DEPTH: Dict[float, int] = {
    1/32: 0,   # depth 0: 7×7
    1/16: 1,   # depth 1: 14×14
    1/8:  2,   # depth 2: 28×28
    1/4:  3,   # depth 3: 56×56
}

# Valid scales (không có 1.0 vì đó là input node)
VALID_BLOCK_SCALES: List[float] = [1/4, 1/8, 1/16, 1/32]

# HyTra-CIFAR graph nodes: Input(0) + 8 blocks(1-8) + Output(9)
NUM_GRAPH_NODES_CIFAR: int = sum(STAGE_DEPTHS_CIFAR) + 2
INPUT_NODE_IDX_CIFAR: int = 0
BLOCK_START_IDX_CIFAR: int = 1
BLOCK_END_IDX_CIFAR: int = sum(STAGE_DEPTHS_CIFAR)
OUTPUT_NODE_IDX_CIFAR: int = NUM_GRAPH_NODES_CIFAR - 1
NODE_FEATURE_DIM_CIFAR: int = NODE_FEATURE_DIM_V2 + 1

SCALE_TO_DEPTH_CIFAR: Dict[float, int] = {
    1.0: 0,
    1 / 2: 1,
    1 / 4: 2,
    1 / 8: 3,
}

# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  2. HARDWARE CATALOG V2 (16D)                                            ║
# ╚══════════════════════════════════════════════════════════════════════════╝

_NORM = {
    "memory":     32.0,    # GB
    "bandwidth":  960.0,   # GB/s
    "tflops":     83.0,    # TFLOPS FP32
    "tdp":        350.0,   # Watt
    "cuda_cores": 16384.0, # RTX 4090
    "arch_gen":   5.0,     # 1=old → 5=newest
}

# Format: [cat×8, perf×8]
# cat: [is_mobile_soc, is_edge_device, is_desktop_gpu, is_integrated_gpu,
#       is_laptop_arm, is_laptop_x86, is_raspberry, is_npu_dominant]
# perf: [memory_norm, bandwidth_norm, tflops_norm, tdp_norm,
#        cuda_cores_norm, arch_gen_norm, is_mobile_flag, is_npu_flag]

HARDWARE_CATALOG_V2: Dict[str, Dict] = {
    # ── Desktop GPUs ──────────────────────────────────────────────────────
    "rtx3080": {
        "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
        "performance": [10/32, 760/960, 29.8/83, 320/350, 8704/16384, 3/5, 0, 0],
    },
    "rtx4080": {
        "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
        "performance": [16/32, 717/960, 48.7/83, 320/350, 9728/16384, 4/5, 0, 0],
    },
    "rtx4060": {
        "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
        "performance": [8/32, 272/960, 15.1/83, 115/350, 3072/16384, 4/5, 0, 0],
    },
    "rtx3050": {
        "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
        "performance": [8/32, 224/960, 9.1/83, 130/350, 2560/16384, 3/5, 0, 0],
    },
    "rtx5090": {
        "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
        "performance": [32/32, 1792/960, 83.0/83, 575/350, 21760/16384, 5/5, 0, 0],
    },
    # ── Laptop ARM ────────────────────────────────────────────────────────
    "macbook_m1": {
        "categorical": [0, 0, 0, 0, 1, 0, 0, 0],
        "performance": [16/32, 200/960, 10.4/83, 30/350, 0/16384, 3/5, 0, 0],
    },
    # ── Laptop x86 CPU ────────────────────────────────────────────────────
    "acer_nitro": {
        "categorical": [0, 0, 0, 0, 0, 1, 0, 0],
        "performance": [16/32, 50/960, 2.0/83, 45/350, 0/16384, 3/5, 0, 0],
    },
    "asus_vivobook": {
        "categorical": [0, 0, 0, 0, 0, 1, 0, 0],
        "performance": [8/32, 38/960, 1.2/83, 28/350, 0/16384, 3/5, 0, 0],
    },
    # ── Edge SBC ──────────────────────────────────────────────────────────
    "raspi4": {
        "categorical": [0, 1, 0, 0, 0, 0, 1, 0],
        "performance": [4/32, 4/960, 0.1/83, 5/350, 0/16384, 1/5, 1, 0],
    },
    "raspi5": {
        "categorical": [0, 1, 0, 0, 0, 0, 1, 0],
        "performance": [8/32, 8/960, 0.2/83, 8/350, 0/16384, 2/5, 1, 0],
    },
    # ── Jetson ────────────────────────────────────────────────────────────
    "jetson_nano_2gb": {
        "categorical": [0, 1, 1, 0, 0, 0, 0, 0],
        "performance": [2/32, 25.6/960, 0.5/83, 10/350, 128/16384, 1/5, 1, 0],
    },
    "jetson_nano_4gb": {
        "categorical": [0, 1, 1, 0, 0, 0, 0, 0],
        "performance": [4/32, 25.6/960, 0.5/83, 10/350, 128/16384, 1/5, 1, 0],
    },
    "jetson_orin": {
        "categorical": [0, 1, 1, 0, 0, 0, 0, 1],
        "performance": [8/32, 68/960, 5.3/83, 15/350, 1024/16384, 3/5, 1, 1],
    },
}

# Alias map: tên cũ → tên mới
HW_ALIASES_V2: Dict[str, str] = {
    "RTX4080":      "rtx4080",
    "rtx4080_super": "rtx4080",
    "RTX4080_SUPER": "rtx4080",
    "RTX3080":      "rtx3080",
    "Macbook_M1":   "macbook_m1",
    "macbook_m1":   "macbook_m1",
    "Mac_M1":       "macbook_m1",
    "acer_nitro":   "acer_nitro",
    "asus_vivobook": "asus_vivobook",
    "raspi4":       "raspi4",
    "raspi5":       "raspi5",
    "jetson_nano_2gb": "jetson_nano_2gb",
    "jetson_nano_4gb": "jetson_nano_4gb",
    "jetson_orin":  "jetson_orin",
}

# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  3. HARDWARE ENCODING FUNCTION V2                                        ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def encode_hardware_v2(hardware_name: str) -> torch.Tensor:
    """
    Encode hardware thành vector 16D.

    Returns:
        FloatTensor shape (16,) = concat(categorical_8D, performance_8D)
    """
    canonical = HW_ALIASES_V2.get(hardware_name, hardware_name)
    if canonical not in HARDWARE_CATALOG_V2:
        # Fallback sang v1 nếu không có trong catalog v2
        from hytra_encoding import encode_hardware as _encode_v1
        v1 = _encode_v1(hardware_name)
        # Pad từ 5D lên 16D bằng zeros
        pad = torch.zeros(HW_ENCODING_DIM_V2 - 5)
        return torch.cat([v1, pad], dim=0)

    info = HARDWARE_CATALOG_V2[canonical]
    cat  = torch.tensor(info["categorical"], dtype=torch.float32)
    perf = torch.tensor(info["performance"], dtype=torch.float32)

    # Clamp performance về [0, 1]
    perf = torch.clamp(perf, 0.0, 1.0)

    return torch.cat([cat, perf], dim=0)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  4. DAG ENCODING V2 — FABRIC-LIKE TOPOLOGY                              ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def _op_to_depth(op_index: int) -> int:
    """Map op_index → depth level (0=deepest/smallest, 3=shallowest/largest)."""
    for depth, ops in S_RANK.items():
        if op_index in ops:
            return depth
    raise ValueError(f"Unknown op_index: {op_index}")


def _scale_to_depth(scale_ratio: float) -> int:
    """Map scale_ratio → depth level."""
    for tol in [1e-8]:
        for scale, depth in SCALE_TO_DEPTH.items():
            if abs(scale_ratio - scale) < 1e-6:
                return depth
    raise ValueError(f"Unknown scale_ratio: {scale_ratio}")


def encode_hytra_dag_v2(
    arch: List[Tuple[str, float]],
    validate: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Encode kiến trúc HyTra thành DAG với fabric-like topology.

    Cải tiến so với v1:
      - Same-depth skip connections trong mỗi stage
      - Explicit depth information trong node features
      - Bỏ global node (dùng attention trong GCN)
      - Node features 17D thay vì 14D

    Args:
        arch: 16 tuples (block_type, scale_ratio)
        validate: kiểm tra tính hợp lệ

    Returns:
        X: np.ndarray (18, 17) — node features
        A: np.ndarray (18, 18) — adjacency matrix
    """
    if validate:
        is_valid, errors = validate_hytra_architecture(arch)
        if not is_valid:
            raise ValueError("Invalid HyTra architecture:\n" +
                             "\n".join(f"  • {e}" for e in errors))

    N = NUM_GRAPH_NODES_V2  # 18
    X = np.zeros((N, NODE_FEATURE_DIM_V2), dtype=np.float32)
    A = np.zeros((N, N), dtype=np.float32)

    # ── Node features ────────────────────────────────────────────────────

    # Input node (node 0) — đặc biệt
    # Không phải ResConv hay ResAtt → để zeros cho block_type
    # Scale = 1.0 (full resolution) → không có trong VALID_BLOCK_SCALES
    # depth=-1 (virtual), stage=-1 (virtual)
    X[INPUT_NODE_IDX_V2, :] = 0.0  # all zeros cho input node

    # 16 choice blocks (nodes 1-16)
    for i, (block_type, scale_ratio) in enumerate(arch):
        node_idx   = BLOCK_START_IDX_V2 + i
        stage_idx  = i // LAYERS_PER_STAGE
        pos_in_stg = i % LAYERS_PER_STAGE
        depth      = _scale_to_depth(scale_ratio)

        offset = 0

        # [0-1] block_type one-hot
        if block_type == "ResConv":
            X[node_idx, 0] = 1.0
        else:  # ResAtt
            X[node_idx, 1] = 1.0
        offset += 2

        # [2] scale_ratio numerical
        X[node_idx, offset] = scale_ratio
        offset += 1

        # [3-6] scale one-hot (4 scales: 1/4, 1/8, 1/16, 1/32)
        scale_idx = VALID_BLOCK_SCALES.index(scale_ratio) \
            if scale_ratio in VALID_BLOCK_SCALES else -1
        if scale_idx >= 0:
            X[node_idx, offset + scale_idx] = 1.0
        offset += 4

        # [7-10] depth one-hot (0,1,2,3)
        X[node_idx, offset + depth] = 1.0
        offset += 4

        # [11-14] stage one-hot (0,1,2,3)
        X[node_idx, offset + stage_idx] = 1.0
        offset += 4

        # [15] position in stage normalized
        X[node_idx, offset] = pos_in_stg / (LAYERS_PER_STAGE - 1)
        offset += 1

        # [16] ResAtt eligibility
        X[node_idx, offset] = 1.0 if scale_ratio in RESATT_ALLOWED_SCALES else 0.0

    # Output node (node 17) — đặc biệt
    X[OUTPUT_NODE_IDX_V2, :] = 0.0

    # ── Adjacency matrix ─────────────────────────────────────────────────

    # Self-loops trên tất cả nodes
    np.fill_diagonal(A, 1.0)

    # Input → first block
    A[INPUT_NODE_IDX_V2, BLOCK_START_IDX_V2] = 1.0

    # Last block → Output
    A[BLOCK_END_IDX_V2, OUTPUT_NODE_IDX_V2] = 1.0

    for stage_idx in range(NUM_STAGES):
        base = stage_idx * LAYERS_PER_STAGE  # local index 0-3 trong stage
        nodes = [BLOCK_START_IDX_V2 + base + j for j in range(LAYERS_PER_STAGE)]
        depths = [_scale_to_depth(arch[base + j][1]) for j in range(LAYERS_PER_STAGE)]

        for j in range(LAYERS_PER_STAGE):
            ni = nodes[j]
            di = depths[j]

            # Sequential edge: block_j → block_{j+1}
            if j < LAYERS_PER_STAGE - 1:
                nj = nodes[j + 1]
                A[ni, nj] = 1.0

            # Same-depth skip connections: block_j → block_k nếu dk == di, k > j
            for k in range(j + 1, LAYERS_PER_STAGE):
                if depths[k] == di:
                    A[ni, nodes[k]] = 1.0

        # Cross-stage: last block stage s → first block stage s+1
        if stage_idx < NUM_STAGES - 1:
            last_node  = nodes[LAYERS_PER_STAGE - 1]
            first_next = BLOCK_START_IDX_V2 + (stage_idx + 1) * LAYERS_PER_STAGE
            A[last_node, first_next] = 1.0

    return X, A


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  5. DATASET V2                                                           ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def _parse_arch_string(arch_string: str) -> List[Tuple[str, float]]:
    """Parse arch string → list of tuples."""
    parts = arch_string.split("|")
    result = []
    for p in parts:
        bt, sr = p.split("@")
        result.append((bt, float(sr)))
    return result


class HyTraMHLPDatasetV2(Dataset):
    """
    Dataset v2 với fabric-like DAG encoding và 16D hardware encoding.

    Mỗi sample:
      X:       (18, 17) node features
      A:       (18, 18) adjacency matrix
      hw:      (16,) hardware vector
      latency: (1,) target
    """

    def __init__(
        self,
        data: List[Dict],
        normalize_latency: bool = True,
        log_transform: bool = False,
    ):
        self.log_transform = log_transform
        self.normalize_latency = normalize_latency
        self.hw_names: List[str] = []

        X_list, A_list, hw_list, lat_list = [], [], [], []

        for item in data:
            arch_raw = item["arch"]
            # Support cả string và list format
            if isinstance(arch_raw, str):
                arch = _parse_arch_string(arch_raw)
            elif isinstance(arch_raw[0], (list, tuple)) and isinstance(arch_raw[0][0], int):
                arch = bossnas_to_tuples(arch_raw)
            else:
                arch = arch_raw

            X, A = encode_hytra_dag_v2(arch)
            hw   = encode_hardware_v2(item["hardware"])
            lat  = float(item["latency"])

            if log_transform:
                lat = np.log1p(lat)

            X_list.append(torch.tensor(X, dtype=torch.float32))
            A_list.append(torch.tensor(A, dtype=torch.float32))
            hw_list.append(hw)
            lat_list.append(torch.tensor([lat], dtype=torch.float32))
            self.hw_names.append(item["hardware"])

        self.X_tensors   = X_list
        self.A_tensors   = A_list
        self.hw_tensors  = hw_list
        self.lat_tensors = lat_list

        # Z-score normalization
        all_lats = torch.cat(self.lat_tensors)
        self.latency_mean = all_lats.mean().item()
        self.latency_std  = all_lats.std().item()

        if normalize_latency and self.latency_std > 1e-8:
            self.lat_tensors = [
                (lat - self.latency_mean) / self.latency_std
                for lat in self.lat_tensors
            ]
            print(f"[V2] Latency z-score: mean={self.latency_mean:.4f}, "
                  f"std={self.latency_std:.4f}")

        print(f"[V2] Dataset: {len(self)} samples, "
              f"X={self.X_tensors[0].shape}, A={self.A_tensors[0].shape}, "
              f"hw={self.hw_tensors[0].shape}")

    def __len__(self) -> int:
        return len(self.X_tensors)

    def __getitem__(self, idx: int):
        return (
            self.X_tensors[idx],
            self.A_tensors[idx],
            self.hw_tensors[idx],
            self.lat_tensors[idx],
        )

    def denormalize(self, normalized: torch.Tensor) -> torch.Tensor:
        if self.normalize_latency and self.latency_std > 1e-8:
            out = normalized * self.latency_std + self.latency_mean
        else:
            out = normalized
        if self.log_transform:
            out = torch.expm1(out)
        return out


def _scale_to_depth_cifar(scale_ratio: float) -> int:
    for scale, depth in SCALE_TO_DEPTH_CIFAR.items():
        if abs(scale_ratio - scale) < 1e-6:
            return depth
    raise ValueError(f"Unknown HyTra-CIFAR scale_ratio: {scale_ratio}")


def _validate_hytra_cifar_architecture(arch: List[Tuple[str, float]]) -> None:
    if len(arch) != sum(STAGE_DEPTHS_CIFAR):
        raise ValueError(f"HyTra-CIFAR architecture must have 8 blocks, got {len(arch)}")

    cursor = 0
    for stage_idx, stage_depth in enumerate(STAGE_DEPTHS_CIFAR):
        stage = arch[cursor:cursor + stage_depth]
        depths = [_scale_to_depth_cifar(scale) for _bt, scale in stage]
        if any(depths[i] > depths[i + 1] for i in range(len(depths) - 1)):
            raise ValueError(f"Stage {stage_idx} violates monotone non-increasing scale constraint")
        for block_type, scale in stage:
            if block_type not in {"ResConv", "ResAtt"}:
                raise ValueError(f"Unknown block_type: {block_type}")
            if block_type == "ResAtt" and scale not in RESATT_ALLOWED_SCALES_CIFAR:
                raise ValueError(f"ResAtt is only allowed at 8x8/4x4, got scale={scale}")
        cursor += stage_depth


def encode_hytra_cifar_dag(
    arch: List[Tuple[str, float]],
    validate: bool = True,
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Encode HyTra-CIFAR as Input(0) + 8 blocks(1-8) + Output(9).

    Node features use the same 17D layout as ``encode_hytra_dag_v2``.
    """
    arch, width_mult = normalize_hytra_cifar_arch(arch)
    if validate:
        _validate_hytra_cifar_architecture(arch)

    N = NUM_GRAPH_NODES_CIFAR
    X = np.zeros((N, NODE_FEATURE_DIM_CIFAR), dtype=np.float32)
    A = np.zeros((N, N), dtype=np.float32)
    X[:, NODE_FEATURE_DIM_V2] = width_mult

    cursor = 0
    for stage_idx, stage_depth in enumerate(STAGE_DEPTHS_CIFAR):
        for pos_in_stage in range(stage_depth):
            block_type, scale_ratio = arch[cursor]
            node_idx = BLOCK_START_IDX_CIFAR + cursor
            depth = _scale_to_depth_cifar(scale_ratio)
            offset = 0

            if block_type == "ResConv":
                X[node_idx, 0] = 1.0
            else:
                X[node_idx, 1] = 1.0
            offset += 2

            X[node_idx, offset] = scale_ratio
            offset += 1

            scale_idx = VALID_BLOCK_SCALES_CIFAR.index(scale_ratio)
            X[node_idx, offset + scale_idx] = 1.0
            offset += 4

            X[node_idx, offset + depth] = 1.0
            offset += 4

            X[node_idx, offset + stage_idx] = 1.0
            offset += 4

            denom = max(stage_depth - 1, 1)
            X[node_idx, offset] = pos_in_stage / denom
            offset += 1

            X[node_idx, offset] = 1.0 if scale_ratio in RESATT_ALLOWED_SCALES_CIFAR else 0.0
            cursor += 1

    np.fill_diagonal(A, 1.0)
    A[INPUT_NODE_IDX_CIFAR, BLOCK_START_IDX_CIFAR] = 1.0
    A[BLOCK_END_IDX_CIFAR, OUTPUT_NODE_IDX_CIFAR] = 1.0

    cursor = 0
    for stage_idx, stage_depth in enumerate(STAGE_DEPTHS_CIFAR):
        nodes = [BLOCK_START_IDX_CIFAR + cursor + j for j in range(stage_depth)]
        depths = [_scale_to_depth_cifar(arch[cursor + j][1]) for j in range(stage_depth)]
        for j, node in enumerate(nodes):
            if j < stage_depth - 1:
                A[node, nodes[j + 1]] = 1.0
            for k in range(j + 1, stage_depth):
                if depths[k] == depths[j]:
                    A[node, nodes[k]] = 1.0
        if stage_idx < len(STAGE_DEPTHS_CIFAR) - 1:
            A[nodes[-1], BLOCK_START_IDX_CIFAR + cursor + stage_depth] = 1.0
        cursor += stage_depth

    return X, A


class HyTraCIFARDataset(Dataset):
    """Dataset wrapper for HyTra-CIFAR MHLP records."""

    def __init__(
        self,
        data: List[Dict],
        normalize_latency: bool = True,
        log_transform: bool = False,
    ):
        self.log_transform = log_transform
        self.normalize_latency = normalize_latency
        self.hw_names: List[str] = []
        self.X_tensors: List[torch.Tensor] = []
        self.A_tensors: List[torch.Tensor] = []
        self.hw_tensors: List[torch.Tensor] = []
        self.lat_tensors: List[torch.Tensor] = []

        for item in data:
            arch_raw = (
                item.get("arch")
                or item.get("architecture")
                or item.get("architecture_string")
                or item.get("arch_string")
            )
            if isinstance(arch_raw, str):
                arch = parse_hytra_cifar_arch_string(arch_raw)
            elif isinstance(arch_raw, dict):
                arch = arch_raw
            else:
                arch = {
                    "blocks": [(bt, float(scale)) for bt, scale in arch_raw],
                    "width_mult": float(item.get("width_mult", 1.0)),
                }

            hardware = item.get("hardware") or item.get("hardware_type")
            latency = item.get("latency")
            if latency is None:
                latency = item.get("latency_ms")
            if hardware is None or latency is None:
                raise ValueError("Each item must provide hardware/hardware_type and latency/latency_ms")

            X, A = encode_hytra_cifar_dag(arch)
            hw = encode_hardware_v2(hardware)
            lat = float(latency)
            if log_transform:
                lat = np.log1p(lat)

            self.X_tensors.append(torch.tensor(X, dtype=torch.float32))
            self.A_tensors.append(torch.tensor(A, dtype=torch.float32))
            self.hw_tensors.append(hw)
            self.lat_tensors.append(torch.tensor([lat], dtype=torch.float32))
            self.hw_names.append(hardware)

        all_lats = torch.cat(self.lat_tensors)
        self.latency_mean = all_lats.mean().item()
        self.latency_std = all_lats.std(unbiased=False).item()
        if normalize_latency and self.latency_std > 1e-8:
            self.lat_tensors = [
                (lat - self.latency_mean) / self.latency_std
                for lat in self.lat_tensors
            ]

    def __len__(self) -> int:
        return len(self.X_tensors)

    def __getitem__(self, idx: int):
        return (
            self.X_tensors[idx],
            self.A_tensors[idx],
            self.hw_tensors[idx],
            self.lat_tensors[idx],
        )

    def denormalize(self, normalized: torch.Tensor) -> torch.Tensor:
        if self.normalize_latency and self.latency_std > 1e-8:
            out = normalized * self.latency_std + self.latency_mean
        else:
            out = normalized
        if self.log_transform:
            out = torch.expm1(out)
        return out


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  6. VERIFY & DEMO                                                        ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def verify_encoding_v2():
    """Verify DAG encoding v2 với một số arch mẫu."""
    print("=" * 60)
    print("  VERIFY HyTra DAG Encoding V2")
    print("=" * 60)

    # Test 1: Pure conv arch
    arch_pure_conv = _parse_arch_string(
        "ResConv@0.25|ResConv@0.125|ResConv@0.0625|ResConv@0.0625|"
        "ResConv@0.125|ResConv@0.0625|ResConv@0.0625|ResConv@0.03125|"
        "ResConv@0.0625|ResConv@0.03125|ResConv@0.03125|ResConv@0.03125|"
        "ResConv@0.0625|ResConv@0.03125|ResConv@0.03125|ResConv@0.03125"
    )
    X, A = encode_hytra_dag_v2(arch_pure_conv)
    print(f"\n  Pure conv arch:")
    print(f"    X shape: {X.shape} (expected: (18, 17))")
    print(f"    A shape: {A.shape} (expected: (18, 18))")
    assert X.shape == (18, 17), f"Wrong X shape: {X.shape}"
    assert A.shape == (18, 18), f"Wrong A shape: {A.shape}"

    # Test 2: Mixed arch với ResAtt
    arch_mixed = _parse_arch_string(
        "ResConv@0.25|ResAtt@0.0625|ResAtt@0.03125|ResConv@0.03125|"
        "ResConv@0.125|ResAtt@0.0625|ResConv@0.0625|ResConv@0.03125|"
        "ResAtt@0.0625|ResConv@0.03125|ResConv@0.03125|ResConv@0.03125|"
        "ResConv@0.0625|ResConv@0.03125|ResAtt@0.03125|ResAtt@0.03125"
    )
    X2, A2 = encode_hytra_dag_v2(arch_mixed)
    print(f"\n  Mixed arch (with ResAtt):")
    print(f"    X shape: {X2.shape}")
    print(f"    A shape: {A2.shape}")

    # Test 3: Verify skip connections
    # Arch có [ResConv@1/8, ResConv@1/8, ResConv@1/16, ResConv@1/32] trong stage 0
    # → blocks 1 và 2 cùng depth 2 → phải có skip edge 1→2
    arch_skip = _parse_arch_string(
        "ResConv@0.125|ResConv@0.125|ResConv@0.0625|ResConv@0.03125|"
        "ResConv@0.0625|ResConv@0.0625|ResConv@0.03125|ResConv@0.03125|"
        "ResConv@0.0625|ResConv@0.03125|ResConv@0.03125|ResConv@0.03125|"
        "ResConv@0.0625|ResConv@0.03125|ResConv@0.03125|ResConv@0.03125"
    )
    X3, A3 = encode_hytra_dag_v2(arch_skip)
    # Block 1 = node 1, Block 2 = node 2 trong stage 0
    # Cả 2 cùng scale 1/8 = depth 2 → phải có edge A3[1, 2] = 1
    node1 = BLOCK_START_IDX_V2 + 0  # block 0 trong stage 0
    node2 = BLOCK_START_IDX_V2 + 1  # block 1 trong stage 0
    has_skip = A3[node1, node2] == 1.0
    print(f"\n  Same-depth skip connection test:")
    print(f"    Block 0 (scale=1/8) → Block 1 (scale=1/8): "
          f"{'✅ PASS' if has_skip else '❌ FAIL'}")

    # Test 4: Hardware encoding
    print(f"\n  Hardware encoding v2 (16D):")
    for hw in ["rtx3080", "rtx4080", "macbook_m1", "raspi4", "jetson_nano_2gb"]:
        vec = encode_hardware_v2(hw)
        print(f"    {hw:20s}: shape={vec.shape}, "
              f"cat={vec[:8].tolist()}, "
              f"perf=[{', '.join(f'{x:.3f}' for x in vec[8:].tolist())}]")
        assert vec.shape == (16,)
        assert (vec >= 0).all() and (vec <= 1 + 1e-6).all(), \
            f"Performance values out of [0,1] for {hw}"

    # Test 5: Verify node feature dimensions
    print(f"\n  Node feature verification:")
    print(f"    NODE_FEATURE_DIM_V2 = {NODE_FEATURE_DIM_V2} (expected: 17)")
    print(f"    HW_ENCODING_DIM_V2  = {HW_ENCODING_DIM_V2} (expected: 16)")
    print(f"    NUM_GRAPH_NODES_V2  = {NUM_GRAPH_NODES_V2} (expected: 18)")

    # Test 6: Edge count so sánh v1 vs v2
    from hytra_encoding import encode_hytra_dag as encode_v1
    X_v1, A_v1 = encode_v1(arch_mixed)
    edges_v1 = int(A_v1.sum()) - int(np.trace(A_v1))
    edges_v2 = int(A2.sum()) - int(np.trace(A2))
    print(f"\n  Edge count comparison (mixed arch):")
    print(f"    V1 (sequential only): {edges_v1} edges, {X_v1.shape[0]} nodes")
    print(f"    V2 (fabric-like):     {edges_v2} edges, {X2.shape[0]} nodes")
    print(f"    V2 has more edges: {'✅' if edges_v2 > edges_v1 else '⚠️ same or fewer'}")

    print(f"\n{'='*60}")
    print("  ALL TESTS PASSED ✅")
    print(f"{'='*60}")


if __name__ == "__main__":
    verify_encoding_v2()
