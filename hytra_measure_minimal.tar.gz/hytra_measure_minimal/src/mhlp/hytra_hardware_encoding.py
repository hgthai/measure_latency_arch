# hytra_hardware_encoding.py
"""
Hardware Encoding Module cho MHLP — Phiên bản cải tiến
=======================================================

Đóng góp mới so với paper MHLP gốc (5D one-hot):
  - Paper gốc: 5D binary vector → không phân biệt được RTX4060 vs RTX5060
  - Phiên bản này: Categorical (8D) + Performance (8D) = 16D input
    → Phân biệt được các GPU cùng thế hệ
    → Generalize sang unseen device dựa trên performance features
    → Không cần retrain khi có device mới

Architecture:
  categorical_vec (8D) ──► Linear(8→32) ──► ReLU ──┐
                                                     ├──► Concat(64D) ──► LayerNorm ──► output
  perf_vec (8D)        ──► MLP(8→32→32) ─────────────┘

Categorical dimensions (8D):
  [is_mobile_soc, is_edge_device, is_desktop_gpu, is_desktop_gpu_integrated,
   is_laptop_arm, is_laptop_x86, is_raspberry, is_mobile_npu]

Performance dimensions (8D — normalized):
  [memory_norm, bandwidth_norm, tflops_norm, tdp_norm,
   cuda_cores_norm, arch_gen_norm, is_mobile_flag, is_npu_flag]

Author: KLTN — Hardware-aware NAS với MHLP
"""

from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from typing import Dict, List, Tuple, Optional


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  1. CONSTANTS                                                            ║
# ╚══════════════════════════════════════════════════════════════════════════╝

CATEGORICAL_DIM: int = 8
PERFORMANCE_DIM: int = 8
HW_INPUT_DIM:   int = CATEGORICAL_DIM + PERFORMANCE_DIM  # 16

# Tên các chiều để dễ debug
CATEGORICAL_NAMES: List[str] = [
    "is_mobile_soc",         # 0: SoC di động (iPhone, Android flagship)
    "is_edge_device",        # 1: Edge device (Raspberry Pi, Jetson Nano)
    "is_desktop_gpu",        # 2: Desktop/Server GPU rời (RTX series)
    "is_integrated_gpu",     # 3: GPU tích hợp (Intel UHD, AMD Radeon iGPU)
    "is_laptop_arm",         # 4: Laptop ARM SoC (MacBook M1/M2/M3)
    "is_laptop_x86",         # 5: Laptop x86 CPU (Intel/AMD Windows laptop)
    "is_raspberry",          # 6: Raspberry Pi / ARM SBC
    "is_npu_dominant",       # 7: Thiết bị có NPU/ANE là primary compute
]

PERFORMANCE_NAMES: List[str] = [
    "memory_norm",           # 0: VRAM/RAM (GB), normalized by 32GB
    "bandwidth_norm",        # 1: Memory bandwidth (GB/s), normalized by 960
    "tflops_norm",           # 2: FP32 TFLOPS, normalized by 83 (H100)
    "tdp_norm",              # 3: TDP (Watt), normalized by 350W
    "cuda_cores_norm",       # 4: CUDA cores / shader units, normalized by 16384
    "arch_gen_norm",         # 5: Architecture generation (1=old → 5=newest)
    "is_mobile_flag",        # 6: Binary mobile flag (redundant nhưng giúp MLP)
    "is_npu_flag",           # 7: Binary NPU flag
]


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  2. DEVICE CATALOG                                                       ║
# ╚══════════════════════════════════════════════════════════════════════════╝

# Normalization constants (dùng để tính performance vector)
_NORM = {
    "memory":     32.0,    # GB
    "bandwidth":  960.0,   # GB/s (A100 SXM ~2TB/s → dùng 960 cho consumer range)
    "tflops":     83.0,    # TFLOPS FP32 (H100)
    "tdp":        350.0,   # Watt
    "cuda_cores": 16384.0, # RTX 4090
    "arch_gen":   5.0,     # 1=Pascal/Ampere-old, 5=Blackwell/newest
}

DEVICE_CATALOG: Dict[str, Dict] = {

    # ── Desktop/Server GPUs ────────────────────────────────────────────────
    "rtx4060": {
        "description": "NVIDIA RTX 4060 — Ada Lovelace, 8GB GDDR6",
        "meta_train":  True,   # dùng trong meta-training pool
        "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
        "performance": [
            8   / _NORM["memory"],       # 8 GB GDDR6
            272 / _NORM["bandwidth"],    # 272 GB/s
            15.1/ _NORM["tflops"],       # 15.1 TFLOPS FP32
            115 / _NORM["tdp"],          # 115W TDP
            3072/ _NORM["cuda_cores"],   # 3072 CUDA cores
            4   / _NORM["arch_gen"],     # Ada Lovelace = gen 4
            0.0,                         # không phải mobile
            0.0,                         # không có NPU
        ],
    },
    "rtx3050": {
        "description": "NVIDIA RTX 3050 — Ampere, 8GB GDDR6",
        "meta_train":  True,
        "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
        "performance": [
            8   / _NORM["memory"],
            224 / _NORM["bandwidth"],
            9.1 / _NORM["tflops"],
            130 / _NORM["tdp"],
            2560/ _NORM["cuda_cores"],
            3   / _NORM["arch_gen"],     # Ampere = gen 3
            0.0,
            0.0,
        ],
    },
    "rtx5060": {
        "description": "NVIDIA RTX 5060 — Blackwell, 8GB GDDR7 (UNSEEN)",
        "meta_train":  False,  # unseen device — dùng để test
        "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
        "performance": [
            8   / _NORM["memory"],
            304 / _NORM["bandwidth"],    # GDDR7 bandwidth cao hơn
            22.0/ _NORM["tflops"],
            150 / _NORM["tdp"],
            3840/ _NORM["cuda_cores"],
            5   / _NORM["arch_gen"],     # Blackwell = gen 5 (newest)
            0.0,
            0.0,
        ],
    },

    # ── Laptop ARM ─────────────────────────────────────────────────────────
    "macbook_m1": {
        "description": "MacBook Pro M1 — Apple Silicon, 16GB unified memory",
        "meta_train":  True,
        "categorical": [0, 0, 0, 0, 1, 0, 0, 0],
        "performance": [
            16  / _NORM["memory"],
            200 / _NORM["bandwidth"],    # Unified memory bandwidth
            10.4/ _NORM["tflops"],       # GPU + Neural Engine combined
            30  / _NORM["tdp"],          # Very efficient
            0   / _NORM["cuda_cores"],   # Không có CUDA cores
            3   / _NORM["arch_gen"],     # M1 = gen 3 Apple Silicon
            0.0,
            0.0,
        ],
    },

    # ── Laptop x86 CPU ─────────────────────────────────────────────────────
    "windows_cpu": {
        "description": "Windows Laptop CPU — Intel/AMD x86, ~16GB RAM",
        "meta_train":  True,
        "categorical": [0, 0, 0, 0, 0, 1, 0, 0],
        "performance": [
            16  / _NORM["memory"],
            50  / _NORM["bandwidth"],    # DDR4/5 bandwidth
            2.0 / _NORM["tflops"],       # CPU FP32 estimate
            45  / _NORM["tdp"],
            0   / _NORM["cuda_cores"],
            3   / _NORM["arch_gen"],
            0.0,
            0.0,
        ],
    },

    # ── Edge Device ────────────────────────────────────────────────────────
    "raspi4": {
        "description": "Raspberry Pi 4B — ARM Cortex-A72, 4GB LPDDR4 (UNSEEN)",
        "meta_train":  False,  # unseen device
        "categorical": [0, 1, 0, 0, 0, 0, 1, 0],
        "performance": [
            4   / _NORM["memory"],
            4   / _NORM["bandwidth"],    # LPDDR4 ~4 GB/s
            0.1 / _NORM["tflops"],       # 4-core ARM Cortex-A72
            5   / _NORM["tdp"],          # Very low power
            0   / _NORM["cuda_cores"],
            1   / _NORM["arch_gen"],     # Older ARM gen
            1.0,                         # is_mobile_flag = 1 (low power)
            0.0,
        ],
    },

    # ── Mobile SoC (nếu đo được iPhone) ───────────────────────────────────
    "iphone15": {
        "description": "iPhone 15 — Apple A16 Bionic, ANE 16-core (UNSEEN)",
        "meta_train":  False,
        "categorical": [1, 0, 0, 0, 0, 0, 0, 1],
        "performance": [
            6   / _NORM["memory"],
            60  / _NORM["bandwidth"],
            2.15/ _NORM["tflops"],
            20  / _NORM["tdp"],
            0   / _NORM["cuda_cores"],
            4   / _NORM["arch_gen"],     # A16 = gen 4 Apple mobile
            1.0,
            1.0,                         # has NPU (Apple Neural Engine)
        ],
    },
}

# Meta-training / meta-testing split
META_TRAIN_DEVICES: List[str] = [
    name for name, info in DEVICE_CATALOG.items() if info["meta_train"]
]
META_TEST_DEVICES: List[str] = [
    name for name, info in DEVICE_CATALOG.items() if not info["meta_train"]
]


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  3. ENCODING FUNCTIONS                                                   ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def get_device_vectors(
    device_name: str,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Trả về (categorical_vec, perf_vec) cho một device.

    Args:
        device_name: Key trong DEVICE_CATALOG

    Returns:
        categorical_vec: FloatTensor shape (8,)
        perf_vec:        FloatTensor shape (8,)

    Raises:
        KeyError: Nếu device_name không có trong catalog
    """
    if device_name not in DEVICE_CATALOG:
        available = list(DEVICE_CATALOG.keys())
        raise KeyError(
            f"Device '{device_name}' không có trong catalog.\n"
            f"Available: {available}"
        )

    info = DEVICE_CATALOG[device_name]

    categorical_vec = torch.tensor(
        info["categorical"], dtype=torch.float32
    )
    perf_vec = torch.tensor(
        info["performance"], dtype=torch.float32
    )

    # Validate ranges
    assert categorical_vec.shape == (CATEGORICAL_DIM,), \
        f"{device_name}: categorical shape sai"
    assert perf_vec.shape == (PERFORMANCE_DIM,), \
        f"{device_name}: performance shape sai"
    assert (perf_vec >= 0).all() and (perf_vec <= 1).all(), \
        f"{device_name}: performance values phải trong [0, 1]"

    return categorical_vec, perf_vec


def get_combined_hw_vector(device_name: str) -> torch.Tensor:
    """
    Trả về vector kết hợp 16D cho một device.
    Dùng khi không cần HybridHardwareEncoder (ví dụ: baseline comparison).

    Returns:
        FloatTensor shape (16,) = concat(categorical_8D, perf_8D)
    """
    cat, perf = get_device_vectors(device_name)
    return torch.cat([cat, perf], dim=0)


def get_legacy_5d_vector(device_name: str) -> torch.Tensor:
    """
    Backward compatibility: trả về 5D vector như paper MHLP gốc.
    Dùng để so sánh ablation với paper gốc.

    5D: [is_desktop_cloud, is_mobile, has_cpu, has_gpu, has_asic_npu]
    """
    # Map từ catalog mới về 5D cũ
    LEGACY_MAP = {
        "rtx4060":    [1, 0, 0, 1, 0],
        "rtx3050":    [1, 0, 0, 1, 0],
        "rtx5060":    [1, 0, 0, 1, 0],
        "macbook_m1": [1, 0, 1, 1, 0],
        "windows_cpu":[1, 0, 1, 0, 0],
        "raspi4":     [0, 1, 1, 0, 0],
        "iphone15":   [0, 1, 1, 1, 1],
    }
    if device_name not in LEGACY_MAP:
        raise KeyError(f"Device '{device_name}' không có legacy mapping")
    return torch.tensor(LEGACY_MAP[device_name], dtype=torch.float32)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  4. HYBRID HARDWARE ENCODER MODULE                                       ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class HybridHardwareEncoder(nn.Module):
    """
    Kết hợp categorical one-hot + continuous performance features.

    Đóng góp mới so với paper MHLP gốc (5D one-hot):
      - Phân biệt được các GPU cùng thế hệ (RTX4060 vs RTX5060)
      - Generalize sang unseen device dựa trên performance features
      - Không cần retrain khi có device mới — chỉ thêm entry vào catalog

    Architecture:
      categorical_vec (8D) ──► Linear(8→embed_dim//2) ──► ReLU ──┐
                                                                   ├──► Cat ──► LayerNorm ──► out(embed_dim)
      perf_vec (8D)        ──► Linear(8→32) ──► ReLU ──────────────┘
                                ──► Linear(32→embed_dim//2) ──►
    """

    def __init__(
        self,
        categorical_dim: int = CATEGORICAL_DIM,   # 8
        perf_dim:        int = PERFORMANCE_DIM,   # 8
        embed_dim:       int = 64,                # output dim
        dropout:         float = 0.1,
    ):
        super().__init__()

        half = embed_dim // 2

        # Branch 1: Categorical features
        self.categorical_branch = nn.Sequential(
            nn.Linear(categorical_dim, half),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
        )

        # Branch 2: Performance features (deeper — cần học scale)
        self.performance_branch = nn.Sequential(
            nn.Linear(perf_dim, half * 2),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(half * 2, half),
            nn.ReLU(inplace=True),
        )

        # Fusion normalization
        self.output_norm = nn.LayerNorm(embed_dim)

        self.embed_dim = embed_dim

    def forward(
        self,
        categorical_vec: torch.Tensor,
        perf_vec: torch.Tensor,
    ) -> torch.Tensor:
        """
        Args:
            categorical_vec: FloatTensor (..., 8)
            perf_vec:        FloatTensor (..., 8)

        Returns:
            FloatTensor (..., embed_dim)
        """
        cat_emb  = self.categorical_branch(categorical_vec)   # (..., 32)
        perf_emb = self.performance_branch(perf_vec)          # (..., 32)
        combined = torch.cat([cat_emb, perf_emb], dim=-1)     # (..., 64)
        return self.output_norm(combined)                      # (..., 64)

    def encode_device(self, device_name: str) -> torch.Tensor:
        """
        Convenience method: encode trực tiếp từ tên device.

        Args:
            device_name: Key trong DEVICE_CATALOG

        Returns:
            FloatTensor (embed_dim,)
        """
        cat_vec, perf_vec = get_device_vectors(device_name)
        # Add batch dim
        cat_vec  = cat_vec.unsqueeze(0)
        perf_vec = perf_vec.unsqueeze(0)
        with torch.no_grad():
            emb = self.forward(cat_vec, perf_vec)
        return emb.squeeze(0)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  5. BATCH UTILITIES                                                      ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def batch_encode_devices(
    device_names: List[str],
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Encode một batch các devices thành 2 tensors.

    Args:
        device_names: List tên devices, length N

    Returns:
        categorical_batch: FloatTensor (N, 8)
        perf_batch:        FloatTensor (N, 8)
    """
    cats, perfs = [], []
    for name in device_names:
        c, p = get_device_vectors(name)
        cats.append(c)
        perfs.append(p)
    return torch.stack(cats), torch.stack(perfs)


def get_meta_train_tensors() -> Tuple[torch.Tensor, torch.Tensor]:
    """Trả về tensors cho toàn bộ meta-training devices."""
    return batch_encode_devices(META_TRAIN_DEVICES)


def get_meta_test_tensors() -> Tuple[torch.Tensor, torch.Tensor]:
    """Trả về tensors cho toàn bộ meta-testing devices."""
    return batch_encode_devices(META_TEST_DEVICES)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  6. ABLATION: SO SÁNH 5D VS 16D                                         ║
# ╚══════════════════════════════════════════════════════════════════════════╝

class LegacyHardwareEncoder(nn.Module):
    """
    Baseline encoder dùng 5D one-hot như paper MHLP gốc.
    Dùng cho ablation study: 5D vs 16D hybrid.
    """

    def __init__(self, hw_dim: int = 5, embed_dim: int = 64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(hw_dim, embed_dim),
            nn.ReLU(inplace=True),
            nn.Linear(embed_dim, embed_dim),
        )
        self.embed_dim = embed_dim

    def forward(self, hw_vec: torch.Tensor) -> torch.Tensor:
        return self.net(hw_vec)

    def encode_device(self, device_name: str) -> torch.Tensor:
        vec = get_legacy_5d_vector(device_name).unsqueeze(0)
        with torch.no_grad():
            return self.forward(vec).squeeze(0)


# ╔══════════════════════════════════════════════════════════════════════════╗
# ║  7. VERIFY & DEMO                                                        ║
# ╚══════════════════════════════════════════════════════════════════════════╝

def verify_catalog() -> bool:
    """Kiểm tra tất cả entries trong catalog đều hợp lệ."""
    print("=" * 60)
    print("  VERIFY HARDWARE CATALOG")
    print("=" * 60)

    all_ok = True
    for name, info in DEVICE_CATALOG.items():
        try:
            cat, perf = get_device_vectors(name)
            combined = get_combined_hw_vector(name)
            legacy = get_legacy_5d_vector(name)

            status = "✅"
            detail = (
                f"cat={cat.tolist()} | "
                f"perf=[{', '.join(f'{x:.3f}' for x in perf.tolist())}]"
            )
        except Exception as e:
            status = "❌"
            detail = str(e)
            all_ok = False

        train_tag = "TRAIN" if info["meta_train"] else "TEST "
        print(f"  {status} [{train_tag}] {name:15s}: {detail}")

    print(f"\n  Meta-train devices: {META_TRAIN_DEVICES}")
    print(f"  Meta-test  devices: {META_TEST_DEVICES}")

    return all_ok


def demo_encoder():
    """Demo HybridHardwareEncoder."""
    print("\n" + "=" * 60)
    print("  DEMO: HybridHardwareEncoder")
    print("=" * 60)

    encoder = HybridHardwareEncoder(embed_dim=64)
    encoder.eval()

    print(f"\n  Encoder parameters: "
          f"{sum(p.numel() for p in encoder.parameters()):,}")

    # Encode từng device và tính pairwise cosine similarity
    device_names = list(DEVICE_CATALOG.keys())
    embeddings = {}

    for name in device_names:
        emb = encoder.encode_device(name)
        embeddings[name] = emb
        print(f"  {name:15s}: emb shape={emb.shape}, "
              f"norm={emb.norm().item():.3f}")

    # Cosine similarity matrix
    print(f"\n  Cosine Similarity Matrix:")
    print(f"  {'':15s}", end="")
    for n in device_names:
        print(f"  {n[:8]:>8s}", end="")
    print()

    for n1 in device_names:
        print(f"  {n1:15s}", end="")
        for n2 in device_names:
            sim = F.cosine_similarity(
                embeddings[n1].unsqueeze(0),
                embeddings[n2].unsqueeze(0)
            ).item()
            print(f"  {sim:8.3f}", end="")
        print()

    print(f"\n  Note: RTX4060, RTX3050, RTX5060 nên có similarity cao")
    print(f"        RasPi và iPhone15 nên khác biệt với GPU group")

    # So sánh 5D vs 16D
    print(f"\n  Ablation — 5D legacy vs 16D hybrid:")
    legacy_enc = LegacyHardwareEncoder(hw_dim=5, embed_dim=64)
    legacy_enc.eval()

    gpu_devices = ["rtx4060", "rtx3050", "rtx5060"]
    print(f"\n  GPU devices — cosine sim với rtx4060:")
    for name in gpu_devices:
        # 16D hybrid
        sim_hybrid = F.cosine_similarity(
            embeddings["rtx4060"].unsqueeze(0),
            embeddings[name].unsqueeze(0)
        ).item()

        # 5D legacy
        v1 = get_legacy_5d_vector("rtx4060").unsqueeze(0)
        v2 = get_legacy_5d_vector(name).unsqueeze(0)
        e1 = legacy_enc(v1)
        e2 = legacy_enc(v2)
        sim_legacy = F.cosine_similarity(e1, e2).item()

        print(f"    {name:15s}: 5D={sim_legacy:.3f} | 16D={sim_hybrid:.3f}")

    print(f"\n  → 16D phân biệt được các GPU khác thế hệ hơn 5D ✅")


if __name__ == "__main__":
    ok = verify_catalog()
    if ok:
        demo_encoder()
    else:
        print("\n❌ Catalog có lỗi — fix trước khi chạy demo")
# Thêm vào DEVICE_CATALOG (chạy lệnh này để patch)
DEVICE_CATALOG["rtx3060"] = {
    "description": "NVIDIA RTX 3060 — Ampere, 10GB GDDR6",
    "meta_train":  True,
    "categorical": [0, 0, 1, 0, 0, 0, 0, 0],
    "performance": [
        10  / _NORM["memory"],
        360 / _NORM["bandwidth"],
        12.7/ _NORM["tflops"],
        170 / _NORM["tdp"],
        3584/ _NORM["cuda_cores"],
        3   / _NORM["arch_gen"],
        0.0,
        0.0,
    ],
}
