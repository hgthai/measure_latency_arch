#!/usr/bin/env python3
"""Validate a HyTra-CIFAR latency CSV before MHLP training."""

from __future__ import annotations

import argparse
import csv
import math
import os
import statistics
import sys
from collections import defaultdict
from typing import Dict, List

import numpy as np
import torch


REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
MHLP_DIR = os.path.join(REPO_ROOT, "src", "mhlp")
if MHLP_DIR not in sys.path:
    sys.path.insert(0, MHLP_DIR)

from hytra_encoding_v2 import HyTraCIFARDataset  # noqa: E402


REQUIRED_COLUMNS = {"architecture_string", "hardware_type", "latency_ms"}


def _load_rows(csv_path: str) -> List[Dict[str, str]]:
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"{csv_path} has no CSV header")
        missing = REQUIRED_COLUMNS.difference(reader.fieldnames)
        if missing:
            raise ValueError(f"Missing required columns: {sorted(missing)}")
        return list(reader)


def check_csv(csv_path: str) -> None:
    rows = _load_rows(csv_path)
    if not rows:
        raise ValueError("Latency CSV is empty")

    seen_pairs = set()
    latencies_by_hw: Dict[str, List[float]] = defaultdict(list)
    dataset_rows = []
    for row_idx, row in enumerate(rows, start=2):
        arch = (row.get("architecture_string") or "").strip()
        hardware = (row.get("hardware_type") or "").strip()
        latency_raw = row.get("latency_ms")
        if not arch or not hardware:
            raise ValueError(f"Row {row_idx} has missing architecture_string or hardware_type")
        if latency_raw is None or str(latency_raw).strip() == "":
            raise ValueError(f"Row {row_idx} has missing latency_ms")
        latency = float(latency_raw)
        if not math.isfinite(latency) or latency <= 0:
            raise ValueError(f"Row {row_idx} has non-positive/non-finite latency_ms={latency_raw}")

        pair = (arch, hardware)
        if pair in seen_pairs:
            raise ValueError(
                f"Duplicate architecture_string + hardware_type row detected at row {row_idx}: {pair}"
            )
        seen_pairs.add(pair)
        latencies_by_hw[hardware].append(latency)
        dataset_rows.append({
            "architecture_string": arch,
            "hardware_type": hardware,
            "latency_ms": latency,
        })

    dataset = HyTraCIFARDataset(dataset_rows, normalize_latency=False)
    if len(dataset) != len(rows):
        raise ValueError(f"Dataset length mismatch: {len(dataset)} != {len(rows)}")

    for idx in range(len(dataset)):
        X, A, hw, latency = dataset[idx]
        if tuple(X.shape) != (10, 18):
            raise ValueError(f"Row {idx} architecture feature shape is {tuple(X.shape)}, expected (10, 18)")
        if tuple(A.shape) != (10, 10):
            raise ValueError(f"Row {idx} adjacency shape is {tuple(A.shape)}, expected (10, 10)")
        if tuple(hw.shape) != (16,):
            raise ValueError(f"Row {idx} hardware vector shape is {tuple(hw.shape)}, expected (16,)")
        for name, tensor in [("X", X), ("A", A), ("hardware", hw), ("latency", latency)]:
            if not torch.isfinite(tensor).all().item():
                raise ValueError(f"Row {idx} has NaN/Inf in {name}")

    print("HyTra-CIFAR latency dataset check passed")
    print(f"Rows: {len(rows)}")
    print(f"Unique architecture+hardware pairs: {len(seen_pairs)}")
    print(f"HyTraCIFARDataset rows: {len(dataset)}")
    print("Latency by hardware:")
    for hardware in sorted(latencies_by_hw):
        values = latencies_by_hw[hardware]
        print(
            f"  {hardware}: n={len(values)}, "
            f"min={min(values):.6f} ms, "
            f"median={statistics.median(values):.6f} ms, "
            f"max={max(values):.6f} ms"
        )


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Check a HyTra-CIFAR latency CSV")
    parser.add_argument("--csv", required=True, help="Path to latency CSV")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    check_csv(args.csv)


if __name__ == "__main__":
    main()
