#!/usr/bin/env python3
"""Audit the official HyTra-CIFAR RTX 4080 SUPER latency dataset."""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import random
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


EXPECTED_ROWS = 1200
REMEASURE_SUBSET_SIZE = 10
REMEASURE_SEED = 20260521


Record = Dict[str, Any]


def _read_json(path: str | Path) -> Dict[str, Any]:
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _read_csv(path: str | Path) -> List[Record]:
    with open(path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        if reader.fieldnames is None:
            raise ValueError(f"CSV has no header: {path}")
        required = {"architecture_string", "hardware_type", "latency_ms"}
        missing = required.difference(reader.fieldnames)
        if missing:
            raise ValueError(f"CSV missing required columns: {sorted(missing)}")
        return list(reader)


def _arch_string(record: Record) -> str:
    value = record.get("architecture_string") or record.get("arch_string")
    if not value:
        raise ValueError(f"Architecture record missing architecture string: {record}")
    return str(value)


def _as_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Cannot parse float value: {value!r}") from exc


def _safe_std(values: Sequence[float]) -> float:
    if not values:
        return float("nan")
    return float(np.std(np.asarray(values, dtype=float)))


def _stats(values: Sequence[float]) -> Dict[str, float | int]:
    arr = np.asarray(values, dtype=float)
    if arr.size == 0:
        return {
            "count": 0,
            "min": float("nan"),
            "median": float("nan"),
            "mean": float("nan"),
            "max": float("nan"),
            "std": float("nan"),
        }
    return {
        "count": int(arr.size),
        "min": float(np.min(arr)),
        "median": float(np.median(arr)),
        "mean": float(np.mean(arr)),
        "max": float(np.max(arr)),
        "std": float(np.std(arr)),
    }


def _global_stats(values: Sequence[float]) -> Dict[str, float | int]:
    arr = np.asarray(values, dtype=float)
    base = _stats(values)
    percentiles = {
        f"p{p}": float(np.percentile(arr, p))
        for p in [5, 25, 50, 75, 95, 99]
    }
    mean = float(base["mean"])
    std = float(base["std"])
    base.update(percentiles)
    base["coefficient_of_variation"] = std / mean if mean else float("nan")
    return base


def _group_stats(rows: Iterable[Record], key: str) -> Dict[str, Dict[str, float | int]]:
    buckets: Dict[str, List[float]] = defaultdict(list)
    for row in rows:
        value = row.get(key)
        if value is None:
            continue
        if key == "downsample_pattern" and isinstance(value, list):
            value = str(value)
        buckets[str(value)].append(float(row["latency_ms"]))
    return {name: _stats(values) for name, values in sorted(buckets.items(), key=lambda item: item[0])}


def _numeric_correlation(rows: Sequence[Record], x_key: str) -> Optional[float]:
    xs: List[float] = []
    ys: List[float] = []
    for row in rows:
        value = row.get(x_key)
        if value is None:
            continue
        x = _as_float(value)
        y = _as_float(row.get("latency_ms"))
        if math.isfinite(x) and math.isfinite(y):
            xs.append(x)
            ys.append(y)
    if len(xs) < 2:
        return None
    if np.std(xs) == 0 or np.std(ys) == 0:
        return None
    return float(np.corrcoef(np.asarray(xs), np.asarray(ys))[0, 1])


def _ensure_dir(path: str | Path) -> Path:
    out = Path(path)
    out.mkdir(parents=True, exist_ok=True)
    return out


def _save_histogram(latencies: Sequence[float], fig_dir: Path, hardware_label: str) -> str:
    path = fig_dir / f"{hardware_label}_latency_histogram.png"
    plt.figure(figsize=(8, 5))
    plt.hist(latencies, bins=40, color="#4C78A8", edgecolor="white")
    plt.title(f"HyTra-CIFAR Latency Distribution on {hardware_label}")
    plt.xlabel("Latency (ms)")
    plt.ylabel("Number of architectures")
    plt.grid(axis="y", alpha=0.25)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()
    return str(path)


def _save_group_boxplot(rows: Sequence[Record], fig_dir: Path, hardware_label: str) -> str:
    path = fig_dir / f"{hardware_label}_latency_boxplot_by_group.png"
    order = ["cnn_dominant", "light_hybrid", "balanced_hybrid", "attention_dominant"]
    grouped = defaultdict(list)
    for row in rows:
        grouped[str(row.get("group"))].append(float(row["latency_ms"]))
    labels = [label for label in order if grouped.get(label)]
    data = [grouped[label] for label in labels]
    plt.figure(figsize=(8, 5))
    plt.boxplot(data, tick_labels=labels, showfliers=False)
    plt.title("HyTra-CIFAR Latency by Architecture Group")
    plt.xlabel("Architecture group")
    plt.ylabel("Latency (ms)")
    plt.grid(axis="y", alpha=0.25)
    plt.xticks(rotation=15, ha="right")
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()
    return str(path)


def _save_resatt_plot(rows: Sequence[Record], fig_dir: Path, hardware_label: str) -> str:
    path = fig_dir / f"{hardware_label}_latency_by_resatt_count.png"
    grouped = defaultdict(list)
    for row in rows:
        grouped[int(row.get("n_resatt", 0))].append(float(row["latency_ms"]))
    labels = sorted(grouped)
    medians = [float(np.median(grouped[label])) for label in labels]
    means = [float(np.mean(grouped[label])) for label in labels]
    plt.figure(figsize=(8, 5))
    plt.plot(labels, medians, marker="o", label="Median")
    plt.plot(labels, means, marker="s", label="Mean")
    plt.title("HyTra-CIFAR Latency by Number of ResAtt Blocks")
    plt.xlabel("Number of ResAtt blocks")
    plt.ylabel("Latency (ms)")
    plt.grid(alpha=0.25)
    plt.legend()
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()
    return str(path)


def _save_complexity_scatter(rows: Sequence[Record], fig_dir: Path, hardware_label: str) -> Optional[str]:
    pairs = [
        (_as_float(row["complexity_proxy"]), _as_float(row["latency_ms"]))
        for row in rows
        if row.get("complexity_proxy") is not None
    ]
    if not pairs:
        return None
    path = fig_dir / f"{hardware_label}_latency_vs_complexity.png"
    xs = [p[0] for p in pairs]
    ys = [p[1] for p in pairs]
    plt.figure(figsize=(8, 5))
    plt.scatter(xs, ys, s=14, alpha=0.65, color="#59A14F", edgecolors="none")
    plt.title("HyTra-CIFAR Latency vs. Complexity Proxy")
    plt.xlabel("Complexity proxy")
    plt.ylabel("Latency (ms)")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()
    return str(path)


def _save_cdf(latencies: Sequence[float], fig_dir: Path, hardware_label: str) -> str:
    path = fig_dir / f"{hardware_label}_latency_cdf.png"
    arr = np.sort(np.asarray(latencies, dtype=float))
    y = np.arange(1, len(arr) + 1) / len(arr)
    plt.figure(figsize=(8, 5))
    plt.plot(arr, y, color="#F28E2B")
    plt.title(f"HyTra-CIFAR Latency CDF on {hardware_label}")
    plt.xlabel("Latency (ms)")
    plt.ylabel("Cumulative fraction")
    plt.grid(alpha=0.25)
    plt.tight_layout()
    plt.savefig(path, dpi=180)
    plt.close()
    return str(path)


def _make_figures(rows: Sequence[Record], fig_dir: str | Path, hardware_label: str) -> List[str]:
    out = _ensure_dir(fig_dir)
    latencies = [float(row["latency_ms"]) for row in rows]
    paths: List[str] = [
        _save_histogram(latencies, out, hardware_label),
        _save_group_boxplot(rows, out, hardware_label),
        _save_resatt_plot(rows, out, hardware_label),
    ]
    complexity_path = _save_complexity_scatter(rows, out, hardware_label)
    if complexity_path:
        paths.append(complexity_path)
    paths.append(_save_cdf(latencies, out, hardware_label))
    return paths


def _make_remeasure_subset(fixed_records: Sequence[Record], fixed_set_path: str | Path) -> str:
    rng = random.Random(REMEASURE_SEED)
    subset = [dict(item) for item in rng.sample(list(fixed_records), REMEASURE_SUBSET_SIZE)]
    out_path = Path(fixed_set_path).with_name("remeasure_subset_10.json")
    payload = {
        "description": "Random 10-architecture subset for optional future latency noise checks. No remeasurement was run when this file was created.",
        "source_fixed_set": str(fixed_set_path),
        "seed": REMEASURE_SEED,
        "count": len(subset),
        "architectures": subset,
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return str(out_path)


def audit(args: argparse.Namespace) -> Dict[str, Any]:
    fixed_payload = _read_json(args.fixed_set)
    measurement_payload = _read_json(args.measurement_json) if args.measurement_json else {}
    csv_rows_all = _read_csv(args.csv)
    if args.hardware:
        csv_rows = [row for row in csv_rows_all if row.get("hardware_type") == args.hardware]
        if not csv_rows:
            available = sorted({row.get("hardware_type", "") for row in csv_rows_all})
            raise ValueError(f"No CSV rows found for --hardware={args.hardware!r}. Available hardware labels: {available}")
    else:
        csv_rows = csv_rows_all
    fixed_records = fixed_payload.get("architectures", [])

    fixed_by_arch = {_arch_string(record): record for record in fixed_records}
    fixed_arch_strings = set(fixed_by_arch)
    csv_arch_strings = [row["architecture_string"] for row in csv_rows]
    csv_arch_set = set(csv_arch_strings)

    duplicate_arch_count = len(csv_arch_strings) - len(csv_arch_set)
    pair_counts = Counter((row["architecture_string"], row["hardware_type"]) for row in csv_rows)
    duplicate_pair_count = sum(count - 1 for count in pair_counts.values() if count > 1)
    missing_from_fixed = sorted(csv_arch_set - fixed_arch_strings)
    missing_from_csv = sorted(fixed_arch_strings - csv_arch_set)

    invalid_latency_rows: List[Dict[str, Any]] = []
    merged_rows: List[Record] = []
    for idx, row in enumerate(csv_rows):
        latency = _as_float(row.get("latency_ms"))
        if not math.isfinite(latency) or latency <= 0:
            invalid_latency_rows.append({"row_index": idx, "architecture_string": row.get("architecture_string"), "latency_ms": row.get("latency_ms")})
        arch = row["architecture_string"]
        fixed = fixed_by_arch.get(arch, {})
        merged = dict(fixed)
        merged.update(row)
        merged["latency_ms"] = latency
        merged_rows.append(merged)

    latencies = [float(row["latency_ms"]) for row in merged_rows]
    hardware_labels = sorted({row.get("hardware_type", "unknown") for row in csv_rows})
    figure_hardware_label = args.hardware or (hardware_labels[0] if len(hardware_labels) == 1 else "all_devices")
    figure_paths = _make_figures(merged_rows, args.fig_dir, figure_hardware_label)
    remeasure_subset_path = _make_remeasure_subset(fixed_records, args.fixed_set)

    pass_status = (
        len(csv_rows) == EXPECTED_ROWS
        and len(csv_arch_set) == EXPECTED_ROWS
        and duplicate_arch_count == 0
        and duplicate_pair_count == 0
        and not invalid_latency_rows
        and not missing_from_fixed
        and not missing_from_csv
    )

    report: Dict[str, Any] = {
        "input_paths": {
            "fixed_set": args.fixed_set,
            "csv": args.csv,
            "measurement_json": args.measurement_json,
        },
        "hardware_filter": args.hardware,
        "hardware_labels_in_scope": hardware_labels,
        "total_rows_all_hardware": len(csv_rows_all),
        "total_rows": len(csv_rows),
        "expected_rows": EXPECTED_ROWS,
        "unique_architecture_count": len(csv_arch_set),
        "duplicate_count": duplicate_arch_count,
        "duplicate_architecture_hardware_rows": duplicate_pair_count,
        "missing_from_fixed_set": missing_from_fixed,
        "missing_from_latency_csv": missing_from_csv,
        "invalid_latency_rows": invalid_latency_rows,
        "global_latency_statistics": _global_stats(latencies),
        "group_level_statistics": _group_stats(merged_rows, "group"),
        "resatt_level_statistics": _group_stats(merged_rows, "n_resatt"),
        "downsample_pattern_statistics": _group_stats(merged_rows, "downsample_pattern"),
        "correlation_summary": {
            "n_resatt_vs_latency_pearson": _numeric_correlation(merged_rows, "n_resatt"),
            "complexity_proxy_vs_latency_pearson": _numeric_correlation(merged_rows, "complexity_proxy"),
        },
        "generated_figure_paths": figure_paths,
        "remeasure_subset_path": remeasure_subset_path,
        "measurement_metadata": {
            key: measurement_payload.get(key)
            for key in [
                "search_space", "proxy_model", "input_size", "batch_size",
                "warmup_iters", "measure_iters", "hardware_label", "hardware",
                "device_used", "torch_version", "cuda_available", "gpu_name",
                "total", "total_measured", "total_failed", "measured_at",
            ]
            if key in measurement_payload
        },
        "pass": pass_status,
        "status": "pass" if pass_status else "fail",
        "generated_at": datetime.now(timezone.utc).isoformat(),
    }
    return report


def _fmt(value: Any, digits: int = 6) -> str:
    if isinstance(value, (int, np.integer)):
        return str(value)
    if isinstance(value, (float, np.floating)):
        return f"{float(value):.{digits}f}"
    return str(value)


def write_markdown(report: Dict[str, Any], out_path: str | Path) -> None:
    stats = report["global_latency_statistics"]
    corr = report["correlation_summary"]
    group_stats = report["group_level_statistics"]
    status = "PASS" if report["pass"] else "FAIL"

    fastest = min(group_stats.items(), key=lambda item: item[1]["median"])[0] if group_stats else "n/a"
    slowest = max(group_stats.items(), key=lambda item: item[1]["median"])[0] if group_stats else "n/a"
    hardware_label = report.get("hardware_filter") or ", ".join(report.get("hardware_labels_in_scope", [])) or "selected hardware"
    lines = [
        f"# HyTra-CIFAR {hardware_label} Latency Audit",
        "",
        f"**Status:** {status}",
        "",
        "Dataset này gồm 1200 kiến trúc HyTra-CIFAR unique. Tất cả latency trong phạm vi audit này được đo thật trên thiết bị được chỉ định, dùng `HyTraCIFARProxyModel`, `input_size=32`, `batch_size=1`, warmup 20 và 50 runs. Không có duplicate architecture, không có duplicate architecture+hardware row, không có missing architecture, và không có lỗi đo trong measurement JSON.",
        "",
        "## Global Latency Summary",
        "",
        f"- Min: {_fmt(stats['min'])} ms",
        f"- Median: {_fmt(stats['median'])} ms",
        f"- Max: {_fmt(stats['max'])} ms",
        f"- Mean: {_fmt(stats['mean'])} ms",
        f"- Std: {_fmt(stats['std'])} ms",
        f"- P5/P25/P50/P75/P95/P99: {_fmt(stats['p5'])} / {_fmt(stats['p25'])} / {_fmt(stats['p50'])} / {_fmt(stats['p75'])} / {_fmt(stats['p95'])} / {_fmt(stats['p99'])} ms",
        f"- Coefficient of variation: {_fmt(stats['coefficient_of_variation'])}",
        "",
        "## Observations",
        "",
        f"Phân phối latency có dải từ khoảng {_fmt(stats['min'])} ms đến {_fmt(stats['max'])} ms, với median thấp hơn mean. Điều này cho thấy phần lớn kiến trúc nằm ở vùng latency thấp hơn, nhưng có một nhóm kiến trúc chậm hơn kéo mean lên.",
        f"Theo median từng group, nhóm nhanh nhất là `{fastest}` và nhóm chậm nhất là `{slowest}`. Tương quan Pearson giữa số ResAtt và latency là `{_fmt(corr.get('n_resatt_vs_latency_pearson'))}`, còn tương quan giữa complexity proxy và latency là `{_fmt(corr.get('complexity_proxy_vs_latency_pearson'))}`. Các giá trị gần 0 này cho thấy tương quan tuyến tính giữa ResAtt/complexity proxy và latency là rất yếu trong dataset official này; biến thiên latency có thể chịu ảnh hưởng lớn từ pattern/implementation/runtime noise hơn là chỉ từ hai biến đơn lẻ này.",
        "",
        "## Figures",
        "",
    ]
    for fig_path in report["generated_figure_paths"]:
        lines.append(f"- `{fig_path}`")
    lines.extend([
        "",
        "## Re-measure Subset",
        "",
        f"- `{report['remeasure_subset_path']}`",
        "",
    ])
    Path(out_path).write_text("\n".join(lines), encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Audit official HyTra-CIFAR latency measurements")
    parser.add_argument("--fixed-set", required=True)
    parser.add_argument("--csv", required=True)
    parser.add_argument("--measurement-json", required=True)
    parser.add_argument("--out-json", required=True)
    parser.add_argument("--out-md", required=True)
    parser.add_argument("--fig-dir", required=True)
    parser.add_argument("--hardware", default=None, help="Optional hardware_type filter when auditing an all-devices CSV")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    report = audit(args)
    Path(args.out_json).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out_json).write_text(json.dumps(report, indent=2), encoding="utf-8")
    write_markdown(report, args.out_md)

    print(f"Audit status: {report['status'].upper()}")
    print(f"Rows: {report['total_rows']}")
    print(f"Unique architectures: {report['unique_architecture_count']}")
    print(f"Duplicate architecture rows: {report['duplicate_count']}")
    print(f"Duplicate architecture+hardware rows: {report['duplicate_architecture_hardware_rows']}")
    print(f"Missing from fixed set: {len(report['missing_from_fixed_set'])}")
    print(f"Missing from latency CSV: {len(report['missing_from_latency_csv'])}")
    stats = report["global_latency_statistics"]
    print(
        "Latency ms: "
        f"min={stats['min']:.6f}, median={stats['median']:.6f}, "
        f"mean={stats['mean']:.6f}, max={stats['max']:.6f}, std={stats['std']:.6f}"
    )
    print(f"JSON report: {args.out_json}")
    print(f"Markdown report: {args.out_md}")
    print("Figures:")
    for path in report["generated_figure_paths"]:
        print(f"  {path}")
    print(f"Remeasure subset: {report['remeasure_subset_path']}")
    if not report["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
